/* iMa! settings. No secret keys here: they live on the backend (Vercel backend). */

// Backend base URL (no trailing slash).
window.IMA_API = "https://imabackend.vercel.app";

window.IMA_CONFIG = {
  // tried in order; the first one that works is kept
  groqModels: ["openai/gpt-oss-120b", "openai/gpt-oss-20b"],
};
