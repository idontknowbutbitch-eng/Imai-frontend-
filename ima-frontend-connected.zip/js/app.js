(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const root      = document.documentElement;
  const app       = $("app");
  const thread    = $("thread");
  const composer  = $("composer");
  const input     = $("input");
  const sendBtn   = $("sendBtn");
  const attachBtn = $("attachBtn");
  const fileInput = $("fileInput");
  const bgFile    = $("bgFile");
  const bgVideoFile = $("bgVideoFile");
  const tray      = $("tray");
  const modesEl   = $("modes");
  const drawerBtn = $("drawerBtn");
  const moreBtn   = $("moreBtn");
  const drawer    = $("drawer");
  const scrim     = $("scrim");
  const menu      = $("menu");
  const menuScrim = $("menuScrim");
  const modal     = $("modal");
  const modalBox  = $("modalBox");
  const toastEl   = $("toast");
  const bgEl      = $("bg");
  const bgHexEl   = $("bgHex");
  const bgAurora  = $("bgAurora");
  const bgPhotoEl = $("bgPhoto");
  const bgVideoEl = $("bgVideo");

  const icon = (name) => `assets/icons/${name}.png`;

  const CHECK = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2.5 8.5l3.5 3.5 7.5-8"/></svg>';
  const BACK  = '<svg viewBox="0 0 9 16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7.5 1.5L1.5 8l6 6.5"/></svg>';


  /* =========================================================
     LANGUAGES  (English / العربية)
     Add a key here, then use t("key") in the code or
     data-i18n="key" in the HTML.
  ========================================================= */

  const I18N = {
    en: {
      menu: "Menu", more: "More options", attach: "Attach", message: "Message", send: "Send",
      settings: "Settings", memory: "Memory", files: "Uploaded files", newChat: "New chat", done: "Done",

      switchModel: "Switch model", addModel: "Add your own model", cmTitle: "Your model", cmYours: "Your models", cmName: "Name", cmEndpoint: "Endpoint URL", cmKey: "API key", cmModelId: "Model ID", cmSave: "Save & use", cmDelete: "Delete this model", cmNew: "New model", cmMissing: "Add the endpoint URL and the model ID", cmNote: "Works with any OpenAI-compatible API (OpenAI, Groq, OpenRouter, Together, Mistral, DeepSeek, Ollama, LM Studio…). Your key stays on this device only.", thinkHarder: "Think harder", deepSearch: "Deep search",
      shareChat: "Share chat", deleteChat: "Delete chat",
      addPicture: "Add a picture", createImage: "Create image", cmdImagine: "Imagine", cmdImagineDesc: "Create an image from your words", cmdImagineHint: "Describe the image…",
      cmdWeather: "Weather", cmdWeatherDesc: "Live weather for any city", cmdWeatherHint: "City (empty = my location)…", cmdNews: "News", cmdNewsDesc: "Latest stories on any topic", cmdNewsHint: "Topic (empty = top stories)…", cmdSearch: "Search", cmdSearchDesc: "Search the web for an answer", cmdSearchHint: "What do you want to know?…", cmdImages: "Images", cmdImagesDesc: "Find pictures from the web", cmdImagesHint: "What pictures?…", cmdMap: "Map", cmdMapDesc: "Show any place on a map", cmdMapHint: "Place name…", mapOpen: "Open in Maps", newsTop: "Top stories",
      igTitle: "Imagine Settings", igQuality: "Quality", igRatio: "Aspect Ratio", igRatioSub: "Choose the shape of your image",
      igImprove: "Improve with AI prompt", igImproveSub: "Let AI rewrite your idea as a professional prompt",

      chipThink: "Thinking harder", chipDeep: "Deep search", chipImage: "Create image",
      turnOff: "Turn off", removePicture: "Remove picture",
      reply: "Reply", edit: "Edit", chipEdit: "Editing message", regenerate: "Regenerate", copy: "Copy", translate: "Translate",
      select: "Select", expand: "Expand", openShort: "Open", chatInfo: "Information", infoCreated: "Created", infoUpdated: "Last activity", infoMessages: "Messages", infoYours: "From you", infoReplies: "From iMa!", infoPhotos: "Photos", infoStatus: "Status", infoPinned: "Pinned", infoArchived: "Archived", infoNormal: "Normal", infoTitle: "Name", addEmoji: "Add emoji",
      replyingTo: "Replying to", replyingSelf: "Replying to yourself", repliedAI: "You replied to iMa!", repliedSelf: "You replied to yourself", haha: "Haha", emphasize: "Emphasis", question: "Question", love: "Love", like: "Like", dislike: "Dislike", openChat: "Open chat", msgCopied: "Copied", translateSoon: "Translation will work once the API is connected",

      switchedTo: "Switched to", copied: "Chat copied to clipboard",
      shareFail: "Couldn't share this chat", deleted: "Chat deleted", you: "You",
      pics: (n) => ` [${n} picture${n > 1 ? "s" : ""}]`,
      empty: "No pictures yet.",

      deleteTitle: "Delete chat?",
      deleteMsg: "It will stay in Trash for 30 days, then it's deleted forever.",
      cancel: "Cancel", delete: "Delete",
      selectAll: "Select all", deselectAll: "Deselect all", delN: (n) => `Delete (${n})`,
      delChatsTitle: (n) => n === 1 ? "Delete chat?" : `Delete ${n} chats?`,
      delChatsMsg: "They will stay in Trash for 30 days, then they're deleted forever.",
      chatsDeleted: (n) => n === 1 ? "Chat deleted" : `${n} chats deleted`,
      delPicsTitle: (n) => n === 1 ? "Delete picture?" : `Delete ${n} pictures?`,
      delPicsMsg: "They will stay in Trash for 30 days, then they're deleted forever.",
      trash: "Trash", trashNote: "Deleted chats and pictures stay here for 30 days, then they're deleted forever.",
      trashChats: "Chats", trashFiles: "Files", trashEmpty: "Nothing in Trash", restore: "Restore",
      restored: (n) => n === 1 ? "Restored" : `${n} restored`,
      daysLeft: (n) => n === 1 ? "1 day left" : `${n} days left`,
      eraseTitle: (n) => n === 1 ? "Delete forever?" : `Delete ${n} items forever?`,
      eraseMsg: "This can't be undone.",
      erased: (n) => n === 1 ? "Deleted forever" : `${n} items deleted forever`,
      cantRun: (l) => `${l} can't be run here. The preview runs HTML, CSS, JavaScript and Python.`,
      picsDeleted: (n) => n === 1 ? "Picture deleted" : `${n} pictures deleted`,

      greeting: "Hi, I'm iMa!. What can I help with?",
      today: "Today", delivered: "Delivered", typing: "iMa! is typing",
      attached: "Attached picture", uploadedPic: "Uploaded picture",
      describeImage: "Describe the image you want…", imageReady: "Here's your image.",
      replies: [
        "Sure — tell me a bit more and I'll help.",
        "Got it. Here's how I'd approach that.",
        "Good question. Let me think it through.",
        "Happy to help with that."
      ],
      nicePic: "Nice picture. What would you like to know about it?",
      nicePics: "Nice pictures. What would you like to know about them?",

      language: "Language",
      general: "General", messaging: "Messaging",
      appearance: "Appearance", appFont: "App font", fontDefault: "Default", fontUpload: "Upload a font file (.ttf, .otf)", fontLink: "Web font link", fontName: "Font name (optional)", fontUse: "Use this link", fontReset: "Back to the default font", fontApplied: "Font applied", fontBad: "Could not load this font", fontNeedName: "Add the font name too", fontNote: "Upload a .ttf, .otf or .woff file, or paste a Google Fonts link (or any font file link). The font is kept on this device.", fontSize: "Font size", fsSmall: "Small", fsDefault: "Default", fsLarge: "Large",
      density: "Interface density", dnCompact: "Compact", dnDefault: "Default", dnComfortable: "Comfortable",
      appearanceNote: "Applies to chats, menus and settings right away.",
      dataPrivacy: "Data & Privacy", exportChats: "Export chats", clearChat: "Clear chat", clearHistory: "Clear history",
      manageData: "Manage local data", deleteAllData: "Delete all local data", dpPrefs: "Data & Privacy preferences",
      dataNote: "Everything is kept on this device. Messages are only sent to the AI service to get a reply.",
      exportNone: "No chats to export", exportDone: "Chats exported", nothingToClear: "Nothing to clear", clearBtn: "Clear",
      clearChatTitle: "Clear this chat?", clearChatMsg: "It will stay in Trash for 30 days, then it's deleted forever.", clearChatDone: "Chat cleared",
      clearHistTitle: "Clear history?", clearHistMsg: "All chats will move to Trash for 30 days, then they're deleted forever.", clearHistDone: "History cleared",
      mdChats: "Chats", mdPics: "Pictures", mdTrash: "Trash", mdCache: "Cached data", mdEmpty: "Nothing to delete", mdDone: "Deleted",
      mdNote: "Tap Pictures, Trash or Cached data to delete them forever.",
      mdPicsTitle: "Delete all pictures?", mdPicsMsg: "Pictures are removed from every chat and can't be restored.",
      mdTrashTitle: "Empty Trash?", mdTrashMsg: "Everything in Trash is deleted forever.",
      mdCacheTitle: "Clear cached data?", mdCacheMsg: "News and other temporary data are removed. Your chats stay.",
      delAllTitle: "Delete all local data?", delAllMsg: "Chats, pictures, profile, settings and songs on this device are deleted forever. This can't be undone.", delAllBtn: "Delete everything",
      saveHistory: "Save chat history", saveHistoryNote: "When off, new chats are not saved on this device.",
      aiTitles: "AI chat names", aiTitlesNote: "iMa! reads the first messages of a chat to give it a name.",
      glass: "Glass effect", glassNote: "Turn off to use a regular blur instead of glass.",
      resetGlass: "Reset glass", advTools: "Advanced tools", advSoon: "Coming soon", musicSearch: "Search music", ytTitle: "YouTube", ytSearch: "Search YouTube", ytLoading: "Loading…", ytNone: "No videos found", ytFail: "Couldn't load YouTube", mapTitle: "Map", mapSatellite: "Satellite", wxTitle: "Weather", newsTitle: "News", newsSearch: "Search news", newsNone: "No stories found", newsFail: "Couldn't load the news", newsRetry: "Tap to retry", srchTitle: "Search", webTitle: "Web", imgTitle: "Images", imgSearch: "Search images", imgHint: "Type a search and press Enter", imgNone: "No images found", imgFail: "Couldn't search images", webSearch: "Search the web", webHint: "Type a search and press Enter", webNone: "No results", webFail: "Couldn't search the web", wxSearch: "Search city", wxHere: "My location", wxNone: "City not found", wxFail: "Couldn't load weather", mapSearch: "Search places", mapLocate: "My location", mapNone: "Place not found", mapFail: "Couldn't load the map", mapDenied: "Location unavailable", ytClose: "Close video", trTitle: "Translate", trGo: "Translate chat", trBack: "Show original", trWorking: "Translating…", trOrig: "Original", trDone: "Translated", trFail: "Couldn't translate", trEmpty: "Nothing to translate", mpSongs: "Songs", mpPick: "Music", mpLoading: "Loading…", mpNone: "No songs found", mpOffline: "Couldn't load music", mpLocal: "Local", mpItunes: "iTunes 30s", mpAdd: "Add songs", mpLocalNone: "No songs added yet", mpSearchLocal: "Search your songs", mpRemove: "Remove", mpLocalFail: "Couldn't save the songs", glassBlur: "Glass blur", glassDark: "Glass darkness", glassOpts: "Glass", sheetBtns: "Sheet buttons (Done / Select)", btnTint: "Inner layer: black ↔ white", btnEdge: "Glass thickness", resetTint: "Reset",
      devMode: "Developer mode", aboutIma: "About iMai", notifyUpdate: "Notify me when iMai is updated", aboutImaNote: "An AI made by Ivan", aboutImaLocal: "Your chats stay on this device.", shapes: "Shapes", pillW: "Title width", pillH: "Title height", pillR: "Title roundness", pillS: "Title smoothness",
      btnSize: "Round buttons", bubbleR: "Bubble roundness", fieldR: "Message bar roundness",
      resetShapes: "Reset shapes", shapesNote: "Size and roundness in px, like CSS: width, height, border-radius. Smoothness turns round corners into squircles.",
      chatTheme: "Chat theme", background: "Background",
      bgColor: "Color", bgHex: "Hexagons", bgAurora: "Aurora", bgPhoto: "Photo", chatStyle: "Chat style", styleGpt: "ChatGPT", styleImsg: "iMessage",
      color: "Color", hexColor: "Hexagon color", auroraColor: "Aurora color",
      choosePhoto: "Choose photo", changePhoto: "Change photo", removePhoto: "Remove",
      photoBlur: "Background blur", removePhotoRow: "Remove photo",
      bgVideo: "Video", chooseVideo: "Choose video", changeVideo: "Change video", removeVideoRow: "Remove video",
      videoFail: "Couldn't use that video (max 150 MB)",
      photoFail: "Couldn't use that picture", customColor: "Custom color",
      bubbles: "Bubbles", bubbleStyle: "Style", solid: "Solid", blur: "Blur",
      myBubbles: "My bubbles", imaBubbles: "iMa! bubbles",
      blurNote: "Blur bubbles are frosted, not glass — they blur whatever is behind them.",
      enterSends: "Enter key sends", receipts: "Delivered receipts",
      enterNote: "The Enter key setting applies on computers. On phones, Enter adds a new line.",
      rememberAcross: "Remember across chats",
      rememberNote: "When on, iMa! can keep useful details you share so you don't have to repeat them.",
      aiError: "Couldn't get an answer right now. Please try again.",
      aiBusy: "Too many requests right now. Wait a moment and try again.",
      recent: "Recent", noChats: "No chats yet", noResults: "No results", searchChats: "Search chats",
      profile: "Profile", profileSoon: "Profile is coming soon", chatBusy: "Wait for the reply to finish first",
      name: "Name", yourName: "Your name", preferences: "Preferences", premium: "Premium iMa!",
      profileNote: "Your profile is saved on this device only. No sign-in needed; accounts are coming later.",
      tone: "Tone", toneDefault: "Default", toneFriendly: "Friendly", toneFormal: "Formal", toneCasual: "Casual",
      aboutYou: "About you", aboutPh: "Anything iMa! should know about you: your work, interests, goals…",
      customInstr: "Custom instructions", instrPh: "How should iMa! respond? For example: keep answers short and give examples.",
      prefNote: "These are sent to the AI together with your messages, and saved on this device.",
      editProfile: "Edit profile", createProfile: "Create profile", username: "Username", usernamePh: "username",
      usernameNote: "Usernames will be checked for availability once accounts are added.",
      adjustPhoto: "Adjust photo", usePhoto: "Use photo", cropHint: "Drag to move. Pinch or use the slider to zoom.",
      premiumFeatures: "Premium features", perMonth: "/ month",
      personalInfo: "Personal information", dataSecurity: "Data & security", subscription: "Subscription", personalization: "Personalization & preferences",
      email: "Email", emailPh: "name@example.com", emailNote: "Your name, username and email are saved on this device only. They will be used for sign-in once accounts are added.",
      freePlan: "Free", freeDesc: "Chat, pictures and the standard tools", currentPlan: "Current plan", upgrade: "Upgrade",
      age: "Age", agePh: "Age", persSec: "Personalization", profileSub: "Personal info, data and subscription", dsPrivacy: "Privacy",
      baseStyle: "Base style and tone", baseStyleNote: "Set the style and tone of how iMa! responds to you. This doesn't change iMa!'s abilities.",
      characteristics: "Characteristics", charNote: "Fine-tune how iMa! answers, on top of the base style. Default keeps the base style.",
      prefWarm: "Warm", prefEnthusiastic: "Enthusiastic", prefLists: "Headers & lists", prefEmoji: "Emoji", prefHumor: "Humor", prefLength: "Response length", prefExamples: "Examples",
      prefMore: "More", prefLess: "Less", prefDefault: "Default", prefShorter: "Shorter", prefLonger: "Longer", prefFewer: "Fewer",
      stProfessional: "Professional", stCandid: "Candid", stQuirky: "Quirky", stEfficient: "Efficient", stNerdy: "Nerdy",
      stSubDefault: "Preset style and tone", stSubFriendly: "Warm and chatty", stSubProfessional: "Polished and precise", stSubCasual: "Relaxed and easy-going",
      stSubCandid: "Direct and encouraging", stSubQuirky: "Playful and imaginative", stSubEfficient: "Concise and plain", stSubNerdy: "Curious about the details",
      mdPageNote: "Tap a row to manage it. Chats move to the Trash. Pictures and cached data are deleted forever. The Trash lets you restore or delete items one by one.", storedOn: "Stored on", thisDevice: "This device",
      dsNote: "Everything stays on this device. iMa! has no account or server storage yet. Deleting data can't be undone.",
      pin: "Pin", unpin: "Unpin", rename: "Rename", archive: "Archive", unarchive: "Unarchive",
      pinned: "Pinned", archived: "Archived", renameChat: "Rename chat", chatName: "Chat name",
      premiumSoon: "Details and payments are coming soon.",
      codePreview: "Code preview", previewBtn: "Preview", codeTab: "Code", runTab: "Run", back: "Back",
      pasteCode: "Paste your HTML, CSS or JavaScript here", nothingToRun: "Paste some code, then tap Run.",
      oneCode: "One code", separate: "Separate", webLang: "Web", separatedOpt: "Separated", langMenu: "Language",
      projects: "Projects", noProjects: "Code the AI writes in your chats is saved here automatically.", delProject: "Delete project", pastePy: "Paste your Python here", pyLoading: "Loading Python…", pasteHtml: "Paste your HTML here", pasteCss: "Paste your CSS here", pasteJs: "Paste your JavaScript here"
    },

    ar: {
      menu: "القائمة", more: "المزيد من الخيارات", attach: "إرفاق", message: "رسالة", send: "إرسال",
      settings: "الإعدادات", memory: "الذاكرة", files: "الملفات المرفوعة", newChat: "محادثة جديدة", done: "تم",

      switchModel: "تبديل النموذج", addModel: "أضف نموذجك الخاص", cmTitle: "نموذجك", cmYours: "نماذجك", cmName: "الاسم", cmEndpoint: "رابط الخدمة (Endpoint)", cmKey: "مفتاح API", cmModelId: "معرّف النموذج", cmSave: "حفظ واستخدام", cmDelete: "حذف هذا النموذج", cmNew: "نموذج جديد", cmMissing: "أضف رابط الخدمة ومعرّف النموذج", cmNote: "يعمل مع أي خدمة متوافقة مع OpenAI (OpenAI، Groq، OpenRouter، Together، Mistral، DeepSeek، Ollama، LM Studio…). يبقى مفتاحك على هذا الجهاز فقط.", thinkHarder: "تفكير أعمق", deepSearch: "بحث معمّق",
      shareChat: "مشاركة المحادثة", deleteChat: "حذف المحادثة",
      addPicture: "إضافة صورة", createImage: "إنشاء صورة", cmdImagine: "تخيّل", cmdImagineDesc: "أنشئ صورة من كلماتك", cmdImagineHint: "صف الصورة…",
      cmdWeather: "الطقس", cmdWeatherDesc: "الطقس المباشر لأي مدينة", cmdWeatherHint: "المدينة (فارغ = موقعي)…", cmdNews: "الأخبار", cmdNewsDesc: "آخر الأخبار عن أي موضوع", cmdNewsHint: "الموضوع (فارغ = أهم الأخبار)…", cmdSearch: "بحث", cmdSearchDesc: "ابحث في الويب عن إجابة", cmdSearchHint: "ماذا تريد أن تعرف؟…", cmdImages: "صور", cmdImagesDesc: "ابحث عن صور من الويب", cmdImagesHint: "أي صور تريد؟…", cmdMap: "الخريطة", cmdMapDesc: "اعرض أي مكان على الخريطة", cmdMapHint: "اسم المكان…", mapOpen: "فتح في الخرائط", newsTop: "أهم الأخبار",
      igTitle: "إعدادات التخيّل", igQuality: "الجودة", igRatio: "أبعاد الصورة", igRatioSub: "اختر شكل صورتك",
      igImprove: "تحسين الوصف بالذكاء الاصطناعي", igImproveSub: "يعيد الذكاء الاصطناعي صياغة فكرتك كوصف احترافي",

      chipThink: "تفكير أعمق", chipDeep: "بحث معمّق", chipImage: "إنشاء صورة",
      turnOff: "إيقاف", removePicture: "إزالة الصورة",
      reply: "رد", edit: "تعديل", chipEdit: "تعديل الرسالة", regenerate: "إعادة التوليد", copy: "نسخ", translate: "ترجمة",
      select: "تحديد", expand: "تكبير", openShort: "فتح", chatInfo: "معلومات", infoCreated: "تاريخ الإنشاء", infoUpdated: "آخر نشاط", infoMessages: "الرسائل", infoYours: "منك", infoReplies: "من iMa!", infoPhotos: "الصور", infoStatus: "الحالة", infoPinned: "مثبتة", infoArchived: "مؤرشفة", infoNormal: "عادية", infoTitle: "الاسم", addEmoji: "إضافة إيموجي",
      replyingTo: "الرد على", replyingSelf: "الرد على نفسك", repliedAI: "رددت على iMa!", repliedSelf: "رددت على نفسك", haha: "هاها", emphasize: "تأكيد", question: "سؤال", love: "حب", like: "إعجاب", dislike: "عدم إعجاب", openChat: "فتح المحادثة", msgCopied: "تم النسخ", translateSoon: "ستعمل الترجمة بعد ربط الواجهة البرمجية",

      switchedTo: "تم التبديل إلى", copied: "تم نسخ المحادثة",
      shareFail: "تعذّرت مشاركة المحادثة", deleted: "تم حذف المحادثة", you: "أنت",
      pics: (n) => n > 1 ? ` [${n} صور]` : " [صورة]",
      empty: "لا توجد صور بعد.",

      deleteTitle: "حذف المحادثة؟",
      deleteMsg: "ستبقى في سلة المحذوفات 30 يومًا ثم تُحذف نهائيًا.",
      cancel: "إلغاء", delete: "حذف",
      selectAll: "تحديد الكل", deselectAll: "إلغاء تحديد الكل", delN: (n) => `حذف (${n})`,
      delChatsTitle: (n) => n === 1 ? "حذف المحادثة؟" : `حذف ${n} محادثات؟`,
      delChatsMsg: "ستبقى في سلة المحذوفات 30 يومًا ثم تُحذف نهائيًا.",
      chatsDeleted: (n) => n === 1 ? "تم حذف المحادثة" : `تم حذف ${n} محادثات`,
      delPicsTitle: (n) => n === 1 ? "حذف الصورة؟" : `حذف ${n} صور؟`,
      delPicsMsg: "ستبقى في سلة المحذوفات 30 يومًا ثم تُحذف نهائيًا.",
      trash: "سلة المحذوفات", trashNote: "تبقى المحادثات والصور المحذوفة هنا 30 يومًا ثم تُحذف نهائيًا.",
      trashChats: "المحادثات", trashFiles: "الملفات", trashEmpty: "لا شيء في سلة المحذوفات", restore: "استعادة",
      restored: (n) => n === 1 ? "تمت الاستعادة" : `تمت استعادة ${n}`,
      daysLeft: (n) => n === 1 ? "باقي يوم واحد" : `باقي ${n} أيام`,
      eraseTitle: (n) => n === 1 ? "حذف نهائي؟" : `حذف ${n} عناصر نهائيًا؟`,
      eraseMsg: "لا يمكن التراجع عن ذلك.",
      erased: (n) => n === 1 ? "تم الحذف نهائيًا" : `تم حذف ${n} عناصر نهائيًا`,
      cantRun: (l) => `لا يمكن تشغيل ${l} هنا. المعاينة تشغّل HTML وCSS وJavaScript وPython.`,
      picsDeleted: (n) => n === 1 ? "تم حذف الصورة" : `تم حذف ${n} صور`,

      greeting: "مرحبًا، أنا iMa!. بماذا يمكنني مساعدتك؟",
      today: "اليوم", delivered: "تم التسليم", typing: "iMa! يكتب",
      attached: "صورة مرفقة", uploadedPic: "صورة مرفوعة",
      describeImage: "صِف الصورة التي تريدها…", imageReady: "تفضّل صورتك.",
      replies: [
        "بالتأكيد — أخبرني بالمزيد وسأساعدك.",
        "فهمت. هكذا سأتعامل مع الأمر.",
        "سؤال جيد. دعني أفكر فيه.",
        "يسعدني مساعدتك في ذلك."
      ],
      nicePic: "صورة جميلة. ماذا تريد أن تعرف عنها؟",
      nicePics: "صور جميلة. ماذا تريد أن تعرف عنها؟",

      language: "اللغة",
      general: "عام", messaging: "المراسلة",
      appearance: "المظهر", appFont: "خط التطبيق", fontDefault: "افتراضي", fontUpload: "ارفع ملف خط (.ttf، .otf)", fontLink: "رابط خط من الويب", fontName: "اسم الخط (اختياري)", fontUse: "استخدم هذا الرابط", fontReset: "العودة إلى الخط الافتراضي", fontApplied: "تم تطبيق الخط", fontBad: "تعذّر تحميل هذا الخط", fontNeedName: "أضف اسم الخط أيضًا", fontNote: "ارفع ملف .ttf أو .otf أو .woff، أو الصق رابط Google Fonts (أو أي رابط لملف خط). يبقى الخط على هذا الجهاز.", fontSize: "حجم الخط", fsSmall: "صغير", fsDefault: "افتراضي", fsLarge: "كبير",
      density: "كثافة الواجهة", dnCompact: "مضغوط", dnDefault: "افتراضي", dnComfortable: "مريح",
      appearanceNote: "يُطبَّق على المحادثات والقوائم والإعدادات فورًا.",
      dataPrivacy: "البيانات والخصوصية", exportChats: "تصدير المحادثات", clearChat: "مسح المحادثة", clearHistory: "مسح السجل",
      manageData: "إدارة البيانات المحلية", deleteAllData: "حذف كل البيانات المحلية", dpPrefs: "تفضيلات البيانات والخصوصية",
      dataNote: "كل شيء محفوظ على هذا الجهاز. تُرسل الرسائل إلى خدمة الذكاء الاصطناعي فقط للحصول على الرد.",
      exportNone: "لا توجد محادثات للتصدير", exportDone: "تم تصدير المحادثات", nothingToClear: "لا يوجد ما يُمسح", clearBtn: "مسح",
      clearChatTitle: "مسح هذه المحادثة؟", clearChatMsg: "ستبقى في سلة المحذوفات 30 يومًا ثم تُحذف نهائيًا.", clearChatDone: "تم مسح المحادثة",
      clearHistTitle: "مسح السجل؟", clearHistMsg: "ستنتقل كل المحادثات إلى سلة المحذوفات 30 يومًا ثم تُحذف نهائيًا.", clearHistDone: "تم مسح السجل",
      mdChats: "المحادثات", mdPics: "الصور", mdTrash: "سلة المحذوفات", mdCache: "البيانات المؤقتة", mdEmpty: "لا يوجد ما يُحذف", mdDone: "تم الحذف",
      mdNote: "اضغط على الصور أو سلة المحذوفات أو البيانات المؤقتة لحذفها نهائيًا.",
      mdPicsTitle: "حذف كل الصور؟", mdPicsMsg: "ستُزال الصور من كل المحادثات ولا يمكن استعادتها.",
      mdTrashTitle: "إفراغ سلة المحذوفات؟", mdTrashMsg: "سيُحذف كل ما فيها نهائيًا.",
      mdCacheTitle: "مسح البيانات المؤقتة؟", mdCacheMsg: "ستُزال الأخبار وغيرها من البيانات المؤقتة. محادثاتك تبقى كما هي.",
      delAllTitle: "حذف كل البيانات المحلية؟", delAllMsg: "ستُحذف نهائيًا المحادثات والصور والملف الشخصي والإعدادات والأغاني على هذا الجهاز. لا يمكن التراجع.", delAllBtn: "حذف كل شيء",
      saveHistory: "حفظ سجل المحادثات", saveHistoryNote: "عند الإيقاف لا تُحفظ المحادثات الجديدة على هذا الجهاز.",
      aiTitles: "أسماء المحادثات بالذكاء الاصطناعي", aiTitlesNote: "يقرأ iMa! أول رسائل المحادثة ليختار لها اسمًا.",
      glass: "تأثير الزجاج", glassNote: "أوقفه لاستخدام ضبابية عادية بدل الزجاج.",
      resetGlass: "إعادة ضبط الزجاج", advTools: "أدوات متقدمة", advSoon: "قريباً", musicSearch: "ابحث عن الموسيقى", ytTitle: "يوتيوب", ytSearch: "ابحث في يوتيوب", ytLoading: "جارٍ التحميل…", ytNone: "لا توجد فيديوهات", ytFail: "تعذّر تحميل يوتيوب", mapTitle: "الخريطة", mapSatellite: "قمر صناعي", wxTitle: "الطقس", newsTitle: "الأخبار", newsSearch: "ابحث في الأخبار", newsNone: "لا توجد أخبار", newsFail: "تعذّر تحميل الأخبار", newsRetry: "اضغط لإعادة المحاولة", srchTitle: "بحث", webTitle: "الويب", imgTitle: "الصور", imgSearch: "ابحث عن صور", imgHint: "اكتب بحثك ثم اضغط Enter", imgNone: "لا توجد صور", imgFail: "تعذّر البحث عن الصور", webSearch: "ابحث في الويب", webHint: "اكتب بحثك ثم اضغط Enter", webNone: "لا توجد نتائج", webFail: "تعذّر البحث في الويب", wxSearch: "ابحث عن مدينة", wxHere: "موقعي", wxNone: "لم يُعثر على المدينة", wxFail: "تعذّر تحميل الطقس", mapSearch: "ابحث عن مكان", mapLocate: "موقعي", mapNone: "لم يُعثر على المكان", mapFail: "تعذّر تحميل الخريطة", mapDenied: "الموقع غير متاح", ytClose: "إغلاق الفيديو", trTitle: "ترجمة", trGo: "ترجمة المحادثة", trBack: "عرض الأصل", trWorking: "جارٍ الترجمة…", trOrig: "النص الأصلي", trDone: "تمت الترجمة", trFail: "تعذّرت الترجمة", trEmpty: "لا يوجد ما يُترجم", mpSongs: "الأغاني", mpPick: "الموسيقى", mpLoading: "جارٍ التحميل…", mpNone: "لا توجد أغانٍ", mpOffline: "تعذّر تحميل الموسيقى", mpLocal: "المحلي", mpItunes: "iTunes ٣٠ ث", mpAdd: "إضافة أغانٍ", mpLocalNone: "لم تُضف أغانٍ بعد", mpSearchLocal: "ابحث في أغانيك", mpRemove: "إزالة", mpLocalFail: "تعذّر حفظ الأغاني", glassBlur: "ضبابية الزجاج", glassDark: "عتمة الزجاج", glassOpts: "الزجاج", sheetBtns: "أزرار النوافذ (تم / تحديد)", btnTint: "الطبقة الداخلية: أسود ↔ أبيض", btnEdge: "سمك الزجاج", resetTint: "إعادة ضبط",
      devMode: "وضع المطوّر", aboutIma: "حول iMai", notifyUpdate: "أعلمني عند تحديث iMai", aboutImaNote: "ذكاء اصطناعي من صنع Ivan", aboutImaLocal: "محادثاتك تبقى على هذا الجهاز.", shapes: "الأشكال", pillW: "عرض العنوان", pillH: "ارتفاع العنوان", pillR: "استدارة العنوان", pillS: "نعومة العنوان",
      btnSize: "الأزرار الدائرية", bubbleR: "استدارة الفقاعات", fieldR: "استدارة شريط الرسالة",
      resetShapes: "إعادة ضبط الأشكال", shapesNote: "الحجم والاستدارة بالبكسل مثل CSS. النعومة تحوّل الزوايا إلى زوايا ناعمة.",
      chatTheme: "مظهر المحادثة", background: "الخلفية",
      bgColor: "لون", bgHex: "سداسيات", bgAurora: "الشفق", bgPhoto: "صورة", chatStyle: "نمط المحادثة", styleGpt: "ChatGPT", styleImsg: "iMessage",
      color: "اللون", hexColor: "لون السداسيات", auroraColor: "لون الشفق",
      choosePhoto: "اختيار صورة", changePhoto: "تغيير الصورة", removePhoto: "إزالة",
      photoBlur: "ضبابية الخلفية", removePhotoRow: "إزالة الصورة",
      bgVideo: "فيديو", chooseVideo: "اختيار فيديو", changeVideo: "تغيير الفيديو", removeVideoRow: "إزالة الفيديو",
      videoFail: "تعذّر استخدام هذا الفيديو (الحد 150 ميجابايت)",
      photoFail: "تعذّر استخدام هذه الصورة", customColor: "لون مخصص",
      bubbles: "الفقاعات", bubbleStyle: "النمط", solid: "عادي", blur: "ضبابي",
      myBubbles: "فقاعاتي", imaBubbles: "فقاعات iMa!",
      blurNote: "الفقاعات الضبابية تطمس ما خلفها، وهي ليست زجاجية.",
      enterSends: "زر Enter يرسل", receipts: "إشعارات التسليم",
      enterNote: "إعداد زر Enter يعمل على الحاسوب فقط. على الهاتف يضيف Enter سطرًا جديدًا.",
      rememberAcross: "التذكّر بين المحادثات",
      rememberNote: "عند التشغيل، يمكن لـ iMa! الاحتفاظ بالتفاصيل المفيدة التي تشاركها حتى لا تكررها.",
      aiError: "تعذّر الحصول على إجابة الآن. حاول مرة أخرى.",
      aiBusy: "هناك طلبات كثيرة الآن. انتظر قليلًا ثم حاول مرة أخرى.",
      recent: "الأخيرة", noChats: "لا توجد محادثات بعد", noResults: "لا توجد نتائج", searchChats: "ابحث في المحادثات",
      profile: "الملف الشخصي", profileSoon: "الملف الشخصي قريبًا", chatBusy: "انتظر حتى ينتهي الرد أولًا",
      name: "الاسم", yourName: "اسمك", preferences: "التفضيلات", premium: "iMa! بريميوم",
      profileNote: "يُحفظ ملفك الشخصي على هذا الجهاز فقط. لا حاجة لتسجيل الدخول، والحسابات قادمة لاحقًا.",
      tone: "الأسلوب", toneDefault: "افتراضي", toneFriendly: "ودّي", toneFormal: "رسمي", toneCasual: "عفوي",
      aboutYou: "نبذة عنك", aboutPh: "أي شيء تريد أن يعرفه iMa! عنك: عملك، اهتماماتك، أهدافك…",
      customInstr: "تعليمات مخصصة", instrPh: "كيف تريد أن يرد iMa!؟ مثلًا: اجعل الإجابات قصيرة وأعطِ أمثلة.",
      prefNote: "تُرسل هذه إلى الذكاء الاصطناعي مع رسائلك، وتُحفظ على هذا الجهاز.",
      editProfile: "تعديل الملف الشخصي", createProfile: "إنشاء ملف شخصي", username: "اسم المستخدم", usernamePh: "username",
      usernameNote: "سيتم التحقق من توفر اسم المستخدم عند إضافة الحسابات.",
      adjustPhoto: "ضبط الصورة", usePhoto: "استخدام الصورة", cropHint: "اسحب لتحريك الصورة. قرّب بإصبعين أو بالمنزلق.",
      premiumFeatures: "ميزات بريميوم", perMonth: "/ شهريًا",
      personalInfo: "المعلومات الشخصية", dataSecurity: "البيانات والأمان", subscription: "الاشتراك", personalization: "التخصيص والتفضيلات",
      email: "البريد الإلكتروني", emailPh: "name@example.com", emailNote: "يُحفظ اسمك واسم المستخدم والبريد الإلكتروني على هذا الجهاز فقط، وسيُستخدمون لتسجيل الدخول عند إضافة الحسابات.",
      freePlan: "مجاني", freeDesc: "المحادثة والصور والأدوات الأساسية", currentPlan: "الخطة الحالية", upgrade: "ترقية",
      age: "العمر", agePh: "العمر", persSec: "التخصيص", profileSub: "المعلومات الشخصية والبيانات والاشتراك", dsPrivacy: "الخصوصية",
      baseStyle: "الأسلوب والنبرة الأساسية", baseStyleNote: "حدّد أسلوب ونبرة ردود iMa! عليك. هذا لا يغيّر قدرات iMa!.",
      characteristics: "الخصائص", charNote: "اضبط طريقة إجابة iMa! فوق الأسلوب الأساسي. الافتراضي يُبقي الأسلوب الأساسي.",
      prefWarm: "الودّ", prefEnthusiastic: "الحماس", prefLists: "العناوين والقوائم", prefEmoji: "الإيموجي", prefHumor: "الدعابة", prefLength: "طول الرد", prefExamples: "الأمثلة",
      prefMore: "أكثر", prefLess: "أقل", prefDefault: "افتراضي", prefShorter: "أقصر", prefLonger: "أطول", prefFewer: "أقل",
      stProfessional: "احترافي", stCandid: "صريح", stQuirky: "طريف", stEfficient: "عملي", stNerdy: "متعمّق",
      stSubDefault: "الأسلوب والنبرة المعتادان", stSubFriendly: "دافئ وودود", stSubProfessional: "مصقول ودقيق", stSubCasual: "هادئ وعفوي",
      stSubCandid: "مباشر ومشجّع", stSubQuirky: "مرح وخيالي", stSubEfficient: "مختصر وبسيط", stSubNerdy: "مهتم بالتفاصيل",
      mdPageNote: "اضغط على أي صف لإدارته. تنتقل المحادثات إلى سلة المحذوفات. تُحذف الصور والبيانات المؤقتة نهائيًا. ومن سلة المحذوفات يمكنك استرجاع العناصر أو حذفها واحدًا واحدًا.", storedOn: "مكان التخزين", thisDevice: "هذا الجهاز",
      dsNote: "كل شيء يبقى على هذا الجهاز. لا توجد حسابات أو تخزين على خادم حتى الآن. لا يمكن التراجع عن حذف البيانات.",
      pin: "تثبيت", unpin: "إلغاء التثبيت", rename: "إعادة تسمية", archive: "أرشفة", unarchive: "إلغاء الأرشفة",
      pinned: "المثبّتة", archived: "المؤرشفة", renameChat: "إعادة تسمية المحادثة", chatName: "اسم المحادثة",
      premiumSoon: "التفاصيل والدفع قادمان قريبًا.",
      codePreview: "معاينة الكود", previewBtn: "معاينة", codeTab: "الكود", runTab: "تشغيل", back: "رجوع",
      pasteCode: "الصق كود HTML أو CSS أو JavaScript هنا", nothingToRun: "الصق بعض الكود ثم اضغط تشغيل.",
      oneCode: "كود واحد", separate: "منفصل", webLang: "ويب", separatedOpt: "منفصل", langMenu: "اللغة",
      projects: "المشاريع", noProjects: "الكود الذي يكتبه الذكاء الاصطناعي في محادثاتك يُحفظ هنا تلقائيًا.", delProject: "حذف المشروع", pastePy: "الصق كود Python هنا", pyLoading: "جارٍ تحميل Python…", pasteHtml: "الصق كود HTML هنا", pasteCss: "الصق كود CSS هنا", pasteJs: "الصق كود JavaScript هنا"
    }
  };


  /* =========================================================
     SETTINGS
  ========================================================= */

  const MODELS = [
    { id: "gpt",   name: "GPT-OSS 120B" },
    { id: "north", name: "North Mini Code" }
  ];

  // [value, English name, Arabic name]
  const OUT_COLORS = [
    ["#0a84ff", "Blue", "أزرق"], ["#bf5af2", "Purple", "بنفسجي"], ["#30d158", "Green", "أخضر"],
    ["#ff9f0a", "Orange", "برتقالي"], ["#ff453a", "Red", "أحمر"]
  ];
  const IN_COLORS = [
    ["#262629", "Gray", "رمادي"], ["#3a3a3c", "Graphite", "فحمي"], ["#0f4c5c", "Teal", "فيروزي"],
    ["#5c1a2b", "Wine", "عنابي"], ["#ffffff", "White", "أبيض"]
  ];
  const BG_COLORS = [
    ["#000000", "Black", "أسود"], ["#0b1d3a", "Navy", "كحلي"], ["#2a0f3d", "Plum", "برقوقي"],
    ["#0d2b20", "Forest", "أخضر غامق"], ["#3a0f1a", "Wine", "عنابي"]
  ];
  const HEX_COLORS = [
    ["#00f0ff", "Cyan", "سماوي"], ["#ff2bd6", "Magenta", "أرجواني"], ["#7dff3a", "Lime", "ليموني"],
    ["#ff9f0a", "Orange", "برتقالي"], ["#ffffff", "White", "أبيض"]
  ];
  const AURORA_COLORS = [
    ["#3dffa0", "Green", "أخضر"], ["#00d4ff", "Sky", "سماوي"], ["#a855ff", "Violet", "بنفسجي"],
    ["#ff4fa3", "Pink", "وردي"], ["#ffd60a", "Gold", "ذهبي"]
  ];

  const DEFAULTS = {
    imagine: { style: "none", quality: "sd", ratio: "1:1", improve: false },   // /imagine settings
    lang: "en",
    glass: true,              // false = regular blur instead of glass
    glassBlur: 7,             // px, 0–60 (backdrop blur of glass parts)
    glassDark: 0,             // %, 0–70 (smoke tint of glass parts)
    btnEdge: 1,               // px, 0–8: thickness of the glass rim on the sheet buttons
    btnTint: 18,              // -100 (black) … +100 (white): inner layer of the sheet buttons
    pillW: 67, pillH: 44, pillR: 22, pillS: 40,   // title pill: px, px, px, smoothness 0–100
    btnSize: 36,              // round top buttons, px
    bubbleR: 20,              // message bubble corner, px
    fieldR: 22,               // message bar corner, px
    bg: "color",              // "color" | "hexagons" | "aurora" | "photo" | "video" | "chatgpt"
    bgColor: "#000000",
    photoBlur: 0,             // 0–100: how blurred the background photo is
    hexColor: "#00f0ff",
    auroraColor: "#3dffa0",
    bubbleStyle: "solid",     // "solid" | "blur"
    chatStyle: "imessage",    // "imessage" | "chatgpt"
    accent: "#0a84ff",        // my bubbles
    inColor: "#262629",       // iMa! bubbles
    enterSends: true,
    receipts: true,
    notifyUpdate: false,      // notify me when iMai is updated
    memory: false,
    fontSize: "default",     // "small" | "default" | "large"
    density: "default",      // "compact" | "default" | "comfortable"
    saveHistory: true,
    aiTitles: true
  };

  let settings = { ...DEFAULTS };
  try { Object.assign(settings, JSON.parse(localStorage.getItem("ima-settings") || "{}")); } catch (e) {}
  if (!I18N[settings.lang]) settings.lang = "en";
  // ChatGPT used to be a background option: it is now a chat style, with its own background
  if (settings.bg === "chatgpt") { settings.bg = "color"; settings.chatStyle = "chatgpt"; }
  // v64: new default look (glass blur 7, darkness 0, title width 67) — older saved values are reset once
  if (settings.defaultsV !== 64) {
    settings.glassBlur = DEFAULTS.glassBlur; settings.glassDark = DEFAULTS.glassDark; settings.pillW = DEFAULTS.pillW;
    settings.defaultsV = 64;
    try { localStorage.setItem("ima-settings", JSON.stringify(settings)); } catch (e) {}
  }
  if (settings.bg === "hexagons") settings.bg = "color";     // hexagons are paused for now

  function saveSettings() {
    try { localStorage.setItem("ima-settings", JSON.stringify(settings)); } catch (e) {}
  }

  const isRTL = () => settings.lang === "ar";

  // local profile + personalization (no sign-in yet)
  const PROFILE_KEY = "ima-profile";
  const PREFS_KEY   = "ima-prefs";
  const readJSON = (key) => {
    try { const v = JSON.parse(localStorage.getItem(key) || "{}"); return v && typeof v === "object" ? v : {}; }
    catch (e) { return {}; }
  };
  let profile = Object.assign({ name: "", username: "", email: "", age: "", photo: "" }, readJSON(PROFILE_KEY));
  let prefs   = Object.assign({ tone: "default", about: "", instructions: "", chars: {} }, readJSON(PREFS_KEY));
  if (!prefs.chars || typeof prefs.chars !== "object") prefs.chars = {};
  const STYLE_LINES = {
    friendly: "friendly and warm", professional: "professional and polished", formal: "professional and formal", casual: "casual and relaxed",
    candid: "candid, direct and encouraging", quirky: "playful and imaginative", efficient: "concise and plain, with no filler",
    nerdy: "curious and happy to go deep into the details"
  };
  const CHAR_LINES = {
    warm:         { more: "Be warmer and more personable.", less: "Be less warm; keep a neutral, matter-of-fact manner." },
    enthusiastic: { more: "Be more enthusiastic and energetic.", less: "Be calm and reserved; avoid exclamation marks and hype." },
    lists:        { more: "Use more headers and bullet lists to organize answers.", less: "Avoid headers and bullet lists; answer in plain paragraphs." },
    emoji:        { more: "Use emojis often.", less: "Never use emojis." },
    humor:        { more: "Add light humor where it fits.", less: "Keep a serious tone, without jokes." },
    length:       { more: "Give longer, more detailed answers.", less: "Keep answers short and to the point." },
    examples:     { more: "Include examples whenever they help.", less: "Avoid examples unless asked." }
  };

  function t(key, ...args) {
    const v = (I18N[settings.lang] && I18N[settings.lang][key]) ?? I18N.en[key] ?? key;
    return typeof v === "function" ? v(...args) : v;
  }

  const timeLocale = () => (isRTL() ? "ar-u-nu-latn" : undefined);


  /* ---------- Color helpers ---------- */

  function hexToRgb(hex) {
    let h = String(hex).replace("#", "");
    if (h.length === 3) h = h.split("").map((c) => c + c).join("");
    const n = parseInt(h, 16) || 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  function luminance(hex) {
    const [r, g, b] = hexToRgb(hex).map((v) => {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }

  function hexToHsl(hex) {
    let [r, g, b] = hexToRgb(hex).map((v) => v / 255);
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0;
    const l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return [h, s * 100, l * 100];
  }

  // colors that are too dark to read as a UI accent get lightened
  function readable(hex) {
    if (luminance(hex) >= 0.2) return hex;
    const [r, g, b] = hexToRgb(hex).map((v) => Math.round(v + (255 - v) * 0.6));
    return `rgb(${r}, ${g}, ${b})`;
  }


  /* ---------- Apply theme (bubbles, glass, accent) ---------- */

  function applyTheme() {
    const st = root.style;
    st.setProperty("--bubble-out", settings.accent);
    st.setProperty("--bubble-in", settings.inColor);
    st.setProperty("--out-rgb", hexToRgb(settings.accent).join(", "));
    st.setProperty("--in-rgb", hexToRgb(settings.inColor).join(", "));
    st.setProperty("--out-text", luminance(settings.accent) > 0.5 ? "#000" : "#fff");
    st.setProperty("--in-text", luminance(settings.inColor) > 0.5 ? "#000" : "#fff");
    st.setProperty("--accent", readable(settings.accent));

    const num = (v, d, lo, hi) => { v = Number(v); return Math.max(lo, Math.min(hi, isFinite(v) ? v : d)); };
    st.setProperty("--glass-blur", num(settings.glassBlur, DEFAULTS.glassBlur, 0, 60) + "px");
    st.setProperty("--glass-tint", (num(settings.glassDark, DEFAULTS.glassDark, 0, 70) / 100).toFixed(2));
    const bt = num(settings.btnTint, DEFAULTS.btnTint, -100, 100);
    st.setProperty("--sheet-btn-bg", bt >= 0 ? "rgba(255, 255, 255, " + (bt * 0.004).toFixed(3) + ")" : "rgba(0, 0, 0, " + (-bt * 0.006).toFixed(3) + ")");
    st.setProperty("--sheet-btn-edge", num(settings.btnEdge, DEFAULTS.btnEdge, 0, 8) + "px");
    st.setProperty("--pill-w", num(settings.pillW, DEFAULTS.pillW, 40, 260) + "px");
    st.setProperty("--pill-h", num(settings.pillH, 44, 30, 80) + "px");
    st.setProperty("--pill-radius", num(settings.pillR, 22, 0, 80) + "px");
    st.setProperty("--pill-n", (2 + num(settings.pillS, 40, 0, 100) * 0.035).toFixed(3));
    st.setProperty("--bar-btn", num(settings.btnSize, 36, 28, 56) + "px");
    st.setProperty("--bubble-radius", num(settings.bubbleR, 20, 0, 30) + "px");
    st.setProperty("--field-radius", num(settings.fieldR, 22, 0, 30) + "px");
    if (window.imaPillRefresh) window.imaPillRefresh();

    root.dataset.glass = settings.glass ? "on" : "off";
    root.dataset.bubbles = settings.bubbleStyle === "blur" ? "blur" : "solid";
    root.dataset.fs = ["small", "large"].includes(settings.fontSize) ? settings.fontSize : "default";
    root.dataset.density = ["compact", "comfortable"].includes(settings.density) ? settings.density : "default";
  }


  /* =========================================================
     BACKGROUNDS
  ========================================================= */

  let photoUrl = "";
  let videoUrl = "";

  /* --- photo: stored in IndexedDB (too big for localStorage) --- */
  const photoDB = {
    open() {
      return new Promise((resolve, reject) => {
        if (!window.indexedDB) return reject(new Error("no idb"));
        const r = indexedDB.open("ima", 1);
        r.onupgradeneeded = () => r.result.createObjectStore("kv");
        r.onsuccess = () => resolve(r.result);
        r.onerror = () => reject(r.error);
      });
    },
    async run(mode, fn) {
      const db = await this.open();
      return new Promise((resolve, reject) => {
        const store = db.transaction("kv", mode).objectStore("kv");
        const req = fn(store);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    },
    get()      { return this.run("readonly",  (s) => s.get("bgPhoto")).catch(() => null); },
    set(blob)  { return this.run("readwrite", (s) => s.put(blob, "bgPhoto")).catch(() => null); },
    remove()   { return this.run("readwrite", (s) => s.delete("bgPhoto")).catch(() => null); }
  };

  /* --- video: also kept in IndexedDB (same store as the photo) --- */
  const videoDB = {
    get()      { return photoDB.run("readonly",  (s) => s.get("bgVideo")).catch(() => null); },
    set(blob)  { return photoDB.run("readwrite", (s) => s.put(blob, "bgVideo")).catch(() => null); },
    remove()   { return photoDB.run("readwrite", (s) => s.delete("bgVideo")).catch(() => null); }
  };

  function setVideoUrl(blob) {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    videoUrl = blob ? URL.createObjectURL(blob) : "";
  }

  // make sure the browser can really play the picked video before using it
  function checkVideo(blob) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(blob);
      const v = document.createElement("video");
      const done = (ok) => { clearTimeout(timer); v.removeAttribute("src"); v.load(); URL.revokeObjectURL(url); ok ? resolve() : reject(new Error("bad video")); };
      const timer = setTimeout(() => done(false), 10000);
      v.preload = "metadata";
      v.muted = true;
      v.onloadedmetadata = () => done(true);
      v.onerror = () => done(false);
      v.src = url;
    });
  }

  function setPhotoUrl(blob) {
    if (photoUrl) URL.revokeObjectURL(photoUrl);
    photoUrl = blob ? URL.createObjectURL(blob) : "";
  }

  // shrink big camera pictures so the background stays fast
  async function shrinkImage(file, max = 1600) {
    let bmp;
    try {
      bmp = await createImageBitmap(file);
    } catch (e) {
      bmp = await new Promise((resolve, reject) => {
        const url = URL.createObjectURL(file);
        const img = new Image();
        img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
        img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("bad image")); };
        img.src = url;
      });
    }
    const w = bmp.width || bmp.naturalWidth;
    const h = bmp.height || bmp.naturalHeight;
    const k = Math.min(1, max / Math.max(w, h));
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(w * k));
    c.height = Math.max(1, Math.round(h * k));
    c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
    if (bmp.close) bmp.close();
    return new Promise((resolve, reject) =>
      c.toBlob((b) => (b ? resolve(b) : reject(new Error("encode failed"))), "image/jpeg", 0.86));
  }

  bgFile.addEventListener("change", async () => {
    const file = bgFile.files && bgFile.files[0];
    bgFile.value = "";
    if (!file || !file.type.startsWith("image/")) return;
    try {
      const blob = await shrinkImage(file);
      setPhotoUrl(blob);
      photoDB.set(blob);
      settings.bg = "photo";
      saveSettings();
      applyBackground();
      refreshSettings();
    } catch (e) {
      showToast(t("photoFail"));
    }
  });

  bgVideoFile.addEventListener("change", async () => {
    const file = bgVideoFile.files && bgVideoFile.files[0];
    bgVideoFile.value = "";
    if (!file) return;
    if (!(file.type || "").startsWith("video/") || file.size > 150 * 1024 * 1024) { showToast(t("videoFail")); return; }
    try {
      const blob = new Blob([file], { type: file.type || "video/mp4" });
      await checkVideo(blob);
      setVideoUrl(blob);
      videoDB.set(blob);
      settings.bg = "video";
      saveSettings();
      applyBackground();
      refreshSettings();
    } catch (e) {
      showToast(t("videoFail"));
    }
  });

  function removeVideo() {
    setVideoUrl(null);
    videoDB.remove();
    bgVideoEl.pause();
    bgVideoEl.removeAttribute("src");
    bgVideoEl.load();
    if (settings.bg === "video") settings.bg = "color";
    saveSettings();
    applyBackground();
    refreshSettings();
  }

  // some browsers pause a muted background video when the page is hidden: start it again on return
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && bgEl.dataset.mode === "video") { const p = bgVideoEl.play(); if (p && p.catch) p.catch(() => {}); }
  });

  function removePhoto() {
    setPhotoUrl(null);
    photoDB.remove();
    if (settings.bg === "photo") settings.bg = "color";
    saveSettings();
    applyBackground();
    refreshSettings();
  }

  /* --- hexagons (your neon-hexagons file, running inside the chat) --- */
  const hex = (() => {
    const ctx = bgHexEl.getContext("2d");

    const GROUP_COUNT = 5;
    const HEX_PER_GROUP = 12;
    const HEX_SIZE = 14;
    const SPEED = 0.15;
    const HEX_SPACING = 1.08;
    const GROUP_MARGIN = 120;
    const NEIGHBORS = [[1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1]];

    const still = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let W = 0, H = 0, groups = [], raf = 0, running = false, last = 0, color = "#00f0ff";

    function makeShape() {
      const cells = [[0, 0]];
      const has = (q, r) => cells.some((c) => c[0] === q && c[1] === r);
      while (cells.length < HEX_PER_GROUP) {
        const [bq, br] = cells[Math.floor(Math.random() * cells.length)];
        const [dq, dr] = NEIGHBORS[Math.floor(Math.random() * 6)];
        if (!has(bq + dq, br + dr)) cells.push([bq + dq, br + dr]);
      }
      return cells;
    }

    function drawHex(x, y, r) {
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = Math.PI / 3 * i;
        const px = x + r * Math.cos(a);
        const py = y + r * Math.sin(a);
        i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
      }
      ctx.closePath();
    }

    function makeGroup() {
      const shape = makeShape();
      const angle = Math.random() * Math.PI * 2;
      const gap = HEX_SIZE * HEX_SPACING;
      return {
        shape,
        x: 0, y: 0,
        vx: Math.cos(angle) * SPEED * (0.6 + Math.random() * 0.8),
        vy: Math.sin(angle) * SPEED * (0.6 + Math.random() * 0.8),
        rot: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.0015,
        phase: Math.random() * Math.PI * 2,
        pulse: 1,
        radius: HEX_SIZE + Math.max(...shape.map(([q, r]) =>
          Math.hypot(gap * 1.5 * q, gap * Math.sqrt(3) * (r + q / 2))))
      };
    }

    function size() {
      const r = bgEl.getBoundingClientRect();
      if (!r.width || !r.height) return;
      W = r.width; H = r.height;
      const d = Math.min(window.devicePixelRatio || 1, 2);
      bgHexEl.width = Math.round(W * d);
      bgHexEl.height = Math.round(H * d);
      ctx.setTransform(d, 0, 0, d, 0, 0);

      if (!groups.length) {
        groups = Array.from({ length: GROUP_COUNT }, makeGroup);
        groups.forEach((g, i) => {
          g.x = (W / GROUP_COUNT) * (i + 0.5);
          g.y = H * (0.2 + 0.6 * ((i * 0.37) % 1));
        });
      }
      if (!raf) step(performance.now(), 0);
    }

    function separate() {
      for (let i = 0; i < groups.length; i++) {
        for (let j = i + 1; j < groups.length; j++) {
          const a = groups[i], b = groups[j];
          let dx = b.x - a.x, dy = b.y - a.y;
          const d = Math.hypot(dx, dy) || 1;
          const minDist = a.radius + b.radius + GROUP_MARGIN;
          if (d < minDist) {
            const push = (minDist - d) * 0.02;
            dx /= d; dy /= d;
            a.x -= dx * push; a.y -= dy * push;
            b.x += dx * push; b.y += dy * push;
          }
        }
      }
    }

    function step(now, k) {
      ctx.clearRect(0, 0, W, H);
      separate();

      const gap = HEX_SIZE * HEX_SPACING;
      const m = 80;

      for (const g of groups) {
        g.x += g.vx * k;
        g.y += g.vy * k;
        g.rot += g.rotSpeed * k;
        if (g.x < -m) g.x = W + m;
        if (g.x > W + m) g.x = -m;
        if (g.y < -m) g.y = H + m;
        if (g.y > H + m) g.y = -m;
        g.pulse = 0.65 + 0.35 * Math.sin(now * 0.001 + g.phase);

        ctx.save();
        ctx.translate(g.x, g.y);
        ctx.rotate(g.rot);
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.6;
        ctx.shadowColor = color;
        ctx.shadowBlur = 14 * g.pulse;
        ctx.globalAlpha = 0.55 + 0.45 * g.pulse;
        for (const [q, r] of g.shape) {
          drawHex(gap * 1.5 * q, gap * Math.sqrt(3) * (r + q / 2), HEX_SIZE);
          ctx.stroke();
          ctx.stroke();
        }
        ctx.restore();
      }
    }

    function loop(now) {
      const k = Math.min((now - last) / 16.67, 3);   // same speed on 60 / 90 / 120 Hz screens
      last = now;
      step(now, k);
      raf = requestAnimationFrame(loop);
    }

    function start() {
      if (running) return;
      running = true;
      size();
      if (still) return;
      last = performance.now();
      raf = requestAnimationFrame(loop);
    }

    function stop() {
      running = false;
      cancelAnimationFrame(raf);
      raf = 0;
    }

    function setColor(c) {
      color = c;
      if (running && !raf) step(performance.now(), 0);
    }

    document.addEventListener("visibilitychange", () => {
      if (!running || still) return;
      cancelAnimationFrame(raf);
      raf = 0;
      if (!document.hidden) { last = performance.now(); raf = requestAnimationFrame(loop); }
    });

    if ("ResizeObserver" in window) new ResizeObserver(() => { if (running) size(); }).observe(bgEl);

    return { start, stop, setColor };
  })();

  /* --- apply the chosen background --- */
  // blur the background photo (slider 0–100 → 0–30px); the layer is enlarged so blurred edges never show
  function applyPhotoBlur() {
    const b = Math.max(0, Math.min(100, Number(settings.photoBlur) || 0)) * 0.3;
    bgPhotoEl.style.filter = b ? `blur(${b}px)` : "";
    bgPhotoEl.style.inset = b ? `${-Math.ceil(b * 3)}px` : "";
    const pad = Math.ceil(b * 3);
    bgVideoEl.style.filter = b ? `blur(${b}px)` : "";
    bgVideoEl.style.left = bgVideoEl.style.top = b ? `${-pad}px` : "";
    bgVideoEl.style.width = bgVideoEl.style.height = b ? `calc(100% + ${pad * 2}px)` : "";
  }

  function applyBackground() {
    let mode = settings.bg;
    if (mode === "photo" && !photoUrl) mode = "color";
    if (mode === "video" && !videoUrl) mode = "color";

    bgEl.dataset.mode = mode;
    root.dataset.chat = settings.chatStyle === "chatgpt" ? "gpt" : "";
    root.style.setProperty("--chat-bg", settings.bgColor);

    // aurora: three hues around the picked color
    const [h, s] = hexToHsl(settings.auroraColor);
    const sat = Math.max(70, Math.min(100, s));
    bgAurora.style.setProperty("--au1", `hsla(${h}, ${sat}%, 55%, 0.62)`);
    bgAurora.style.setProperty("--au2", `hsla(${(h + 42) % 360}, ${sat}%, 58%, 0.5)`);
    bgAurora.style.setProperty("--au3", `hsla(${(h + 318) % 360}, ${sat}%, 52%, 0.42)`);

    bgPhotoEl.style.backgroundImage = mode === "photo" ? `url("${photoUrl}")` : "none";
    applyPhotoBlur();

    if (mode === "video") {
      if (bgVideoEl.getAttribute("src") !== videoUrl) bgVideoEl.src = videoUrl;
      bgVideoEl.muted = true;
      const p = bgVideoEl.play();
      if (p && p.catch) p.catch(() => {});
    } else if (!bgVideoEl.paused) {
      bgVideoEl.pause();
    }

    hex.setColor(settings.hexColor);
    if (mode === "hexagons") hex.start(); else hex.stop();

    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", mode === "color" ? settings.bgColor : "#000000");
  }


  /* =========================================================
     LANGUAGE
  ========================================================= */

  function translateStatic() {
    document.querySelectorAll("[data-i18n]").forEach((n) => { n.textContent = t(n.dataset.i18n); });
    document.querySelectorAll("[data-i18n-aria]").forEach((n) => { n.setAttribute("aria-label", t(n.dataset.i18nAria)); });
    document.querySelectorAll(".stamp").forEach(renderStamp);
    const ms = document.getElementById("musicSearch");
    if (ms) ms.placeholder = t("musicSearch");
    if (window.imaMusicRefresh) window.imaMusicRefresh();
    if (window.imaTrRefresh) window.imaTrRefresh();
    if (window.imaMapRefresh) window.imaMapRefresh();
    if (window.imaWxRefresh) window.imaWxRefresh();
    if (window.imaNewsRefresh) window.imaNewsRefresh();
    if (window.imaWebRefresh) window.imaWebRefresh();
    if (window.imaImgRefresh) window.imaImgRefresh();
    updatePlaceholder();
  }

  function applyLang() {
    root.lang = settings.lang;
    root.dir = isRTL() ? "rtl" : "ltr";
    translateStatic();
    renderModes();
    refreshProfileRow();
  }

  function updatePlaceholder() {
    input.placeholder = modes.image ? t("describeImage") : t("message");
  }


  /* =========================================================
     CHAT STATE
  ========================================================= */

  let model = "gpt";
  // custom models the user added (OpenAI-compatible endpoint + key), kept on this device only
  const CM_KEY = "ima-custom-models";
  let customModels = [];
  try { const a = JSON.parse(localStorage.getItem(CM_KEY) || "[]"); if (Array.isArray(a)) customModels = a.filter((x) => x && x.id && x.url && x.modelId); } catch (e) {}
  const saveCustomModels = () => { try { localStorage.setItem(CM_KEY, JSON.stringify(customModels)); } catch (e) {} };
  const allModels = () => MODELS.concat(customModels.map((c) => ({ id: c.id, name: c.name || c.modelId })));
  // the header always shows the iMa! logo
  function applyModelLogo() {
    const img = document.querySelector(".brand .ico-logo");
    if (!img) return;
    img.src = "assets/icons/logo.png";
    img.alt = "iMa!";
  }
  applyModelLogo();
  const modes = { think: false, deep: false, image: false, tool: "" };   // image: on while the box starts with /imagine; tool: "weather" | "news" | "search" | "images" | "map"
  const CMD_RE = /^\/(imagine|weather|news|map)(?=\s|$)/i;
  let pickedCmd = "";   // a command chosen from the "/" list sits alone (no space) until you type after it
  const cmdMatch = (v) => { const m = CMD_RE.exec(v); return m && (/^\/\S+\s/.test(v) || (pickedCmd && v.toLowerCase() === "/" + pickedCmd)) ? m : null; };
  const CMD_HINT = { imagine: "cmdImagineHint", weather: "cmdWeatherHint", news: "cmdNewsHint", search: "cmdSearchHint", images: "cmdImagesHint", map: "cmdMapHint" };
  const TOOL_OPTIONAL = new Set(["weather", "news"]);   // these work with an empty box (my location / top stories)
  // the command word is shown in blue: a mirror of the text sits on top of the (then transparent) textarea
  const taWrap = el("div", "ta-wrap");
  const taMirror = el("div", "ta-mirror");
  taMirror.setAttribute("aria-hidden", "true");
  input.parentNode.insertBefore(taWrap, input);
  taWrap.append(input, taMirror);
  input.addEventListener("scroll", () => { taMirror.scrollTop = input.scrollTop; });
  function syncCommand() {
    const m = cmdMatch(input.value);
    const cmdName = m ? m[1].toLowerCase() : "";
    const wasImage = modes.image;
    modes.image = cmdName === "imagine";
    modes.tool = m && !modes.image ? cmdName : "";
    if (modes.image !== wasImage) { if (modes.image) openImagine(); else closeImagine(); }
    taWrap.classList.toggle("has-cmd", !!m);
    taMirror.textContent = "";
    if (!m) return;
    const cs = getComputedStyle(input);
    ["fontFamily", "fontSize", "fontWeight", "lineHeight", "letterSpacing", "paddingTop", "paddingRight", "paddingBottom", "paddingLeft", "textAlign"]
      .forEach((k) => { taMirror.style[k] = cs[k]; });
    const rest = input.value.slice(m[0].length);
    const w = el("span", "cmd-word"); w.textContent = m[0];
    taMirror.append(w, document.createTextNode(rest));
    if (!rest.trim()) { const h = el("span", "cmd-hint"); h.textContent = t(CMD_HINT[cmdName] || "cmdImagineHint"); taMirror.appendChild(h); }
    else taMirror.appendChild(document.createTextNode("\u200b"));
    taMirror.scrollTop = input.scrollTop;
  }

  /* ---------- Imagine settings: glass panel above the message box while /imagine is active ---------- */
  const IG_STYLES = [
    { id: "none",       en: "None",       ar: "بدون",       bg: "linear-gradient(135deg,#3a3a40,#1c1c20)", hint: "" },
    { id: "anime",      en: "Anime",      ar: "أنمي",       bg: "linear-gradient(135deg,#ff7eb3,#7a5cff)", hint: "anime style, vibrant colors, clean line art, detailed cel shading" },
    { id: "cinematic",  en: "Cinematic",  ar: "سينمائي",    bg: "linear-gradient(135deg,#f6b73c,#2a3a5c)", hint: "cinematic film still, dramatic lighting, shallow depth of field, anamorphic lens, color graded" },
    { id: "photo",      en: "Photo",      ar: "واقعي",      bg: "linear-gradient(135deg,#8fd3f4,#4a6b52)", hint: "ultra realistic photograph, natural lighting, sharp focus, 85mm lens, high detail" },
    { id: "3d",         en: "3D",         ar: "ثلاثي الأبعاد", bg: "linear-gradient(135deg,#7be0c3,#3b6fd8)", hint: "3D render, Pixar-style, soft global illumination, smooth materials, highly detailed" },
    { id: "watercolor", en: "Watercolor", ar: "ألوان مائية", bg: "linear-gradient(135deg,#ffd6a5,#a0c4ff)", hint: "watercolor painting, soft washes, paper texture, delicate brush strokes" },
    { id: "pixel",      en: "Pixel",      ar: "بكسل",       bg: "linear-gradient(135deg,#6ee7a8,#1d4d3a)", hint: "pixel art, 16-bit retro game style, crisp pixels, limited color palette" },
    { id: "cyberpunk",  en: "Cyberpunk",  ar: "سايبربانك",  bg: "linear-gradient(135deg,#ff2bd6,#0fd6ff)", hint: "cyberpunk, neon lights, rainy futuristic city, high contrast, glowing accents" },
    { id: "fantasy",    en: "Fantasy",    ar: "فانتازيا",   bg: "linear-gradient(135deg,#c9a7ff,#2e1f5e)", hint: "epic fantasy illustration, magical atmosphere, intricate details, painterly" },
    { id: "sketch",     en: "Sketch",     ar: "رسم",        bg: "linear-gradient(135deg,#e9e9e9,#8a8a8a)", hint: "pencil sketch, detailed hand-drawn linework, graphite shading on paper" },
    { id: "oil",        en: "Oil paint",  ar: "زيتي",       bg: "linear-gradient(135deg,#e0a458,#6b3e26)", hint: "oil painting, rich textured brush strokes, classical composition, warm tones" }
  ];
  const IG_RATIOS = ["2:3", "3:2", "1:1", "9:16", "16:9"];
  function imagineOpts() { return Object.assign({ style: "none", quality: "sd", ratio: "1:1", improve: false }, settings.imagine); }
  function setImagine(patch) { settings.imagine = Object.assign(imagineOpts(), patch); saveSettings(); }

  // slide the pill thumb under a button (animate = false puts it there instantly)
  function moveThumb(thumb, btn, animate) {
    if (!thumb || !btn) return;
    if (!animate) thumb.style.transition = "none";
    thumb.style.width = btn.offsetWidth + "px";
    thumb.style.transform = "translateX(" + btn.offsetLeft + "px)";
    if (!animate) { void thumb.offsetWidth; thumb.style.transition = ""; }
  }

  let igPanel = null;
  let igFit = null;
  const IG_EASE = "cubic-bezier(0.34, 1.2, 0.5, 1)";
  function closeImagine(now) {
    if (igFit) { window.removeEventListener("resize", igFit); igFit = null; }
    const p = igPanel; igPanel = null;
    if (!p) return;
    if (now === true || matchMedia("(prefers-reduced-motion: reduce)").matches) { p.remove(); return; }
    p.style.overflow = "hidden"; p.style.pointerEvents = "none";
    const h = p.getBoundingClientRect().height;
    const an = p.animate(
      [{ height: h + "px", opacity: 1, paddingTop: "6px", paddingBottom: "14px", marginBottom: "6px" },
       { height: "0px", opacity: 0, paddingTop: "0px", paddingBottom: "0px", marginBottom: "0px" }],
      { duration: 280, easing: "cubic-bezier(0.4, 0, 0.6, 1)", fill: "forwards" });
    an.onfinish = () => p.remove();
    setTimeout(() => p.remove(), 450);
  }
  function openImagine() {
    closeImagine(true);
    const o = imagineOpts();
    const ar = document.documentElement.dir === "rtl";
    const panel = el("div", "imagine-panel material");
    panel.addEventListener("pointerdown", (e) => { if (!e.target.closest(".ig-styles")) e.preventDefault(); });   // keep the keyboard open

    const head = el("div", "ig-head");
    const title = el("div", "ig-title"); title.textContent = t("igTitle");
    const x = el("button", "ig-x"); x.type = "button"; x.setAttribute("aria-label", t("close") || "Close");
    x.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
    x.addEventListener("click", () => closeImagine());
    const ok = el("button", "ig-ok"); ok.type = "button"; ok.setAttribute("aria-label", t("done") || "Done");
    ok.innerHTML = '<i class="ig-check" aria-hidden="true"></i>';
    ok.addEventListener("click", () => closeImagine());
    head.append(x, title, ok);

    // styling presets: names only, one scrollable pill with a sliding thumb (same feel as Quality)
    const presets = el("div", "ig-styles");
    const sTrack = el("div", "ig-styles-track");
    const sThumb = el("i", "ig-thumb"); sThumb.setAttribute("aria-hidden", "true");
    sTrack.appendChild(sThumb);
    const sBtns = [];
    IG_STYLES.forEach((st) => {
      const b = el("button", o.style === st.id ? "on" : "");
      b.type = "button"; b.textContent = ar ? st.ar : st.en;
      b.addEventListener("click", () => {
        setImagine({ style: st.id });
        sBtns.forEach((n) => n.classList.toggle("on", n === b));
        moveThumb(sThumb, b, true);
        b.scrollIntoView({ inline: "center", block: "nearest", behavior: "smooth" });
      });
      sBtns.push(b);
      sTrack.appendChild(b);
    });
    presets.appendChild(sTrack);

    // quality: SD / HD
    const qRow = el("div", "ig-row");
    const ql = el("span", "ig-label"); ql.textContent = t("igQuality");
    const qSeg = el("div", "ig-seg");
    const qThumb = el("i", "ig-thumb"); qThumb.setAttribute("aria-hidden", "true");
    qSeg.appendChild(qThumb);
    const qBtns = [];
    ["sd", "hd"].forEach((q) => {
      const b = el("button", q === o.quality ? "on" : ""); b.type = "button"; b.textContent = q.toUpperCase();
      b.addEventListener("click", () => {
        setImagine({ quality: q });
        qBtns.forEach((n) => n.classList.toggle("on", n === b));
        moveThumb(qThumb, b, true);
      });
      qBtns.push(b);
      qSeg.appendChild(b);
    });
    qRow.append(ql, qSeg);

    // aspect ratio
    const rCard = el("div", "ig-card");
    const rt = el("div", "ig-label"); rt.textContent = t("igRatio");
    const rs = el("div", "ig-sub"); rs.textContent = t("igRatioSub");
    const rList = el("div", "ig-ratios");
    IG_RATIOS.forEach((r) => {
      const [w, h] = r.split(":").map(Number);
      const k = 42 / Math.max(w, h);
      const b = el("button", "ig-ratio" + (o.ratio === r ? " on" : "")); b.type = "button";
      const box = el("span", "ig-box");
      const shape = el("i"); shape.style.width = Math.round(w * k) + "px"; shape.style.height = Math.round(h * k) + "px";
      box.appendChild(shape);
      const lb = el("em"); lb.textContent = r;
      b.append(box, lb);
      b.addEventListener("click", () => {
        setImagine({ ratio: r });
        rList.querySelectorAll(".ig-ratio").forEach((n) => n.classList.toggle("on", n === b));
      });
      rList.appendChild(b);
    });
    rCard.append(rt, rs, rList);

    // improve with AI prompt
    const iRow = el("div", "ig-row ig-improve");
    const il = el("span", "ig-label"); il.textContent = t("igImprove");
    iRow.append(il, toggle(!!o.improve, (v) => setImagine({ improve: v }), t("igImprove")));

    panel.append(head, presets, qRow, rCard, iRow);
    const field = composer.querySelector(".field");
    field.insertBefore(panel, field.firstChild);   // inside the message box: same glass, no gap
    igPanel = panel;
    igFit = () => {   // keep the panel inside the free room above the box (keyboard open = less room)
      const bar = document.querySelector(".topbar");
      const top = (bar ? bar.getBoundingClientRect().bottom : 70) + 8;
      const fr = field.getBoundingClientRect();
      const other = fr.height - panel.getBoundingClientRect().height;
      panel.style.maxHeight = Math.max(160, Math.floor(fr.bottom - top - other - 8)) + "px";
    };
    igFit();
    window.addEventListener("resize", igFit);
    // put the thumbs under the current choice (no animation on open)
    const place = () => {
      moveThumb(sThumb, sBtns.find((n) => n.classList.contains("on")) || sBtns[0], false);
      moveThumb(qThumb, qBtns.find((n) => n.classList.contains("on")) || qBtns[0], false);
      const cur = sBtns.find((n) => n.classList.contains("on"));
      if (cur) presets.scrollLeft = 0, cur.scrollIntoView({ inline: "center", block: "nearest" });
    };
    place();
    if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
      const h = panel.getBoundingClientRect().height;
      panel.style.overflow = "hidden";
      const an = panel.animate(
        [{ height: "0px", opacity: 0, paddingTop: "0px", paddingBottom: "0px", marginBottom: "0px" },
         { height: h + "px", opacity: 1, paddingTop: "6px", paddingBottom: "14px", marginBottom: "6px" }],
        { duration: 440, easing: IG_EASE });
      an.onfinish = () => { panel.style.overflow = ""; };
    }
    requestAnimationFrame(place);
  }
  let replyTo = null;    // message being replied to: { text, role }
  let editing = null;    // your own message being edited (it is sent again, replacing it)

  let pending = [];      // pictures waiting to be sent: { url }
  let uploads = [];      // pictures already sent in this chat
  let removedWeb = new Set();   // web photos the user deleted from Uploaded files (kept out of the open chat's next save)
  let selMode = false;          // drawer: choosing chats to delete
  const selSet = new Set();
  let history = [];      // transcript for "Share chat"
  let chatId = null;     // id of the open chat inside the saved recent chats
  let chatTs = 0;        // when that chat started
  let busy = false;      // true while iMa! is "typing"
  let lastMsg = null;
  let receipt = null;
  let typingEl = null;


  /* ---------- AI reply: GPT-OSS 120B (main mind) + Qwen (eyes) ----------
     Qwen looks at the pictures and writes private notes. GPT receives the
     user's message + those notes and writes the only reply the chat shows.
     The secret keys now live on the backend (.env), not in the browser. */
  const GROQ_URL   = (window.IMA_API || "") + "/api/groq/";   // the backend adds the secret key
  const GPT_KEY    = "gpt";     // not a key: the name of the key slot on the backend
  const GPT_MODEL  = "openai/gpt-oss-120b";
  const QWEN_KEY   = "qwen";
  const QWEN_MODEL = "qwen/qwen3.8-27b";

  // Cloudflare Workers AI (FLUX image generation)
      const CF_MODEL   = "@cf/black-forest-labs/flux-1-schnell";
  const CF_URL     = (window.IMA_API || "") + "/api/image";

  // Reserp (web + image search for Deep search)
    const RESERP_URL = (window.IMA_API || "") + "/api/serp";

  // Cohere (North Mini Code)
    const COHERE_MODEL = "north-mini-code-1-0";
  const COHERE_URL   = (window.IMA_API || "") + "/api/cohere";

  const SYSTEM_PROMPT =
    "You are iMa!, a warm and helpful AI assistant inside a chat app. " +
    "Always reply in the language the user writes in (English, Arabic, or a natural mix if they mix). " +
    "You may use simple markdown: **bold**, short lists, and fenced code blocks with a language tag for any code. " +
    "Do not use tables, and use headings only when they really help. " +
    "Write math in LaTeX: \\( ... \\) for inline formulas and \\[ ... \\] for displayed equations. " +
    "Be clear and conversational. " +
    "Pictures reach you as written notes inside [Picture notes] blocks in the user's message. " +
    "Treat those notes as what you see with your own eyes. Never mention notes, analysis, a vision model, or any other assistant. " +
    "Just answer naturally, as if you looked at the picture yourself. " +
    "If the notes say something is unclear or could not be analyzed, say so honestly instead of guessing. " +
    "Sometimes the user's message ends with a [Live data] block that was fetched a moment ago for them (weather, news, web results, pictures or a map). " +
    "Treat it as real, current information: base your answer on it and never invent details it does not contain. " +
    "Never mention tools, APIs, blocks or fetching; name a source in plain words when it helps.";

  // the user's profile name + preferences, added to every system prompt
  function personalPrompt() {
    const bits = [];
    if (profile.name && profile.name.trim()) bits.push("The user's name is " + profile.name.trim() + ".");
    const tone = STYLE_LINES[prefs.tone];
    if (tone) bits.push("Use a " + tone + " tone.");
    Object.keys(CHAR_LINES).forEach((k) => { const l = CHAR_LINES[k][(prefs.chars || {})[k]]; if (l) bits.push(l); });
    if (prefs.about && prefs.about.trim()) bits.push("About the user: " + prefs.about.trim());
    if (prefs.instructions && prefs.instructions.trim()) bits.push("The user's own instructions for how to answer (follow them): " + prefs.instructions.trim());
    return bits.length ? "\n\nPersonalization:\n" + bits.join("\n") : "";
  }
  const systemPrompt = () => SYSTEM_PROMPT + personalPrompt();

  let convo = [];        // what GPT sees: [{ role: "user" | "assistant", content }]

  const cleanText = (v) => String(v || "").replace(/<think>[\s\S]*?<\/think>/gi, "").trim();

  // one Groq request -> the assistant message object
  async function groqRequest(key, body, ms) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), ms);
    try {
      const res = await fetch(GROQ_URL + key, {
        method: "POST",
        signal: ctl.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      let data = null;
      try { data = await res.json(); } catch (e) {}
      if (!res.ok) {
        const err = new Error((data && data.error && data.error.message) || ("HTTP " + res.status));
        err.status = res.status;
        throw err;
      }
      const msg = data && data.choices && data.choices[0] && data.choices[0].message;
      if (!msg) throw new Error("Empty response");
      return msg;
    } finally {
      clearTimeout(timer);
    }
  }

  // same request, text answer only
  async function groq(key, body, ms) {
    const msg = await groqRequest(key, body, ms);
    const out = cleanText(msg.content);
    if (!out) throw new Error("Empty response");
    return out;
  }

  // one Cohere request -> the assistant message object
  async function cohereRequest(body, ms) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), ms);
    try {
      const res = await fetch(COHERE_URL, {
        method: "POST",
        signal: ctl.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      let data = null;
      try { data = await res.json(); } catch (e) {}
      if (!res.ok) {
        const err = new Error((data && (data.message || (data.error && data.error.message))) || ("HTTP " + res.status));
        err.status = res.status;
        throw err;
      }
      if (!data || !data.message) throw new Error("Empty response");
      return data.message;
    } finally {
      clearTimeout(timer);
    }
  }

  /* One chat step with whichever model is selected (GPT-OSS 120B or North Mini Code).
     Resolves to { text, calls, assistant } where
       calls     = tool calls the model asked for (may be empty)
       assistant = the assistant message to put back into the conversation */
  // normalise what the user typed into the full chat-completions URL
  function cmUrl(u) {
    u = String(u || "").trim().replace(/\/+$/, "");
    if (/\/chat\/completions$/i.test(u)) return u;
    if (/\/v\d+(beta)?$/i.test(u) || /\/openai$/i.test(u)) return u + "/chat/completions";
    return u + "/v1/chat/completions";
  }
  async function customRequest(cm, body, ms) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), ms);
    try {
      const headers = { "Content-Type": "application/json" };
      if (cm.key) headers["Authorization"] = "Bearer " + cm.key;
      const res = await fetch(cmUrl(cm.url), { method: "POST", signal: ctl.signal, headers, body: JSON.stringify(body) });
      let data = null;
      try { data = await res.json(); } catch (e) {}
      if (!res.ok) {
        const err = new Error((data && ((data.error && (data.error.message || data.error)) || data.message)) || ("HTTP " + res.status));
        err.status = res.status;
        throw err;
      }
      const msg = data && data.choices && data.choices[0] && data.choices[0].message;
      if (!msg) throw new Error("Empty response");
      return msg;
    } finally {
      clearTimeout(timer);
    }
  }

  async function chatStep({ messages, tools = null, force = false, temperature = 0.7, maxTokens = 4096 }) {
    const cm = customModels.find((c) => c.id === model);
    if (cm) {
      const body = { model: cm.modelId, messages, temperature, max_tokens: maxTokens, stream: false };
      if (tools) { body.tools = tools; body.tool_choice = force ? "required" : "auto"; }
      let msg;
      try { msg = await customRequest(cm, body, 90000); }
      catch (e) {
        if (tools && [400, 404, 422].includes(e.status)) { delete body.tools; delete body.tool_choice; msg = await customRequest(cm, body, 90000); }   // model without tool support: plain answer
        else throw e;
      }
      const calls = msg.tool_calls || [];
      const assistant = { role: "assistant", content: msg.content || null };
      if (calls.length) assistant.tool_calls = calls;
      return { text: cleanText(msg.content), calls, assistant };
    }
    if (model === "north") {
      const body = { model: COHERE_MODEL, messages, temperature: Math.min(temperature, 1), max_tokens: maxTokens };
      if (tools) { body.tools = tools; body.tool_choice = force ? "REQUIRED" : "AUTO"; }
      const msg = await cohereRequest(body, 90000);
      const text = cleanText((msg.content || []).map((c) => (c && c.type !== "thinking" && c.text) || "").join("\n"));
      const calls = msg.tool_calls || [];
      const assistant = { role: "assistant", tool_calls: calls };
      if (msg.tool_plan) assistant.tool_plan = msg.tool_plan;
      return { text, calls, assistant };
    }
    const body = { model: GPT_MODEL, messages, temperature, max_completion_tokens: maxTokens, stream: false };
    if (tools) { body.tools = tools; body.tool_choice = force ? "required" : "auto"; }
    const msg = await groqRequest(GPT_KEY, body, 90000);
    const calls = msg.tool_calls || [];
    return { text: cleanText(msg.content), calls, assistant: { role: "assistant", content: msg.content || null, tool_calls: calls } };
  }

  // a tool result, in the format of the selected model
  const toolMessage = (tc, result) => model === "north"
    ? { role: "tool", tool_call_id: tc.id, content: [{ type: "document", document: { data: JSON.stringify(result) } }] }
    : { role: "tool", tool_call_id: tc.id, name: tc.function.name, content: JSON.stringify(result) };

  // blob: URL -> smaller JPEG data URL (keeps requests light and fast)
  async function toDataUrl(src) {
    const blob  = await (await fetch(src)).blob();
    const small = await shrinkImage(blob, 1600);
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = () => reject(new Error("Could not read image"));
      r.readAsDataURL(small);
    });
  }

  // Qwen: one picture in, plain-text notes out
  async function describePicture(src, userText) {
    const dataUrl = await toDataUrl(src);
    const ask =
      "Analyze this image carefully. Identify visible objects, text (transcribe it exactly, in its original language), " +
      "colors, layout, and subtle details. If it is a user interface, explain its design accurately. " +
      "Do not invent anything. Be precise and concise." +
      (userText ? "\nThe user's message about it (only to know what to focus on): " + userText : "");
    return groq(QWEN_KEY, {
      model: QWEN_MODEL,
      messages: [{ role: "user", content: [
        { type: "text", text: ask },
        { type: "image_url", image_url: { url: dataUrl } }
      ] }],
      max_completion_tokens: 700,
      temperature: 0.2,
      stream: false
    }, 45000);
  }

  async function pictureNotes(images, userText) {
    const list = images.slice(0, 5);
    const notes = await Promise.all(list.map((src) =>
      describePicture(src, userText).catch((e) => { console.error("[iMa! vision]", e); return ""; })
    ));
    const lines = notes.map((n, i) =>
      "Picture " + (i + 1) + ": " + (n || "(could not be analyzed)"));
    if (images.length > list.length) lines.push("(" + (images.length - list.length) + " more picture(s) were not analyzed.)");
    return "[Picture notes]\n" + lines.join("\n\n") + "\n[End of picture notes]";
  }

  /* ---------- Deep search: GPT decides when to search the web ---------- */

  const isGoogleUrl = (v) => { try { return /(^|\.)google\./i.test(new URL(v).hostname); } catch (e) { return true; } };
  const domainOf = (v) => { try { return new URL(v).hostname.replace(/^www\./, ""); } catch (e) { return ""; } };
  const safeUrl = (v) => {
    if (!v || typeof v !== "string") return "";
    try { const u = new URL(v); return (u.protocol === "https:" || u.protocol === "http:") ? u.href : ""; } catch (e) { return ""; }
  };

  async function requestSerp(query, type) {
    const params = new URLSearchParams();
    params.set("q", query);
    params.set("gl", "us");
    params.set("hl", /[\u0600-\u06FF]/.test(query) ? "ar" : "en");
    params.set("safe", "active");
    if (type === "images") params.set("udm", "2");

    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 30000);
    try {
      const res = await fetch(RESERP_URL, {
        method: "POST",
        signal: ctl.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: "https://www.google.com/search?" + params.toString() })
      });
      const raw = await res.text();
      let data;
      try { data = JSON.parse(raw); } catch (e) { throw new Error("Unreadable search response (HTTP " + res.status + ")"); }
      if (!res.ok || data.ok === false) {
        const detail = data.message || (data.error && data.error.message) || data.error || data.detail || ("HTTP " + res.status);
        throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail).slice(0, 200));
      }
      return Array.isArray(data.blocks) ? data.blocks : [];
    } finally {
      clearTimeout(timer);
    }
  }

  function serpItems(blocks, type) {
    const wanted = type === "images" ? ["images"] : ["organic", "featured_snippet", "knowledge_panel"];
    const out = [];

    for (const block of blocks) {
      if (!wanted.includes(block.type)) continue;
      const list = Array.isArray(block.items) ? block.items : [];
      for (const item of list) out.push({ ...item, _blockTitle: block.title, _blockText: block.text, _blockDomain: block.domain });
      if (!list.length && (block.url || block.image_url) && (block.title || block.text)) out.push({ ...block });
    }

    // fallback: any useful link, in case a different block type comes back
    if (!out.length && type !== "images") {
      for (const block of blocks) {
        if (block.url && !["navigation", "consent", "notice"].includes(block.type)) out.push({ ...block });
        for (const link of (block.links || [])) {
          if (link.url && !isGoogleUrl(link.url)) {
            out.push({ title: link.text || link.title || link.url, url: link.url, snippet: block.text, domain: domainOf(link.url) });
          }
        }
      }
    }

    const seen = new Set();
    return out.filter((it) => {
      const key = it.url || it.image_url || it.title;
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  async function toolWebSearch(query) {
    const items = serpItems(await requestSerp(query, "web"), "web").slice(0, 6);
    if (!items.length) return { results: [], note: "No results found." };
    return {
      results: items.map((it) => ({
        title: it.title || it.name || it._blockTitle || "",
        source: it.source || it.domain || it._blockDomain || domainOf(safeUrl(it.url)),
        snippet: String(it.snippet || it.description || it.text || it._blockText || "").slice(0, 320),
        url: safeUrl(it.url || it.link)
      }))
    };
  }

  // returns the tool result for GPT; the picture links go into photoBag for the chat
  async function toolImageSearch(query, photoBag) {
    const items = serpItems(await requestSerp(query, "images"), "images").slice(0, 10);
    const urls = [];
    items.forEach((it) => {
      const u = safeUrl(it.image_url || it.image || it.thumbnail_url || it.thumbnail);
      if (u && !photoBag.includes(u)) { photoBag.push(u); urls.push(u); }
    });
    return {
      found: items.length,
      note: items.length
        ? "Photos were found and will be shown to the user right above your reply."
        : "No photos found.",
      titles: items.slice(0, 5).map((it) => it.title || it.name || "").filter(Boolean)
    };
  }

  // keep only pictures the browser can really load (some sites block hotlinking)
  function canLoadPhoto(url) {
    return new Promise((resolve) => {
      const im = new Image();
      im.referrerPolicy = "no-referrer";
      const timer = setTimeout(() => resolve(false), 7000);
      im.onload  = () => { clearTimeout(timer); resolve(im.naturalWidth > 80); };
      im.onerror = () => { clearTimeout(timer); resolve(false); };
      im.src = url;
    });
  }

  async function pickPhotos(bag) {
    const list = bag.slice(0, 12);
    const ok = await Promise.all(list.map(canLoadPhoto));
    return list.filter((u, i) => ok[i]).slice(0, 4);
  }

  const SEARCH_TOOLS = [
    { type: "function", function: {
      name: "web_search",
      description: "Search the web and get the top results (title, source, snippet, url). Use short, focused queries.",
      parameters: { type: "object", properties: { query: { type: "string", description: "The search query" } }, required: ["query"] }
    } },
    { type: "function", function: {
      name: "image_search",
      description: "Find real photos of a subject from the web. The photos are shown to the user automatically above your reply.",
      parameters: { type: "object", properties: { query: { type: "string", description: "What the photos should show" } }, required: ["query"] }
    } }
  ];

  const deepPrompt = () =>
    "\n\nDeep search is ON. Today's date is " + new Date().toISOString().slice(0, 10) + ". " +
    "You have two tools: web_search (facts from the web) and image_search (real photos to show the user). " +
    "You MUST call web_search before answering, and you may search several more times with short focused queries if needed " +
    "(English queries usually work best; use Arabic when the topic is Arabic). " +
    "Use image_search once when real photos of the subject would help the user (a place, animal, product, event, object); skip it for abstract questions. " +
    "Base your answer on what the results say; if they don't answer the question, say so honestly. " +
    "Mention source sites by name in plain words when it helps, but never paste raw links. " +
    "Photos appear automatically right above your reply, so you can refer to them naturally, but never describe what they show beyond the subject you searched for.";

  // used when a model refuses tool calling: the app searches for it instead
  async function searchFirstAnswer(turns) {
    const last = turns.slice().reverse().find((x) => x.role === "user");
    const q = String(last ? last.content : "").split("\n\n[Picture notes]")[0].replace(/^\(Replying to:[^\n]*\)\n/, "").trim().slice(0, 200);
    const photoBag = [];
    const [web] = await Promise.all([
      toolWebSearch(q).catch((e) => ({ error: "Search failed: " + e.message })),
      toolImageSearch(q, photoBag).catch(() => null)
    ]);
    const sys = systemPrompt() + "\n\nDeep search is ON. Today's date is " + new Date().toISOString().slice(0, 10) + ". " +
      "Web search results for the user's latest message (base your answer on them, mention sources by name, never paste raw links): " +
      JSON.stringify(web) + (photoBag.length ? "\nPhotos about this subject are shown above your reply automatically." : "");
    const step = await chatStep({ messages: [{ role: "system", content: sys }, ...turns.slice(-24)], temperature: model === "north" ? 0.3 : 0.5 });
    if (!step.text) throw new Error("Empty response");
    return { text: step.text, photos: photoBag.length ? await pickPhotos(photoBag) : [] };
  }

  async function deepAnswer(turns) {
    const msgs = [{ role: "system", content: systemPrompt() + deepPrompt() }, ...turns.slice(-24)];
    const photoBag = [];
    const temp = model === "north" ? 0.3 : 0.5;

    for (let round = 0; ; round++) {
      // round 0: a web search is required; later rounds: GPT chooses; after 4 rounds it must answer
      const tools = round === 0 ? [SEARCH_TOOLS[0]] : (round < 4 ? SEARCH_TOOLS : null);

      let step;
      try {
        step = await chatStep({ messages: msgs, tools, force: round === 0, temperature: temp });
      } catch (e) {
        if (round === 0 && (e.status === 400 || e.status === 422)) return searchFirstAnswer(turns);
        throw e;
      }

      const calls = tools ? step.calls : [];
      if (!calls.length) {
        if (!step.text) throw new Error("Empty response");
        return { text: step.text, photos: photoBag.length ? await pickPhotos(photoBag) : [] };
      }

      msgs.push(step.assistant);

      const results = await Promise.all(calls.slice(0, 3).map(async (tc) => {
        let result;
        try {
          const args = JSON.parse(tc.function.arguments || "{}");
          const query = String(args.query || "").trim().slice(0, 200);
          if (!query) throw new Error("Missing query");
          result = tc.function.name === "image_search"
            ? await toolImageSearch(query, photoBag)
            : await toolWebSearch(query);
        } catch (e) {
          console.error("[iMa! search]", e);
          showToast("Search failed: " + (e.message || "unknown error"));
          result = { error: "Search failed: " + (e.message || "unknown error") + ". Answer from your own knowledge and say the search failed." };
        }
        return toolMessage(tc, result);
      }));
      // every call needs an answer, even the ones beyond the cap
      calls.slice(3).forEach((tc) => results.push(toolMessage(tc, { error: "Too many searches at once." })));
      msgs.push(...results);
    }
  }

  /* getReply resolves to { text, ok, ci }
       ok  = false when the request failed (text is then a friendly error)
       photos = web pictures to show with the answer (Deep search only)
       ci  = index of GPT's answer inside convo (used by Regenerate)
     Pass regen = <ci> to redo that answer instead of adding a new turn. */
  async function getReply({ text, images, quote = "", regen = -1, modes: m = {}, extra = "" }) {
    let turns;
    let userTurn = null;

    try {
      if (regen >= 0) {
        turns = convo.slice(0, regen);
      } else {
        let content = text || "";
        if (quote) content = "(Replying to: \"" + quote + "\")\n" + content;
        if (images.length) {
          if (!text) content = (content ? content + "\n" : "") + "(The user sent a picture with no message.)";
          content += "\n\n" + await pictureNotes(images, text);
        }
        if (extra) content += "\n\n" + extra;      // live data fetched by a tool command
        userTurn = { role: "user", content };
        convo.push(userTurn);
        turns = convo.slice();
      }

      let answer;
      let photos = [];
      if (m.deep) {
        const r = await deepAnswer(turns);
        answer = r.text;
        if (regen < 0) photos = r.photos;
      } else {
        const step = await chatStep({
          messages: [{ role: "system", content: systemPrompt() }, ...turns.slice(-24)],
          temperature: model === "north" ? 0.3 : 0.7
        });
        if (!step.text) throw new Error("Empty response");
        answer = step.text;
      }

      const turn = { role: "assistant", content: answer };
      if (regen >= 0) { convo[regen] = turn; return { text: answer, ok: true, ci: regen, photos }; }
      convo.push(turn);
      return { text: answer, ok: true, ci: convo.length - 1, photos };

    } catch (e) {
      console.error("[iMa! reply]", e);
      if (userTurn) { const i = convo.lastIndexOf(userTurn); if (i >= 0) convo.splice(i, 1); }
      return { text: t(e && e.status === 429 ? "aiBusy" : "aiError"), ok: false, ci: -1, photos: [] };
    }
  }

  /* ---------- Create image: FLUX (Cloudflare Workers AI) ----------
     Resolves to a blob: URL of the generated picture. FLUX understands
     English best, so Arabic descriptions are translated by GPT first. */
  // crop the picture to the chosen aspect ratio and scale it to the chosen quality
  async function fitImage(blob, ratio, longSide, q) {
    const src = URL.createObjectURL(blob);
    try {
      const im = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = src; });
      const [rw, rh] = ratio.split(":").map(Number), r = rw / rh;
      const sw = Math.min(im.naturalWidth, im.naturalHeight * r), sh = sw / r;
      const sx = (im.naturalWidth - sw) / 2, sy = (im.naturalHeight - sh) / 2;
      const cw = r >= 1 ? longSide : Math.round(longSide * r), ch = r >= 1 ? Math.round(longSide / r) : longSide;
      const cv = document.createElement("canvas"); cv.width = cw; cv.height = ch;
      cv.getContext("2d").drawImage(im, sx, sy, sw, sh, 0, 0, cw, ch);
      const out = await new Promise((ok) => cv.toBlob(ok, "image/jpeg", q));
      return out ? URL.createObjectURL(out) : URL.createObjectURL(blob);
    } catch (e) {
      return URL.createObjectURL(blob);
    } finally {
      URL.revokeObjectURL(src);
    }
  }

  async function getImage({ text }) {
    const ig = imagineOpts();
    let prompt = text;
    if (ig.improve) {
      try {
        prompt = await groq(GPT_KEY, {
          model: GPT_MODEL,
          messages: [
            { role: "system", content: "You are an expert prompt engineer for text-to-image models. Rewrite the user's idea as ONE professional, vivid English image prompt: subject, setting, composition, lighting, mood, camera/lens and fine details, in about 60-110 words. Keep the user's intent and any names or text they want in the image. Reply with the prompt only, no quotes or commentary." },
            { role: "user", content: text }
          ],
          temperature: 0.7,
          max_completion_tokens: 600,
          stream: false
        }, 30000);
      } catch (e) { prompt = text; }
    }
    if (!ig.improve && /[\u0600-\u06FF]/.test(text)) {
      try {
        prompt = await groq(GPT_KEY, {
          model: GPT_MODEL,
          messages: [
            { role: "system", content: "Translate the user's image description into one clear, vivid English prompt for an image generator. Reply with the prompt only." },
            { role: "user", content: text }
          ],
          temperature: 0.3,
          max_completion_tokens: 1000,
          stream: false
        }, 30000);
      } catch (e) { prompt = text; }
    }
    const st = IG_STYLES.find((x) => x.id === ig.style);
    if (st && st.hint) prompt += ", " + st.hint;
    if (ig.ratio !== "1:1") prompt += ", composed for a " + ig.ratio + " frame";
    prompt = prompt.slice(0, 2048);

    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 90000);
    try {
      const res = await fetch(CF_URL, {
        method: "POST",
        signal: ctl.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, steps: ig.quality === "hd" ? 8 : 4 })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        const why = (data.errors || []).map((e) => e.message || JSON.stringify(e)).join("; ");
        throw new Error(why || ("Cloudflare HTTP " + res.status));
      }
      const b64 = data.result && data.result.image;
      if (!b64) throw new Error("No image returned");
      const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
      const raw = new Blob([bytes], { type: "image/jpeg" });
      return await fitImage(raw, ig.ratio, ig.quality === "hd" ? 1024 : 768, ig.quality === "hd" ? 0.93 : 0.85);
    } catch (e) {
      console.error("[iMa! image]", e);
      throw e;
    } finally {
      clearTimeout(timer);
    }
  }


  /* ---------- Tool commands: /weather /news /search /images /map ----------
     The app fetches live data first, then GPT-OSS 120B (the main mind) writes the answer from it.
     runTool resolves to { block, photos, map } on success, or { fail } (a message shown as is). */
  const TOOL_FAIL = { weather: "wxFail", news: "newsFail", search: "webFail", images: "imgFail", map: "mapFail" };
  const toolLang = () => (settings.lang === "ar" ? "ar" : "en");

  async function fetchJson(url, ms = 15000) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), ms);
    try {
      const r = await fetch(url, { signal: ctl.signal });
      if (!r.ok) throw new Error("HTTP " + r.status);
      return await r.json();
    } finally { clearTimeout(timer); }
  }

  const WX_TEXT = { 0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast", 45: "Fog", 48: "Rime fog", 51: "Light drizzle", 53: "Drizzle", 55: "Dense drizzle", 56: "Freezing drizzle", 57: "Dense freezing drizzle", 61: "Light rain", 63: "Rain", 65: "Heavy rain", 66: "Freezing rain", 67: "Heavy freezing rain", 71: "Light snow", 73: "Snow", 75: "Heavy snow", 77: "Snow grains", 80: "Light rain showers", 81: "Rain showers", 82: "Violent rain showers", 85: "Snow showers", 86: "Heavy snow showers", 95: "Thunderstorm", 96: "Thunderstorm with hail", 99: "Thunderstorm with heavy hail" };

  function devicePlace() {
    return new Promise((ok) => {
      if (!navigator.geolocation) { ok(null); return; }
      navigator.geolocation.getCurrentPosition(
        (p) => ok({ lat: +p.coords.latitude.toFixed(3), lon: +p.coords.longitude.toFixed(3) }),
        () => ok(null), { timeout: 8000, maximumAge: 600000 });
    });
  }
  async function placeName(lat, lon) {
    try {
      const j = await fetchJson("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10&accept-language=" + toolLang() + "&lat=" + lat + "&lon=" + lon, 8000);
      const a = j.address || {};
      return [a.city || a.town || a.village || a.county || a.state, a.country].filter(Boolean).join(", ");
    } catch (e) { return ""; }
  }

  async function toolWeather(q) {
    let spot;
    if (q) {
      const g = await fetchJson("https://geocoding-api.open-meteo.com/v1/search?count=1&language=" + toolLang() + "&name=" + encodeURIComponent(q));
      const hit = (g.results || [])[0];
      if (!hit) return { fail: t("wxNone") };
      spot = { lat: hit.latitude, lon: hit.longitude, name: [hit.name, hit.admin1, hit.country].filter(Boolean).join(", ") };
    } else {
      spot = await devicePlace();
      if (!spot) return { fail: t("mapDenied") };
      spot.name = (await placeName(spot.lat, spot.lon)) || ("lat " + spot.lat + ", lon " + spot.lon);
    }
    const d = await fetchJson("https://api.open-meteo.com/v1/forecast?latitude=" + spot.lat + "&longitude=" + spot.lon + "&timezone=auto&forecast_days=5&wind_speed_unit=kmh" +
      "&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,precipitation,cloud_cover,weather_code,is_day" +
      "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset,uv_index_max");
    if (!d.current || !d.daily) throw new Error("no weather data");
    const c = d.current, dd = d.daily;
    const lines = [
      "[Live data · Weather] fetched just now (Open-Meteo)",
      "Place: " + spot.name,
      "Local time there: " + String(c.time).replace("T", " "),
      "Now: " + c.temperature_2m + "°C (feels like " + c.apparent_temperature + "°C), " + (WX_TEXT[c.weather_code] || "") + ", " + (c.is_day ? "daytime" : "night") +
        ", humidity " + c.relative_humidity_2m + "%, wind " + c.wind_speed_10m + " km/h, cloud cover " + c.cloud_cover + "%, precipitation " + c.precipitation + " mm"
    ];
    dd.time.forEach((day, i) => {
      const nm = new Date(day + "T12:00:00").toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" });
      lines.push("- " + nm + ": " + (WX_TEXT[dd.weather_code[i]] || "") + ", " + dd.temperature_2m_min[i] + "–" + dd.temperature_2m_max[i] + "°C, rain chance " +
        dd.precipitation_probability_max[i] + "%, UV " + dd.uv_index_max[i] + (i === 0 ? ", sunrise " + String(dd.sunrise[0]).slice(11) + ", sunset " + String(dd.sunset[0]).slice(11) : ""));
    });
    lines.push("Write a short, friendly weather report: how it is right now, the next days at a glance, and one practical tip (umbrella, jacket, sunscreen…). Use °C. Don't paste the data as a raw list.");
    return { block: lines.join("\n") };
  }

  // Google News has no CORS headers → asked through public relays, all at once; the first good answer wins
  const NEWS_RELAYS = [
    { u: (x) => "https://api.allorigins.win/raw?url=" + encodeURIComponent(x) },
    { u: (x) => "https://api.allorigins.win/get?url=" + encodeURIComponent(x), wrap: (j) => j && j.contents },
    { u: (x) => "https://corsproxy.io/?url=" + encodeURIComponent(x) },
    { u: (x) => "https://api.codetabs.com/v1/proxy?quest=" + encodeURIComponent(x) },
    { u: (x) => "https://api.cors.lol/?url=" + encodeURIComponent(x) },
    { u: (x) => "https://thingproxy.freeboard.io/fetch/" + x }
  ];
  function newsFromRss(xml) {
    const doc = new DOMParser().parseFromString(xml, "text/xml");
    return Array.from(doc.querySelectorAll("item")).slice(0, 8).map((it) => {
      const g = (n) => { const e = it.querySelector(n); return e ? e.textContent.trim() : ""; };
      let title = g("title"), src = g("source");
      const cut = title.lastIndexOf(" - ");
      if (cut > 0) { if (!src) src = title.slice(cut + 3); title = title.slice(0, cut); }
      return title ? { title, src, link: g("link"), date: Date.parse(g("pubDate")) } : null;
    }).filter(Boolean);
  }
  function fetchNewsFeed(url) {
    return new Promise((resolve, reject) => {
      let left = NEWS_RELAYS.length, done = false;
      const ctls = [];
      NEWS_RELAYS.forEach((rl) => {
        const ctl = new AbortController(); ctls.push(ctl);
        const to = setTimeout(() => ctl.abort(), 12000);
        fetch(rl.u(url), { signal: ctl.signal })
          .then((r) => { if (!r.ok) throw new Error("http " + r.status); return rl.wrap ? r.json() : r.text(); })
          .then((d) => {
            const txt = rl.wrap ? rl.wrap(d) : d;
            if (typeof txt !== "string" || !/<(rss|channel|item)[\s>]/i.test(txt)) throw new Error("not rss");
            if (!done) { done = true; ctls.forEach((c) => { if (c !== ctl) c.abort(); }); resolve(newsFromRss(txt)); }
          })
          .catch(() => { if (--left === 0 && !done) reject(new Error("no news relay answered")); })
          .finally(() => clearTimeout(to));
      });
    });
  }
  async function toolNews(q) {
    const G = "https://news.google.com/rss";
    const ar = q ? /[\u0600-\u06FF]/.test(q) : settings.lang === "ar";
    const loc = ar ? "hl=ar&gl=DZ&ceid=DZ:ar" : "hl=en-US&gl=US&ceid=US:en";
    const items = await fetchNewsFeed(q ? G + "/search?q=" + encodeURIComponent(q) + "+when:2d&" + loc : G + "?" + loc);
    if (!items.length) return { fail: t("newsNone") };
    const ago = (d) => { const m = Math.round((Date.now() - d) / 60000); return !isFinite(m) || m < 0 ? "" : m < 60 ? m + " min ago" : m < 1440 ? Math.round(m / 60) + " h ago" : Math.round(m / 1440) + " d ago"; };
    return { block: [
      "[Live data · News] fetched just now (Google News)",
      "Topic: " + (q || "top stories") + " · today is " + new Date().toISOString().slice(0, 10),
      ...items.map((x, i) => (i + 1) + ". " + x.title + " — " + (x.src || "?") + (ago(x.date) ? ", " + ago(x.date) : "") + (x.link ? " (" + x.link + ")" : "")),
      "Give a short briefing: the main stories in one or two lines each, with the source name. You may link a headline with markdown [headline](url). Answer in the user's language (translate headlines if needed)."
    ].join("\n") };
  }

  async function toolSearch(q) {
    const r = await toolWebSearch(q);
    if (!r.results || !r.results.length) return { fail: t("webNone") };
    return { block: [
      "[Live data · Web search] fetched just now",
      "Query: " + q,
      ...r.results.map((x, i) => (i + 1) + ". " + x.title + " — " + x.source + (x.snippet ? ": " + x.snippet : "") + (x.url ? " (" + x.url + ")" : "")),
      "Answer the user's question from these results, clearly and compactly. Name the sources in plain words; you may link with markdown [site](url). If the results don't answer it, say so honestly."
    ].join("\n") };
  }

  async function toolImages(q) {
    const bag = [];
    const r = await toolImageSearch(q, bag);
    const photos = bag.length ? await pickPhotos(bag) : [];
    if (!photos.length) return { fail: t("imgNone") };
    return { photos, block: [
      "[Live data · Images] fetched just now",
      "Search: " + q + " — " + photos.length + " photos found" + (r.titles && r.titles.length ? " (e.g. " + r.titles.join("; ") + ")" : ""),
      "The photos are shown right above your reply. Write only a short, friendly caption (one or two sentences) about the subject."
    ].join("\n") };
  }

  // a Wikipedia summary for the place, only when the article clearly matches the name
  async function wikiBrief(name) {
    try {
      const lang = toolLang();
      const s = await fetchJson("https://" + lang + ".wikipedia.org/w/api.php?action=query&list=search&srlimit=1&format=json&origin=*&srsearch=" + encodeURIComponent(name), 8000);
      const hit = s.query && s.query.search && s.query.search[0];
      if (!hit) return "";
      const norm = (x) => String(x).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
      const a = norm(hit.title), b = norm(name);
      if (!a || !b || !(a.includes(b) || b.includes(a))) return "";
      const r = await fetchJson("https://" + lang + ".wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(hit.title), 8000);
      return String(r.extract || "").slice(0, 700);
    } catch (e) { return ""; }
  }
  async function toolMap(q) {
    const j = await fetchJson("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&addressdetails=1&accept-language=" + toolLang() + "&q=" + encodeURIComponent(q));
    const hit = j && j[0];
    if (!hit) return { fail: t("mapNone") };
    const lat = +hit.lat, lon = +hit.lon;
    const bb = (hit.boundingbox || []).map(Number);                       // south, north, west, east
    const span = bb.length === 4 && bb.every(isFinite) ? Math.max(bb[1] - bb[0], bb[3] - bb[2]) : 0.01;
    const z = Math.max(3, Math.min(17, Math.floor(Math.log2(514 / Math.max(span, 0.0005)))));
    const name = hit.name || String(hit.display_name || q).split(",")[0];
    const wiki = await wikiBrief(name);
    const a = hit.address || {};
    return { map: { lat, lon, name, z }, block: [
      "[Live data · Map] fetched just now (OpenStreetMap)",
      "Place: " + hit.display_name,
      "Kind: " + [hit.category, hit.type].filter(Boolean).join(" / "),
      a.country ? "Country: " + a.country : "",
      wiki ? "Wikipedia: " + wiki : "",
      "The map of this place is shown right above your reply. Tell the user what and where it is (region, country) plus a few useful facts from the data, in two to four sentences. Don't mention coordinates unless asked."
    ].filter(Boolean).join("\n") };
  }

  function runTool(name, q) {
    return ({ weather: toolWeather, news: toolNews, search: toolSearch, images: toolImages, map: toolMap })[name](q);
  }

  // the map card inside a chat message: OpenStreetMap tiles around the place, zoom buttons, a link to open it
  function attachMap(msg, info) {
    msg._map = info;
    const card = el("div", "map-card");
    const view = el("div", "map-view"), tiles = el("div", "map-tiles"), pin = el("i", "map-pin"), zoom = el("div", "map-zoom"), attr = el("span", "map-attr");
    pin.setAttribute("aria-hidden", "true");
    attr.textContent = "© OpenStreetMap";
    const zin = el("button", ""), zout = el("button", "");
    zin.type = zout.type = "button";
    zin.textContent = "+"; zout.textContent = "−";
    zin.setAttribute("aria-label", "+"); zout.setAttribute("aria-label", "−");
    zoom.append(zin, zout);
    view.append(tiles, pin, zoom, attr);
    const foot = el("a", "map-foot");
    foot.href = "https://www.openstreetmap.org/?mlat=" + info.lat + "&mlon=" + info.lon + "#map=" + info.z + "/" + info.lat + "/" + info.lon;
    foot.target = "_blank"; foot.rel = "noopener noreferrer";
    const nm = el("b", ""), op = el("span", "");
    nm.textContent = info.name; op.textContent = t("mapOpen");
    foot.append(nm, op);
    card.append(view, foot);
    let z = info.z;
    const draw = () => {
      const n = Math.pow(2, z), rad = Math.PI / 180;
      const xf = (info.lon + 180) / 360 * n;
      const yf = (1 - Math.log(Math.tan(info.lat * rad) + 1 / Math.cos(info.lat * rad)) / Math.PI) / 2 * n;
      const tx = Math.floor(xf), ty = Math.floor(yf), fx = (xf - tx) * 256, fy = (yf - ty) * 256;
      tiles.textContent = "";
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const y = ty + dy;
        if (y < 0 || y >= n) continue;
        const im = new Image();
        im.alt = ""; im.draggable = false; im.decoding = "async";
        im.src = "https://tile.openstreetmap.org/" + z + "/" + (((tx + dx) % n) + n) % n + "/" + y + ".png";
        im.style.left = (384 + dx * 256 - fx) + "px";
        im.style.top = (384 + dy * 256 - fy) + "px";
        tiles.appendChild(im);
      }
      zin.disabled = z >= 18; zout.disabled = z <= 2;
    };
    zin.addEventListener("click", () => { if (z < 18) { z++; draw(); } });
    zout.addEventListener("click", () => { if (z > 2) { z--; draw(); } });
    draw();
    msg.insertBefore(card, msg.firstChild);
    scrollToEnd();
    // upgrade to a full Leaflet map (drag, pinch, double-tap, wheel, zoom buttons) — same engine as the expanded map
    loadChatLeaflet().then(() => {
      if (!window.L || !card.isConnected) return;
      view.textContent = "";
      const lm = L.map(view, { zoomControl: false, attributionControl: false, worldCopyJump: true, tap: true, minZoom: 2, maxZoom: 19 }).setView([info.lat, info.lon], info.z);
      L.control.attribution({ prefix: false, position: "bottomleft" }).addTo(lm);
      L.control.zoom({ position: "topright" }).addTo(lm);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }).addTo(lm);
      L.marker([info.lat, info.lon], { icon: L.divIcon({ className: "map-dot", html: "<i></i>", iconSize: [18, 18], iconAnchor: [9, 9] }), keyboard: false }).addTo(lm);
      view.classList.add("is-live");
      setTimeout(() => lm.invalidateSize(), 60);
      if (window.ResizeObserver) new ResizeObserver(() => lm.invalidateSize()).observe(view);
    }).catch(() => {});   // offline / blocked: the simple static map above stays
  }
  let chatLeaflet = null;
  function loadChatLeaflet() {
    if (window.L) return Promise.resolve();
    if (chatLeaflet) return chatLeaflet;
    chatLeaflet = new Promise((ok, fail) => {
      const base = "https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/";
      if (!document.querySelector('link[data-leaflet]')) {
        const css = document.createElement("link");
        css.rel = "stylesheet"; css.href = base + "leaflet.css"; css.setAttribute("data-leaflet", "1");
        document.head.appendChild(css);
      }
      const js = document.createElement("script");
      js.src = base + "leaflet.js";
      js.onload = () => ok(); js.onerror = () => { chatLeaflet = null; js.remove(); fail(new Error("leaflet")); };
      document.head.appendChild(js);
    });
    return chatLeaflet;
  }


  /* ---------- Thread ---------- */

  function renderStamp(elm) {
    const time = new Date(+elm.dataset.ts).toLocaleTimeString(timeLocale(), { hour: "numeric", minute: "2-digit" });
    elm.innerHTML = "<b></b> " + time;
    const d = new Date(+elm.dataset.ts);
    elm.firstChild.textContent = d.toDateString() === new Date().toDateString()
      ? t("today")
      : d.toLocaleDateString(timeLocale(), { month: "short", day: "numeric" });
  }

  function stamp() {
    const elm = document.createElement("div");
    elm.className = "stamp";
    elm.dataset.ts = String(Date.now());
    renderStamp(elm);
    thread.appendChild(elm);
  }

  function scrollToEnd(smooth = true) {
    thread.scrollTo({ top: thread.scrollHeight, behavior: smooth ? "smooth" : "auto" });
  }

  function addMessage(role, { text = "", images = [], i18n = "", quote = "", qrole = "in", md = false } = {}) {
    const same = lastMsg && lastMsg.classList.contains(role);
    if (same) {
      const prev = lastMsg.querySelector(".bubble.tail");
      if (prev) prev.classList.remove("tail");
    }

    const msg = document.createElement("div");
    msg.className = `msg ${role} new${same ? " same" : ""}`;

    // pictures found on the web are shown as a swipeable strip; your own pictures stay large
    let host = msg;
    if (images.length && images.every((u) => /^https?:/i.test(u))) {
      host = document.createElement("div");
      host.className = "gallery";
      msg.appendChild(host);
    }
    images.forEach((src) => {
      const img = document.createElement("img");
      img.className = "photo";
      img.referrerPolicy = "no-referrer";
      img.src = src;
      img.alt = t("attached");
      host.appendChild(img);
    });

    if (quote) {
      const q = document.createElement("div");
      q.className = "quote";
      q.dataset.qrole = qrole;
      const lab = document.createElement("span");
      lab.className = "quote-label";
      const key = qrole === "out" ? "repliedSelf" : "repliedAI";
      lab.dataset.i18n = key;
      lab.textContent = t(key);
      const body = document.createElement("span");
      body.className = "quote-text " + qrole;
      const clip = document.createElement("span");
      clip.className = "quote-clip";
      clip.dir = "auto";
      clip.textContent = quote;
      body.appendChild(clip);
      q.append(lab, body);
      msg.appendChild(q);
    }

    if (text) {
      const bubble = document.createElement("div");
      bubble.className = "bubble tail";
      if (md) {
        bubble.classList.add("md");
        bubble.innerHTML = renderMarkdown(text);
        msg.classList.add("md");
        msg._raw = text;
      } else {
        bubble.textContent = text;
      }
      if (i18n) bubble.dataset.i18n = i18n;     // re-translated when the language changes
      msg.appendChild(bubble);
    }

    removeTyping();
    thread.appendChild(msg);
    lastMsg = msg;
    msg._h = { role, text, images: images.length };
    if (i18n) msg._noRegen = true;
    history.push(msg._h);
    scrollToEnd();
    return msg;
  }

  function showReceipt(msg) {
    clearReceipt();
    if (!settings.receipts) return;
    receipt = document.createElement("div");
    receipt.className = "receipt";
    receipt.dataset.i18n = "delivered";
    receipt.textContent = t("delivered");
    msg.appendChild(receipt);
  }

  function clearReceipt() {
    if (receipt) receipt.remove();
    receipt = null;
  }

  function showTyping() {
    removeTyping();
    typingEl = document.createElement("div");
    typingEl.className = "msg in new";
    if (lastMsg && lastMsg.classList.contains("in")) typingEl.classList.add("same");
    typingEl.innerHTML =
      '<div class="bubble tail typing"><span></span><span></span><span></span></div>';
    typingEl.firstChild.setAttribute("aria-label", t("typing"));
    thread.appendChild(typingEl);
    scrollToEnd();
  }

  function removeTyping() {
    if (typingEl) typingEl.remove();
    typingEl = null;
  }


  /* ---------- Toast ---------- */

  let toastTimer;
  function showToast(text) {
    toastEl.textContent = text;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("show"), 2200);
  }


  /* ---------- Attachments ---------- */

  function renderTray() {
    tray.innerHTML = "";
    tray.hidden = pending.length === 0;

    pending.forEach((item, i) => {
      const thumb = document.createElement("div");
      thumb.className = "thumb";

      const img = document.createElement("img");
      img.src = item.url;
      img.alt = "";

      const remove = document.createElement("button");
      remove.type = "button";
      remove.setAttribute("aria-label", t("removePicture"));
      remove.addEventListener("click", () => {
        URL.revokeObjectURL(item.url);
        pending.splice(i, 1);
        renderTray();
        syncSend();
      });

      thumb.append(img, remove);
      tray.appendChild(thumb);
    });

    fitComposer();
  }

  fileInput.addEventListener("change", () => {
    Array.from(fileInput.files)
      .filter((f) => f.type.startsWith("image/"))
      .forEach((f) => pending.push({ url: URL.createObjectURL(f) }));
    fileInput.value = "";
    renderTray();
    syncSend();
  });


  /* ---------- Mode chips (Think harder / Deep search / Create image) ---------- */

  function renderModes() {
    modesEl.innerHTML = "";
    const list = [];
    if (editing)     list.push({ key: "edit",  ico: "rename",       label: t("chipEdit") });
    if (replyTo)     list.push({ key: "reply", reply: replyTo, cls: " chip-reply" });
    if (modes.think) list.push({ key: "think", ico: "lamp",         label: t("chipThink") });
    if (modes.deep)  list.push({ key: "deep",  ico: "telescope",    label: t("chipDeep") });
    modesEl.hidden = list.length === 0;

    list.forEach(({ key, ico, label, cls = "", reply }) => {
      const chip = document.createElement("div");
      chip.className = "chip material" + cls;
      if (reply) {
        // reply preview: small label + the quoted message in its own bubble colour
        chip.classList.add("chip-reply--" + reply.role);
        label = reply.role === "out" ? t("replyingSelf") : t("replyingTo") + " iMa!";
        const box = document.createElement("div");
        box.className = "reply-box";
        const lab = document.createElement("span");
        lab.className = "reply-label";
        lab.textContent = label;
        const q = document.createElement("span");
        q.className = "reply-quote " + reply.role;
        q.dir = "auto";
        q.textContent = reply.text;
        box.append(lab, q);
        const xb = document.createElement("button");
        xb.type = "button";
        xb.setAttribute("aria-label", t("turnOff") + " " + label);
        xb.addEventListener("click", () => { replyTo = null; renderModes(); });
        chip.append(box, xb);
        modesEl.appendChild(chip);
        return;
      }

      const img = document.createElement("img");
      img.src = icon(ico);
      img.alt = "";

      const text = document.createElement("span");
      text.textContent = label;

      const x = document.createElement("button");
      x.type = "button";
      x.setAttribute("aria-label", t("turnOff") + " " + label);
      x.addEventListener("click", () => { if (key === "edit") { cancelEdit(); return; } if (key === "reply") replyTo = null; else modes[key] = false; renderModes(); });

      chip.append(img, text, x);
      modesEl.appendChild(chip);
    });

    updatePlaceholder();
    syncSend();
    fitComposer();
  }


  /* ---------- Popup menu ---------- */

  let menuState = null;

  function el(tag, cls) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    return n;
  }

  function renderMenu(items, header) {
    menu.innerHTML = "";

    if (header) {
      const back = el("button", "menu-item menu-back");
      back.type = "button";
      back.setAttribute("role", "menuitem");
      back.innerHTML = BACK + "<span></span>";
      back.querySelector("span").textContent = header.title;
      back.addEventListener("click", header.onBack);
      menu.appendChild(back);
    }

    items.forEach((it) => {
      if (it.sep) { menu.appendChild(el("div", "menu-sep")); return; }

      const btn = el("button", "menu-item" + (it.danger ? " danger" : ""));
      btn.type = "button";
      btn.setAttribute("role", "menuitem");

      const label = el("span", "menu-label");
      const name = el("span");
      name.textContent = it.label;
      label.appendChild(name);
      if (it.on) label.insertAdjacentHTML("beforeend", CHECK);
      btn.appendChild(label);

      if (it.icon) {
        const img = el("img", "mi");
        img.src = icon(it.icon);
        img.alt = "";
        btn.appendChild(img);
      }

      btn.addEventListener("click", () => {
        if (it.sub) {
          renderMenu(it.sub, { title: it.label, onBack: () => { renderMenu(items); placeMenu(); } });
          placeMenu();
        } else {
          closeMenu();
          if (it.action) it.action();
        }
      });

      menu.appendChild(btn);
    });
  }

  function placeMenu() {
    if (!menuState) return;
    const { anchor, placement } = menuState;
    const a = app.getBoundingClientRect();
    const r = anchor.getBoundingClientRect();

    menu.style.top = menu.style.right = menu.style.bottom = menu.style.left = "auto";

    if (placement === "down") {
      // open toward the middle of the screen, from whichever side the button is on
      const fromLeft = r.left - a.left;
      const fromRight = a.right - r.right;
      const roomBelow = a.bottom - r.bottom - 10 - 12;
      if (menu.offsetHeight > roomBelow && r.top - a.top > menu.offsetHeight + 22) {
        menu.style.bottom = (a.bottom - r.top + 10) + "px";
      } else {
        menu.style.top = (r.bottom - a.top + 10) + "px";
      }
      if (fromLeft < fromRight) {
        menu.style.left = Math.max(12, fromLeft) + "px";
        menu.style.transformOrigin = "top left";
      } else {
        menu.style.right = Math.max(12, fromRight) + "px";
        menu.style.transformOrigin = "top right";
      }
    } else {
      menu.style.bottom = (a.bottom - r.top + 12) + "px";
      if (isRTL()) {
        menu.style.right = Math.max(12, a.right - r.right - 6) + "px";
        menu.style.transformOrigin = "bottom right";
      } else {
        menu.style.left = Math.max(12, r.left - a.left - 6) + "px";
        menu.style.transformOrigin = "bottom left";
      }
    }
  }

  function openMenu(anchor, placement, items, small = false) {
    menuState = { anchor, placement };
    menu.classList.toggle("menu--sm", small);
    menu.classList.remove("menu--attach");
    renderMenu(items);
    menu.hidden = false;
    menuScrim.hidden = false;
    placeMenu();
    const first = menu.querySelector(".menu-item");
    if (first) first.focus({ preventScroll: true });
  }

  function closeMenu() {
    menu.hidden = true;
    menuScrim.hidden = true;
    menuState = null;
  }

  menuScrim.addEventListener("click", closeMenu);

  function moreItems() {
    return [
      {
        label: t("switchModel"), icon: "model",
        sub: allModels().map((m) => ({
          label: m.name,
          on: model === m.id,
          action: () => { model = m.id; applyModelLogo(); showToast(t("switchedTo") + " " + m.name); }
        })).concat([{ sep: true }, { label: "+  " + t("addModel"), action: () => openCustomModel() }])
      },
      { label: t("newChat"),     icon: "compose",
        action: () => { startChat(); input.focus(); } },
      { label: t("files"),       icon: "folder", action: openFiles },
      { label: t("deleteChat"),  icon: "trash-red", danger: true, action: confirmDelete }
    ];
  }

  moreBtn.addEventListener("click", () => {
    if (menuState) { closeMenu(); return; }
    openMenu(moreBtn, "down", moreItems(), true);
    menu.classList.add("menu--attach");      // same compact size as the + menu
  });

  attachBtn.addEventListener("click", () => {
    if (menuState) { closeMenu(); return; }
    openMenu(composer, "up", [
      { label: t("addPicture"), icon: "image", action: () => fileInput.click() },
      { label: t("deepSearch"), icon: "telescope", on: modes.deep,
        action: () => { modes.deep = !modes.deep; renderModes(); input.focus(); } }
    ], true);
    menu.classList.add("menu--attach");
  });


  /* ---------- Sheets + alerts ---------- */

  function closeModal() {
    modal.hidden = true;
    modal.style.zIndex = "";
    modalBox.innerHTML = "";
    modalBox.className = "";
    modalBox.style.animation = "";
  }

  $("modalScrim").addEventListener("click", closeModal);

  function openSheet(title, build, { instant = false } = {}) {
    modalBox.className = "sheet";
    modalBox.style.animation = instant ? "none" : "";
    modalBox.setAttribute("role", "dialog");
    modalBox.setAttribute("aria-modal", "true");
    modalBox.setAttribute("aria-label", title);
    modalBox.innerHTML = "";

    modalBox.appendChild(el("div", "grabber"));

    const head = el("div", "sheet-head");
    const ttl = el("div", "sheet-title");
    ttl.textContent = title;
    const done = el("button", "sheet-done");
    done.type = "button";
    done.textContent = t("done");
    done.addEventListener("click", closeModal);
    head.append(ttl, done);
    modalBox.appendChild(head);

    build(modalBox);
    modal.hidden = false;
    if (!instant) done.focus({ preventScroll: true });
  }

  function openAlert(title, message, actions) {
    modalBox.className = "alert";
    modalBox.setAttribute("role", "alertdialog");
    modalBox.setAttribute("aria-modal", "true");
    modalBox.setAttribute("aria-label", title);
    modalBox.innerHTML = "";

    const body = el("div", "alert-body");
    const h = el("div", "alert-title"); h.textContent = title;
    const p = el("div", "alert-msg");   p.textContent = message;
    body.append(h, p);

    const bar = el("div", "alert-actions");
    actions.forEach((a) => {
      const b = el("button", a.danger ? "danger" : "");
      b.type = "button";
      b.textContent = a.label;
      b.addEventListener("click", () => { closeModal(); if (a.onClick) a.onClick(); });
      bar.appendChild(b);
    });

    modalBox.append(body, bar);
    modal.hidden = false;
  }

  // small builders for settings-style rows
  /* ---------- Profile (kept on this device; sign-in comes later) ---------- */

  const SVG_PERSON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4.5 20c0-3.6 3.4-6 7.5-6s7.5 2.4 7.5 6"/></svg>';
  const SVG_SLIDERS = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/></svg>';
  const SVG_STAR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l2.4 5.6L20 11l-5.6 2.4L12 19l-2.4-5.6L4 11l5.6-2.4z"/></svg>';
  const SVG_IMAGE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="4.5" width="17" height="15" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="M4 17l5-4.5 4 3.5 3-2.5 4 3.5"/></svg>';

  const SVG_TRASH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/></svg>';
  const SVG_CHEV = '<svg viewBox="0 0 9 15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.5 1.5l6 6-6 6"/></svg>';

  const profileFile = document.createElement("input");
  profileFile.type = "file";
  profileFile.accept = "image/*";
  profileFile.hidden = true;
  app.appendChild(profileFile);

  let profileBig = null;      // the large avatar while the Profile sheet is open

  function saveProfile() {
    try { localStorage.setItem(PROFILE_KEY, JSON.stringify(profile)); } catch (e) {}
    refreshProfileRow();
  }
  function savePrefs() {
    try { localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); } catch (e) {}
  }

  function initials(name) {
    const parts = String(name || "").trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return "";
    const first = Array.from(parts[0])[0];
    const last = parts.length > 1 ? Array.from(parts[parts.length - 1])[0] : "";
    return (first + last).toUpperCase();
  }

  function paintAvatar(node) {
    node.style.backgroundImage = profile.photo ? 'url("' + profile.photo + '")' : "";
    node.classList.toggle("has-photo", !!profile.photo);
    node.textContent = "";
    if (profile.photo) return;
    const ini = initials(profile.name);
    if (ini) node.textContent = ini; else node.innerHTML = SVG_PERSON;
  }

  function refreshProfileRow() {
    const av = $("profileAvatar");
    const label = $("profileLabel");
    if (!av || !label) return;
    paintAvatar(av);
    const name = (profile.name || "").trim() || (profile.username ? "@" + profile.username : "");
    if (name) { label.removeAttribute("data-i18n"); label.textContent = name; }
    else { label.setAttribute("data-i18n", "profile"); label.textContent = t("profile"); }
    const subEl = $("profileSub");
    if (subEl) {
      const mail = (profile.email || "").trim();
      const user = profile.username ? "@" + profile.username : "";
      subEl.textContent = mail || ((profile.name || "").trim() ? user : "") || t("profileSub");
    }
  }

  function readAsDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = () => reject(new Error("Could not read image"));
      r.readAsDataURL(blob);
    });
  }

  profileFile.addEventListener("change", () => {
    const f = profileFile.files && profileFile.files[0];
    profileFile.value = "";
    if (f) openCropper(f);
  });

  function navRow(label, svg, onClick) {
    const b = el("button", "row row-nav");
    b.type = "button";
    const left = el("span", "row-label");
    const ic = el("span", "row-ico");
    ic.innerHTML = svg;
    const txt = el("span");
    txt.textContent = label;
    left.append(ic, txt);
    const chev = el("span", "chev");
    chev.innerHTML = SVG_CHEV;
    b.append(left, chev);
    b.addEventListener("click", onClick);
    return b;
  }

  function backLink(label, onClick) {
    const b = el("button", "link-btn back-link");
    b.type = "button";
    b.innerHTML = SVG_CHEV;
    const txt = el("span");
    txt.textContent = label;
    b.appendChild(txt);
    b.addEventListener("click", onClick);
    return b;
  }

  function textRow(value, placeholder, max, onInput) {
    const r = el("div", "row row-text");
    const ta = document.createElement("textarea");
    ta.className = "pref-text";
    ta.rows = 4;
    ta.maxLength = max;
    ta.value = value;
    ta.placeholder = placeholder;
    ta.setAttribute("aria-label", placeholder);
    ta.addEventListener("input", () => onInput(ta.value));
    r.appendChild(ta);
    return r;
  }

  // Add / edit your own model: name, endpoint URL, API key, model ID
  function openCustomModel(editId, { instant = false } = {}) {
    const editing = customModels.find((c) => c.id === editId) || null;
    openSheet(t("cmTitle"), (box) => {
      if (!editing && customModels.length) {
        const list = el("div", "group");
        customModels.forEach((c) => {
          const r = el("button", "row row-nav");
          r.type = "button";
          const nm = el("span"); nm.textContent = c.name || c.modelId;
          const ch = el("span", "chev"); ch.innerHTML = SVG_CHEV;
          r.append(nm, ch);
          r.addEventListener("click", () => openCustomModel(c.id, { instant: true }));
          list.appendChild(r);
        });
        box.appendChild(list);
        box.appendChild(foot(t("cmYours")));
      }
      if (editing) box.appendChild(backLink(t("cmNew"), () => openCustomModel(null, { instant: true })));

      const grp = el("div", "group");
      const field = (label, value, ph, type) => {
        const r = el("div", "row row-cm");
        const l = el("span"); l.textContent = label;
        const i = document.createElement("input");
        i.className = "cm-input"; i.type = type || "text"; i.value = value || ""; i.placeholder = ph || "";
        i.autocomplete = "off"; i.spellcheck = false; i.autocapitalize = "off"; i.dir = "ltr";
        r.append(l, i); grp.appendChild(r);
        return i;
      };
      const fName = field(t("cmName"), editing && editing.name, "My model");
      const fUrl  = field(t("cmEndpoint"), editing && editing.url, "https://api.example.com/v1", "url");
      const fKey  = field(t("cmKey"), editing && editing.key, "sk-…", "password");
      const fId   = field(t("cmModelId"), editing && editing.modelId, "gpt-4o-mini");
      box.appendChild(grp);

      const save = el("button", "cm-save");
      save.type = "button";
      save.textContent = t("cmSave");
      save.addEventListener("click", () => {
        const url = fUrl.value.trim(), modelId = fId.value.trim();
        if (!/^https?:\/\//i.test(url) || !modelId) { showToast(t("cmMissing")); return; }
        const rec = { id: editing ? editing.id : "c_" + Date.now().toString(36), name: fName.value.trim() || modelId, url, key: fKey.value.trim(), modelId };
        if (editing) customModels[customModels.findIndex((c) => c.id === editing.id)] = rec; else customModels.push(rec);
        saveCustomModels();
        model = rec.id; applyModelLogo();
        closeModal();
        showToast(t("switchedTo") + " " + rec.name);
      });
      box.appendChild(save);

      if (editing) {
        const del = el("button", "cm-del");
        del.type = "button";
        del.textContent = t("cmDelete");
        del.addEventListener("click", () => {
          customModels = customModels.filter((c) => c.id !== editing.id);
          saveCustomModels();
          if (model === editing.id) model = "gpt";
          applyModelLogo();
          closeModal();
        });
        box.appendChild(del);
      }
      box.appendChild(foot(t("cmNote")));
    }, { instant });
  }

  /* ---------- Profile: a full-screen page (Apple Account style) with its own back button ---------- */
  const SVG_IDCARD = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="11" r="2"/><path d="M6.2 16c.4-1.4 1.5-2 2.8-2s2.4.6 2.8 2M14.5 10h3.5M14.5 13.5h3.5"/></svg>';
  const SVG_SHIELD = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l7 2.6v5.6c0 4.4-2.9 8-7 9.8-4.1-1.8-7-5.4-7-9.8V5.6z"/><path d="M9.2 12.2l2 2 3.6-4"/></svg>';
  const SVG_SUBS = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M12 8v8M8 12h8"/></svg>';
  const SVG_CLOSE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  const SVG_BACK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>';
  const SVG_CAMERA = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8.5A2.5 2.5 0 0 1 6.5 6h1.2l1.2-1.8h6.2L16.3 6h1.2A2.5 2.5 0 0 1 20 8.5v8a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 16.5z"/><circle cx="12" cy="12.5" r="3.3"/></svg>';

  let acct = null;     // the open profile page: { root, left, title, scroll }

  function acctClose() {
    if (!acct) return;
    const r = acct.root;
    acct = null;
    profileBig = null;
    r.classList.remove("in");
    setTimeout(() => r.remove(), 380);
  }

  // show one page inside the profile screen; back = null on the first page (shows ×), or a function (shows <)
  function acctGo(title, build, { back = null, dir = "push", key = "" } = {}) {
    if (!acct) {
      const root = el("div", "acct");
      root.setAttribute("role", "dialog");
      root.setAttribute("aria-modal", "true");
      const bar = el("div", "ac-bar");
      const left = el("button", "glass tap bar-circle ac-btn");
      left.type = "button";
      const ttl = el("div", "ac-title");
      bar.append(left, ttl, el("span", "bar-circle ac-ghost"));
      const scroll = el("div", "ac-scroll");
      root.append(bar, scroll);
      app.appendChild(root);
      acct = { root, left, title: ttl, scroll };
      requestAnimationFrame(() => requestAnimationFrame(() => root.classList.add("in")));
      dir = "none";
    }
    const A = acct;
    A.key = key;
    A.left.innerHTML = SVG_BACK;
    A.left.classList.add("is-back");
    A.left.setAttribute("aria-label", t("back"));
    A.left.onclick = back || acctClose;
    A.title.textContent = title;
    const page = el("div", "ac-page" + (dir === "push" ? " ac-push" : dir === "pop" ? " ac-pop" : ""));
    build(page);
    A.scroll.innerHTML = "";
    A.scroll.appendChild(page);
    A.scroll.scrollTop = 0;
  }

  // one account row: grey square icon + label, optional value, chevron
  function acctRow(label, { ico = "", value = "", danger = false, onClick } = {}) {
    const b = el("button", "row row-nav ac-row" + (danger ? " danger-row" : ""));
    b.type = "button";
    const left = el("span", "row-label");
    if (ico) { const sq = el("span", "ac-ico"); sq.innerHTML = ico; left.appendChild(sq); }
    const tx = el("span", "ac-txt"); tx.textContent = label;
    left.appendChild(tx);
    b.appendChild(left);
    const trail = el("span", "row-trail");
    if (value) { const v = el("span", "row-value"); v.textContent = value; trail.appendChild(v); }
    if (!danger) { const ch = el("span", "chev"); ch.innerHTML = SVG_CHEV; trail.appendChild(ch); }
    b.appendChild(trail);
    if (onClick) b.addEventListener("click", onClick);
    return b;
  }

  function openProfile({ dir = "push" } = {}) {
    if (!acct) closeModal();      // the page replaces whatever sheet was open (Settings)
    acctGo(t("profile"), (page) => {
      const name = (profile.name || "").trim();
      const user = (profile.username || "").trim();
      const mail = (profile.email || "").trim();

      const hero = el("div", "ac-hero");
      const av = el("button", "avatar avatar-xl");
      av.type = "button";
      av.addEventListener("click", () => openEditProfile());
      paintAvatar(av);
      hero.appendChild(av);
      const nm = el("div", "ac-name" + (name ? "" : " muted"));
      nm.dir = "auto";
      nm.textContent = name || t("yourName");
      hero.appendChild(nm);
      const sub = mail || (user ? "@" + user : "");
      if (sub) { const sb = el("div", "ac-sub"); sb.dir = "ltr"; sb.textContent = sub; hero.appendChild(sb); }
      page.appendChild(hero);

      page.appendChild(group(
        acctRow(t("personalInfo"), { onClick: () => openEditProfile() }),
        acctRow(t("dataSecurity"), { onClick: () => openDataSecurity() })
      ));
      page.appendChild(group(
        acctRow(t("subscription"), { value: t("freePlan"), onClick: () => openPremium() }),
        acctRow(t("personalization"), { onClick: () => openPreferences() })
      ));
      page.appendChild(foot(t("profileNote")));
    }, { back: null, dir });
  }

  // Personal information: photo, name, username, email
  function openEditProfile({ dir = "push" } = {}) {
    acctGo(t("personalInfo"), (page) => {
      const top = el("div", "ac-photo");
      const wrap = el("div", "ac-avwrap");
      const big = el("button", "avatar avatar-lg");
      big.type = "button";
      big.setAttribute("aria-label", profile.photo ? t("changePhoto") : t("choosePhoto"));
      big.addEventListener("click", () => profileFile.click());
      paintAvatar(big);
      profileBig = big;
      const badge = el("span", "ac-badge");
      badge.innerHTML = SVG_CAMERA;
      wrap.append(big, badge);
      top.appendChild(wrap);

      const actions = el("div", "photo-row");
      const pick = el("button", "link-btn");
      pick.type = "button";
      pick.textContent = profile.photo ? t("changePhoto") : t("choosePhoto");
      pick.addEventListener("click", () => profileFile.click());
      actions.appendChild(pick);
      if (profile.photo) {
        const del = el("button", "link-btn danger");
        del.type = "button";
        del.textContent = t("removePhoto");
        del.addEventListener("click", () => { profile.photo = ""; saveProfile(); openEditProfile({ dir: "none" }); });
        actions.appendChild(del);
      }
      top.appendChild(actions);
      page.appendChild(top);

      const mkInput = (max, ph, label) => {
        const i = document.createElement("input");
        i.type = "text";
        i.className = "name-input";
        i.maxLength = max;
        i.autocomplete = "off";
        i.placeholder = ph;
        i.setAttribute("aria-label", label);
        return i;
      };

      const nameInput = mkInput(40, t("yourName"), t("name"));
      nameInput.value = profile.name || "";
      nameInput.addEventListener("input", () => {
        profile.name = nameInput.value;
        saveProfile();
        if (!profile.photo) paintAvatar(big);
      });

      const userInput = mkInput(24, t("usernamePh"), t("username"));
      userInput.autocapitalize = "none";
      userInput.spellcheck = false;
      userInput.dir = "ltr";
      userInput.value = profile.username || "";
      userInput.addEventListener("input", () => {
        const v = userInput.value.toLowerCase().replace(/[^a-z0-9._]/g, "").slice(0, 24);
        if (v !== userInput.value) userInput.value = v;
        profile.username = v;
        saveProfile();
      });
      const userWrap = el("span", "user-wrap");
      const at = el("span", "user-at");
      at.textContent = "@";
      const sizer = el("span", "user-sizer");
      const fit = () => { sizer.dataset.v = userInput.value || userInput.placeholder; };
      userInput.addEventListener("input", fit);
      fit();
      sizer.appendChild(userInput);
      userWrap.append(at, sizer);

      const mailInput = mkInput(80, t("emailPh"), t("email"));
      mailInput.type = "email";
      mailInput.inputMode = "email";
      mailInput.autocapitalize = "none";
      mailInput.spellcheck = false;
      mailInput.dir = "ltr";
      mailInput.value = profile.email || "";
      mailInput.addEventListener("input", () => {
        profile.email = mailInput.value.trim();
        saveProfile();
      });

      const ageInput = mkInput(3, t("agePh"), t("age"));
      ageInput.type = "text";
      ageInput.inputMode = "numeric";
      ageInput.dir = "ltr";
      ageInput.value = profile.age || "";
      ageInput.addEventListener("input", () => {
        const v = ageInput.value.replace(/\D/g, "").slice(0, 3);
        if (v !== ageInput.value) ageInput.value = v;
        profile.age = v;
        saveProfile();
      });

      page.appendChild(group(row(t("name"), nameInput), row(t("age"), ageInput), row(t("username"), userWrap), row(t("email"), mailInput)));
      page.appendChild(foot(t("usernameNote")));
      page.appendChild(foot(t("emailNote")));
    }, { back: () => openProfile({ dir: "pop" }), dir });
  }

  // Data & security: privacy switches, Memory, Uploaded files, export, manage local data
  function openDataSecurity({ dir = "push" } = {}) {
    acctGo(t("dataSecurity"), (page) => {
      page.appendChild(section(t("dsPrivacy")));
      page.appendChild(group(
        row(t("saveHistory"), toggle(settings.saveHistory, (v) => { settings.saveHistory = v; saveSettings(); }, t("saveHistory"))),
        row(t("rememberAcross"), toggle(settings.memory, (v) => { settings.memory = v; saveSettings(); }, t("rememberAcross")))
      ));
      page.appendChild(foot(t("saveHistoryNote")));

      page.appendChild(group(
        acctRow(t("memory"), { onClick: () => { modal.style.zIndex = "85"; openMemory(); } }),
        acctRow(t("files"), { onClick: () => { modal.style.zIndex = "85"; openFiles(); } })
      ));

      page.appendChild(group(
        acctRow(t("exportChats"), { onClick: () => exportChats() }),
        acctRow(t("manageData"), { onClick: () => openManageDataPage() })
      ));
      page.appendChild(foot(t("dsNote")));
    }, { back: () => openProfile({ dir: "pop" }), dir });
  }

  // re-run something when the sheet that was opened on top of the profile page is closed
  function afterModalClose(fn) {
    const mo = new MutationObserver(() => { if (modal.hidden) { mo.disconnect(); fn(); } });
    mo.observe(modal, { attributes: true, attributeFilter: ["hidden"] });
  }

  // Manage local data: every kind of data can be cleared here, and everything can be wiped
  async function openManageDataPage({ dir = "push" } = {}) {
    let pics = [];
    try { pics = (await PicDB.all()) || []; } catch (e) {}
    const picBytes = pics.reduce((n, r) => n + ((r.blob && r.blob.size) || 0), 0);
    let chatBytes = 0;
    try { chatBytes = (localStorage.getItem(CHATS_KEY) || "").length * 2; } catch (e) {}
    const trashN = trash.chats.length + trash.files.length;
    const cache = cacheKeys();

    acctGo(t("manageData"), (page) => {
      const again = () => { if (acct && acct.key === "manage") openManageDataPage({ dir: "none" }); };
      const ask = (title, msg, label, fn) => settingsAlert(title, msg, [{ label: t("cancel") }, { label, danger: true, onClick: fn }]);

      page.appendChild(group(
        acctRow(t("mdChats"), { value: chats.length + " · " + fmtBytes(chatBytes), onClick: () => {
          if (busy) { showToast(t("chatBusy")); return; }
          if (!chats.length) { showToast(t("mdEmpty")); return; }
          ask(t("clearHistTitle"), t("clearHistMsg"), t("clearBtn"), () => {
            trashChats(chats.map((c) => c.id));
            startChat();
            renderChatList();
            showToast(t("clearHistDone"));
            again();
          });
        } }),
        acctRow(t("mdPics"), { value: pics.length + " · " + fmtBytes(picBytes), onClick: () => {
          if (!pics.length) { showToast(t("mdEmpty")); return; }
          ask(t("mdPicsTitle"), t("mdPicsMsg"), t("delete"), async () => {
            const all = (await PicDB.all().catch(() => [])) || [];
            await eraseFiles(all.map((r) => ({ kind: "db", id: r.id })));
            trash.files = trash.files.filter((f) => f.kind !== "db");
            writeTrash();
            showToast(t("mdDone"));
            again();
          });
        } }),
        acctRow(t("mdTrash"), { value: String(trashN), onClick: () => {
          modal.style.zIndex = "85";
          openTrash();
          afterModalClose(again);
        } }),
        acctRow(t("mdCache"), { value: String(cache.length), onClick: () => {
          if (!cache.length) { showToast(t("mdEmpty")); return; }
          ask(t("mdCacheTitle"), t("mdCacheMsg"), t("delete"), () => {
            cacheKeys().forEach((k) => { try { localStorage.removeItem(k); } catch (e) {} });
            showToast(t("mdDone"));
            again();
          });
        } })
      ));
      page.appendChild(foot(t("mdPageNote")));

      page.appendChild(group(
        acctRow(t("deleteAllData"), { danger: true, onClick: () => deleteAllLocalData() })
      ));
    }, { back: () => openDataSecurity({ dir: "pop" }), dir, key: "manage" });
  }

  // Photo cropper: drag to move, pinch / wheel to zoom, then the round part is saved
  function openCropper(file) {
    shrinkImage(file, 1400).then((blob) => {
      const url = URL.createObjectURL(blob);
      const im = new Image();
      im.onload = () => buildCropper(url, im);
      im.onerror = () => { URL.revokeObjectURL(url); showToast(t("aiError")); };
      im.src = url;
    }).catch((e) => { console.error("[iMa! profile photo]", e); showToast(t("aiError")); });
  }

  function buildCropper(url, im) {
    const V = 256, OUT = 256, MAXZ = 4;
    const iw = im.naturalWidth, ih = im.naturalHeight;
    const sMin = Math.max(V / iw, V / ih);
    let z = 1;
    let x = (V - iw * sMin) / 2;
    let y = (V - ih * sMin) / 2;
    const release = () => URL.revokeObjectURL(url);

    acctGo(t("adjustPhoto"), (box) => {

      const stage = el("div", "crop-stage");
      const img = document.createElement("img");
      img.src = url;
      img.alt = "";
      img.draggable = false;
      img.style.width = iw + "px";
      img.style.height = ih + "px";
      stage.append(img, el("div", "crop-ring"));
      const wrap = el("div", "crop-wrap");
      wrap.appendChild(stage);
      box.appendChild(wrap);

      const clamp = () => {
        const s = sMin * z;
        x = Math.min(0, Math.max(V - iw * s, x));
        y = Math.min(0, Math.max(V - ih * s, y));
      };
      const render = () => {
        clamp();
        img.style.transform = "translate(" + x + "px, " + y + "px) scale(" + (sMin * z) + ")";
      };
      const zoomAt = (cx, cy, nz) => {
        nz = Math.min(MAXZ, Math.max(1, nz));
        const so = sMin * z, sn = sMin * nz;
        const px = (cx - x) / so, py = (cy - y) / so;
        x = cx - px * sn;
        y = cy - py * sn;
        z = nz;
        render();
      };

      const pts = new Map();
      let lastDist = 0;
      stage.addEventListener("pointerdown", (e) => {
        try { stage.setPointerCapture(e.pointerId); } catch (err) {}
        pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
        lastDist = 0;
      });
      stage.addEventListener("pointermove", (e) => {
        const p = pts.get(e.pointerId);
        if (!p) return;
        if (pts.size === 1) {
          x += e.clientX - p.x;
          y += e.clientY - p.y;
          p.x = e.clientX; p.y = e.clientY;
          render();
        } else if (pts.size === 2) {
          p.x = e.clientX; p.y = e.clientY;
          const [a, b] = Array.from(pts.values());
          const d = Math.hypot(a.x - b.x, a.y - b.y);
          if (lastDist) {
            const r = stage.getBoundingClientRect();
            zoomAt((a.x + b.x) / 2 - r.left, (a.y + b.y) / 2 - r.top, z * d / lastDist);
          }
          lastDist = d;
        }
      });
      const lift = (e) => { pts.delete(e.pointerId); lastDist = 0; };
      stage.addEventListener("pointerup", lift);
      stage.addEventListener("pointercancel", lift);
      stage.addEventListener("wheel", (e) => {
        e.preventDefault();
        const r = stage.getBoundingClientRect();
        zoomAt(e.clientX - r.left, e.clientY - r.top, z * (e.deltaY < 0 ? 1.08 : 1 / 1.08));
      }, { passive: false });

      const hint = el("p", "foot crop-hint");
      hint.textContent = t("cropHint");
      box.appendChild(hint);

      const use = el("button", "crop-use");
      use.type = "button";
      use.textContent = t("usePhoto");
      use.addEventListener("click", () => {
        const c = document.createElement("canvas");
        c.width = c.height = OUT;
        const s = sMin * z;
        c.getContext("2d").drawImage(im, -x / s, -y / s, V / s, V / s, 0, 0, OUT, OUT);
        profile.photo = c.toDataURL("image/jpeg", 0.9);
        saveProfile();
        release();
        openEditProfile({ dir: "pop" });
      });
      box.appendChild(use);

      render();
    }, { back: () => { release(); openEditProfile({ dir: "pop" }); } });
  }

  // Personalization: base style and tone, characteristics, then your own words
  const PREF_STYLES = [
    ["default", "toneDefault", "stSubDefault"], ["friendly", "toneFriendly", "stSubFriendly"], ["professional", "stProfessional", "stSubProfessional"],
    ["casual", "toneCasual", "stSubCasual"], ["candid", "stCandid", "stSubCandid"], ["quirky", "stQuirky", "stSubQuirky"],
    ["efficient", "stEfficient", "stSubEfficient"], ["nerdy", "stNerdy", "stSubNerdy"]
  ];
  // [key, label, word for "more", word for "less"]
  const PREF_CHARS = [
    ["warm", "prefWarm", "prefMore", "prefLess"], ["enthusiastic", "prefEnthusiastic", "prefMore", "prefLess"],
    ["lists", "prefLists", "prefMore", "prefLess"], ["emoji", "prefEmoji", "prefMore", "prefLess"],
    ["humor", "prefHumor", "prefMore", "prefLess"], ["length", "prefLength", "prefLonger", "prefShorter"],
    ["examples", "prefExamples", "prefMore", "prefFewer"]
  ];

  // a list of choices on its own page; the chosen one has a check
  function openPrefPicker(title, options, current, onPick, note) {
    acctGo(title, (page) => {
      const g = el("div", "group");
      options.forEach((o) => {
        const b = el("button", "row row-nav ac-pick");
        b.type = "button";
        const col = el("span", "ac-pick-txt");
        const l1 = el("span", "ac-pick-main"); l1.textContent = o.label;
        col.appendChild(l1);
        if (o.sub) { const l2 = el("span", "ac-pick-sub"); l2.textContent = o.sub; col.appendChild(l2); }
        const ck = el("span", "ac-check");
        if (o.value === current) ck.innerHTML = SVG_CHECK;
        b.append(col, ck);
        b.addEventListener("click", () => { onPick(o.value); openPreferences({ dir: "pop" }); });
        g.appendChild(b);
      });
      page.appendChild(g);
      if (note) page.appendChild(foot(note));
    }, { back: () => openPreferences({ dir: "pop" }) });
  }

  function openPreferences({ dir = "push" } = {}) {
    acctGo(t("personalization"), (box) => {
      const styleOpts = PREF_STYLES.map(([v, l, sb]) => ({ value: v, label: t(l), sub: t(sb) }));
      const curStyle = PREF_STYLES.find((x) => x[0] === prefs.tone) || PREF_STYLES[0];
      box.appendChild(group(
        acctRow(t("baseStyle"), { value: t(curStyle[1]), onClick: () => openPrefPicker(t("baseStyle"), styleOpts, curStyle[0], (v) => { prefs.tone = v; savePrefs(); }, t("baseStyleNote")) })
      ));
      box.appendChild(foot(t("baseStyleNote")));

      box.appendChild(section(t("characteristics")));
      const g = el("div", "group");
      PREF_CHARS.forEach(([key, label, more, less]) => {
        const cur = (prefs.chars || {})[key] === "more" || (prefs.chars || {})[key] === "less" ? prefs.chars[key] : "default";
        const opts = [
          { value: "more", label: t(more) },
          { value: "default", label: t("prefDefault") },
          { value: "less", label: t(less) }
        ];
        const shown = cur === "more" ? t(more) : cur === "less" ? t(less) : t("prefDefault");
        g.appendChild(acctRow(t(label), { value: shown, onClick: () => openPrefPicker(t(label), opts, cur, (v) => {
          prefs.chars = Object.assign({}, prefs.chars, { [key]: v });
          savePrefs();
        }, t("charNote")) }));
      });
      box.appendChild(g);
      box.appendChild(foot(t("charNote")));

      box.appendChild(section(t("persSec")));
      box.appendChild(group(textRow(prefs.instructions, t("instrPh"), 800, (v) => { prefs.instructions = v; savePrefs(); })));

      box.appendChild(section(t("aboutYou")));
      box.appendChild(group(textRow(prefs.about, t("aboutPh"), 600, (v) => { prefs.about = v; savePrefs(); })));

      box.appendChild(foot(t("prefNote")));
    }, { back: () => openProfile({ dir: "pop" }), dir });
  }

  // Subscription: the normal (free) plan and Premium iMa!
  function openPremium() {
    acctGo(t("subscription"), (box) => {
      const free = el("div", "plan-card current");
      const fh = el("div", "plan-head");
      const fn = el("div", "plan-title"); fn.textContent = t("freePlan");
      const fb = el("span", "plan-badge"); fb.textContent = t("currentPlan");
      fh.append(fn, fb);
      const fd = el("div", "plan-desc"); fd.textContent = t("freeDesc");
      free.append(fh, fd);
      box.appendChild(free);

      const prem = el("div", "plan-card");
      const ph = el("div", "plan-head");
      const pt = el("div", "plan-title plan-title-ico");
      const pi = el("span", "plan-ico"); pi.innerHTML = SVG_STAR;
      const pn = el("span"); pn.textContent = t("premium");
      pt.append(pi, pn);
      const price = el("div", "plan-price");
      const amount = el("b"); amount.dir = "ltr"; amount.textContent = "$10";
      const per = el("span"); per.textContent = t("perMonth");
      price.append(amount, per);
      ph.append(pt, price);
      const pd = el("div", "plan-desc"); pd.textContent = t("premiumFeatures");
      const up = el("button", "plan-btn");
      up.type = "button";
      up.textContent = t("upgrade");
      up.addEventListener("click", () => showToast(t("premiumSoon")));
      prem.append(ph, pd, up);
      box.appendChild(prem);

      box.appendChild(foot(t("premiumSoon")));
    }, { back: () => openProfile({ dir: "pop" }) });
  }

  /* ---------- Language: a row (like Region) that opens a sheet sliding up, just like Profile ---------- */

  const LANG_OPTIONS = [
    { value: "en", label: "English" },
    { value: "ar", label: "العربية" }
  ];
  const SVG_CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

  function languageRow() {
    const cur = LANG_OPTIONS.find((o) => o.value === settings.lang) || LANG_OPTIONS[0];
    const b = el("button", "row row-nav lang-row");
    b.type = "button";
    const label = el("span", "row-label");
    label.textContent = t("language");
    const trail = el("span", "row-trail");
    const val = el("span", "row-value");
    val.textContent = cur.label;
    const chev = el("span", "chev");
    chev.innerHTML = SVG_CHEV;
    trail.append(val, chev);
    b.append(label, trail);
    b.addEventListener("click", () => { modal.style.zIndex = "85"; openLanguage(); });
    return b;
  }

  function openLanguage() {
    openSheet(t("language"), (box) => {
      const rows = LANG_OPTIONS.map((o) => {
        const b = el("button", "row row-nav lang-opt" + (o.value === settings.lang ? " on" : ""));
        b.type = "button";
        const txt = el("span", "row-label");
        txt.textContent = o.label;
        const tick = el("span", "lang-check");
        tick.innerHTML = SVG_CHECK;
        b.append(txt, tick);
        b.addEventListener("click", () => {
          rows.forEach((r) => r.classList.toggle("on", r === b));
          if (o.value === settings.lang) { setTimeout(closeModal, 140); return; }
          // brief pause so the tick moves before the sheet slides away
          setTimeout(() => {
            closeModal();
            settings.lang = o.value;
            saveSettings();
            closeMenu();
            applyLang();
            refreshSettings();
          }, 160);
        });
        return b;
      });
      box.appendChild(group(...rows));
    });
  }

  /* ---------- Photo background options (iOS-style rows + blur slider) ---------- */


  const SVG_VIDEO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="6" width="13" height="12" rx="3"/><path d="M16 10.5l5-3v9l-5-3"/></svg>';

  function photoNavRow(label, url, picker = bgFile, onRemove = null) {
    const b = el(onRemove ? "div" : "button", onRemove ? "row photo-opt photo-split" : "row row-nav photo-opt");
    if (!onRemove) b.type = "button";
    const left = el("span", "row-label");
    if (url) {
      const th = el("span", "photo-opt-thumb");
      th.style.backgroundImage = `url("${url}")`;
      left.appendChild(th);
    } else {
      const ic = el("span", "row-ico");
      ic.innerHTML = picker === bgVideoFile ? SVG_VIDEO : SVG_IMAGE;
      left.appendChild(ic);
    }
    const txt = el("span");
    txt.textContent = label;
    left.appendChild(txt);
    if (onRemove) {
      const main = el("button", "photo-main");
      main.type = "button";
      main.appendChild(left);
      main.addEventListener("click", () => picker.click());
      const rm = el("button", "photo-rm");
      rm.type = "button";
      rm.textContent = t("removePhoto");
      rm.addEventListener("click", onRemove);
      b.append(main, rm);
      return b;
    }
    const chev = el("span", "chev");
    chev.innerHTML = SVG_CHEV;
    b.append(left, chev);
    b.addEventListener("click", () => picker.click());
    return b;
  }

  function blurRow() {
    const r = el("div", "row slider-row");
    const lab = el("span", "slider-label");
    lab.textContent = t("blur");
    const s = document.createElement("input");
    s.type = "range";
    s.min = "0"; s.max = "100"; s.step = "1";
    s.value = String(Number(settings.photoBlur) || 0);
    s.className = "blur-slider";
    s.dir = "ltr";
    s.setAttribute("aria-label", t("photoBlur"));
    s.style.setProperty("--v", String((Number(s.value)) / 100));
    s.addEventListener("input", () => {
      settings.photoBlur = Number(s.value);
      s.style.setProperty("--v", String(Number(s.value) / 100));
      applyPhotoBlur();
    });
    s.addEventListener("change", saveSettings);
    r.append(lab, s);
    return r;
  }

  // "Reset" row: puts the listed settings back to the app defaults
  function resetRow(label, keys) {
    const b = el("button", "row row-nav reset-row");
    b.type = "button";
    b.textContent = label;
    b.addEventListener("click", () => {
      keys.forEach((k) => { settings[k] = DEFAULTS[k]; });
      saveSettings(); applyTheme(); refreshSettings();
    });
    return b;
  }

  // slider + typed value, bound to settings[key]; applies live
  function rangeRow(label, key, min, max, unit, step = 1) {
    const dec = step < 1 ? (String(step).split(".")[1] || "").length : 0;   // 0.1 -> 1 decimal
    const r = el("div", "row range-row");
    const head = el("div", "range-head");
    const lab = el("span"); lab.textContent = label;
    const val = el("span", "range-val");
    const num = document.createElement("input");
    num.className = "range-num";
    if (dec) { num.type = "text"; num.inputMode = "decimal"; }              // so both 0.5 and 0,5 can be typed
    else { num.type = "number"; num.inputMode = "numeric"; num.min = String(min); num.max = String(max); num.step = "1"; }
    num.setAttribute("aria-label", label);
    val.appendChild(num);
    if (unit) { const u = el("span", "range-unit"); u.textContent = unit; val.appendChild(u); }
    head.append(lab, val);

    const s = document.createElement("input");
    s.type = "range"; s.min = String(min); s.max = String(max); s.step = String(step);
    s.className = "blur-slider"; s.dir = "ltr";
    s.setAttribute("aria-label", label);

    const cur = Number(settings[key]);
    const set = (v, fromNum) => {
      v = Number(String(v).replace(",", "."));
      if (!isFinite(v)) return;
      v = Math.max(min, Math.min(max, Number((Math.round(v / step) * step).toFixed(dec))));
      settings[key] = v;
      s.value = String(v);
      if (!fromNum) num.value = String(v);
      s.style.setProperty("--v", String((v - min) / (max - min)));
      applyTheme();
    };
    s.value = String(isFinite(cur) ? cur : DEFAULTS[key]);
    num.value = s.value;
    s.style.setProperty("--v", String((Number(s.value) - min) / (max - min)));
    s.addEventListener("input", () => set(s.value));
    num.addEventListener("input", () => { if (num.value !== "") set(num.value, true); });
    num.addEventListener("blur", () => { num.value = s.value; });
    s.addEventListener("change", saveSettings);
    num.addEventListener("change", saveSettings);
    r.append(head, s);
    return r;
  }

  function group(...rows) {
    const g = el("div", "group");
    rows.forEach((r) => g.appendChild(r));
    return g;
  }

  function row(label, control) {
    const r = el("div", "row");
    const l = el("span"); l.textContent = label;
    r.append(l, control);
    return r;
  }

  function toggle(value, onChange, label) {
    const b = el("button", "switch");
    b.type = "button";
    b.setAttribute("role", "switch");
    b.setAttribute("aria-label", label);
    b.setAttribute("aria-checked", String(value));
    b.addEventListener("click", () => {
      value = !value;
      b.setAttribute("aria-checked", String(value));
      onChange(value);
    });
    return b;
  }

  function foot(text) {
    const p = el("p", "foot");
    p.textContent = text;
    return p;
  }

  function section(text) {
    const p = el("div", "sect");
    p.textContent = text;
    return p;
  }

  // segmented control: options = [{ value, label }]
  function segmented(label, options, value, onChange) {
    const wrap = el("div", "seg");
    wrap.setAttribute("role", "radiogroup");
    wrap.setAttribute("aria-label", label);
    const thumb = el("span", "seg-thumb");
    thumb.setAttribute("aria-hidden", "true");
    wrap.style.setProperty("--n", String(options.length));
    wrap.style.setProperty("--i", String(Math.max(0, options.findIndex((o) => o.value === value))));
    wrap.appendChild(thumb);
    options.forEach((o, idx) => {
      const b = el("button");
      b.type = "button";
      b.textContent = o.label;
      b.setAttribute("role", "radio");
      b.setAttribute("aria-checked", String(o.value === value));
      b.addEventListener("click", () => {
        wrap.querySelectorAll("button").forEach((n) => n.setAttribute("aria-checked", "false"));
        b.setAttribute("aria-checked", "true");
        wrap.style.setProperty("--i", String(idx));
        onChange(o.value);
      });
      wrap.appendChild(b);
    });
    return wrap;
  }

  /* ---------- App font: upload a .ttf / .otf / .woff file, or paste a web font link ---------- */
  const FONT_DEF_TEXT = '"iMa Sans", "iMa Arabic", "SF Pro Text", -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif';
  const FONT_DEF_DISPLAY = '"iMa Sans", "iMa Arabic", "SF Pro Text", -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif';
  let fontFace = null, fontLinkEl = null;
  const fontDB = {
    get()     { return photoDB.run("readonly",  (s) => s.get("appFont")).catch(() => null); },
    set(blob) { return photoDB.run("readwrite", (s) => s.put(blob, "appFont")).catch(() => null); },
    remove()  { return photoDB.run("readwrite", (s) => s.delete("appFont")).catch(() => null); }
  };
  function clearFontNodes() {
    if (fontFace) { try { document.fonts.delete(fontFace); } catch (e) {} fontFace = null; }
    if (fontLinkEl) { fontLinkEl.remove(); fontLinkEl = null; }
  }
  function setFontFamily(fam) {
    const st = document.documentElement.style;
    if (!fam) { st.removeProperty("--font-text"); st.removeProperty("--font-display"); return; }
    const q = '"' + String(fam).replace(/"/g, "") + '"';
    st.setProperty("--font-text", q + ", " + FONT_DEF_TEXT);
    st.setProperty("--font-display", q + ", " + FONT_DEF_DISPLAY);
  }
  // a variable font (has an "fvar" table) can serve every weight; a static one stays at 400 and the browser makes the bold
  function isVariableFont(buf) {
    try {
      const v = new DataView(buf), n = v.getUint16(4);
      for (let i = 0; i < n; i++) { const o = 12 + i * 16; if (String.fromCharCode(v.getUint8(o), v.getUint8(o + 1), v.getUint8(o + 2), v.getUint8(o + 3)) === "fvar") return true; }
    } catch (e) {}
    return false;
  }
  async function loadFontBlob(blob) {
    const buf = await blob.arrayBuffer();
    const ff = new FontFace("iMa Custom", buf, { weight: isVariableFont(buf) ? "100 900" : "400" });
    await ff.load();
    clearFontNodes();
    document.fonts.add(ff); fontFace = ff;
    setFontFamily("iMa Custom");
  }
  async function loadFontLink(url, nameHint) {
    url = String(url || "").trim();
    if (!/^https?:\/\//i.test(url)) throw new Error("link");
    if (/\.(ttf|otf|woff2?)(\?|#|$)/i.test(url)) {            // a direct font file
      const ff = new FontFace("iMa Custom", "url(" + JSON.stringify(url) + ")", { weight: "100 900" });
      await ff.load();
      clearFontNodes();
      document.fonts.add(ff); fontFace = ff;
      setFontFamily("iMa Custom");
      return "iMa Custom";
    }
    let fam = String(nameHint || "").trim();                   // a stylesheet link (Google Fonts, Fontshare...)
    if (!fam) { try { const f = new URL(url).searchParams.get("family"); if (f) fam = f.split("|")[0].split(":")[0].replace(/\+/g, " "); } catch (e) {} }
    if (!fam) throw new Error("name");
    const link = document.createElement("link");
    link.rel = "stylesheet"; link.href = url;
    await new Promise((ok, fail) => { link.onload = ok; link.onerror = () => { link.remove(); fail(new Error("load")); }; document.head.appendChild(link); });
    try { await document.fonts.load('16px "' + fam.replace(/"/g, "") + '"'); } catch (e) {}
    clearFontNodes();
    fontLinkEl = link;
    setFontFamily(fam);
    return fam;
  }
  async function restoreFont() {
    const cf = settings.customFont;
    if (!cf) return;
    try {
      if (cf.kind === "file") { const b = await fontDB.get(); if (b) await loadFontBlob(b); }
      else if (cf.kind === "link") await loadFontLink(cf.url, cf.family);
    } catch (e) {}
  }
  restoreFont();

  function openFontSheet({ instant = false } = {}) {
    modal.style.zIndex = "85";                                  // above the Settings page
    openSheet(t("appFont"), (box) => {
      const cf = settings.customFont;
      const info = el("div", "group");
      const cur = el("div", "row");
      const l = el("span"); l.textContent = t("appFont");
      const v = el("span", "font-cur"); v.textContent = cf ? cf.label : t("fontDefault"); v.dir = "auto";
      cur.append(l, v); info.appendChild(cur);
      box.appendChild(info);

      const fileIn = document.createElement("input");
      fileIn.type = "file"; fileIn.hidden = true; fileIn.accept = ".ttf,.otf,.woff,.woff2,font/ttf,font/otf,font/woff,font/woff2";
      const up = el("button", "cm-save");
      up.type = "button"; up.textContent = t("fontUpload");
      up.addEventListener("click", () => fileIn.click());
      fileIn.addEventListener("change", async () => {
        const f = fileIn.files && fileIn.files[0];
        fileIn.value = "";
        if (!f) return;
        try {
          await loadFontBlob(f);
          await fontDB.set(f);
          settings.customFont = { kind: "file", label: f.name };
          saveSettings(); showToast(t("fontApplied"));
          openFontSheet({ instant: true });
        } catch (e) { showToast(t("fontBad")); }
      });
      box.append(up, fileIn);

      const grp = el("div", "group");
      const field = (label, value, ph) => {
        const r = el("div", "row row-cm");
        const s = el("span"); s.textContent = label;
        const i = document.createElement("input");
        i.className = "cm-input"; i.type = "text"; i.value = value || ""; i.placeholder = ph;
        i.autocomplete = "off"; i.spellcheck = false; i.autocapitalize = "off"; i.dir = "ltr";
        r.append(s, i); grp.appendChild(r);
        return i;
      };
      const fLink = field(t("fontLink"), cf && cf.kind === "link" ? cf.url : "", "https://fonts.googleapis.com/css2?family=Cairo");
      const fName = field(t("fontName"), cf && cf.kind === "link" && cf.family !== "iMa Custom" ? cf.family : "", "Cairo");
      box.appendChild(grp);

      const use = el("button", "cm-sec");
      use.type = "button"; use.textContent = t("fontUse");
      use.addEventListener("click", async () => {
        const url = fLink.value.trim();
        if (!url) { showToast(t("fontBad")); return; }
        use.disabled = true;
        try {
          const fam = await loadFontLink(url, fName.value);
          await fontDB.remove();
          settings.customFont = { kind: "link", url, family: fam, label: fam };
          saveSettings(); showToast(t("fontApplied"));
          openFontSheet({ instant: true });
        } catch (e) { use.disabled = false; showToast(e && e.message === "name" ? t("fontNeedName") : t("fontBad")); }
      });
      box.appendChild(use);

      if (cf) {
        const rs = el("button", "cm-del");
        rs.type = "button"; rs.textContent = t("fontReset");
        rs.addEventListener("click", async () => {
          clearFontNodes(); setFontFamily("");
          await fontDB.remove();
          delete settings.customFont; saveSettings();
          openFontSheet({ instant: true });
        });
        box.appendChild(rs);
      }
      box.appendChild(foot(t("fontNote")));
    }, { instant });
  }

  /* ---------- Custom color picker (in-app, replaces the browser one) ---------- */

  function hsvToHex(h, s, v) {
    const f = (n) => {
      const k = (n + h / 60) % 6;
      const c = v - v * s * Math.max(0, Math.min(k, 4 - k, 1));
      return Math.round(c * 255).toString(16).padStart(2, "0");
    };
    return "#" + f(5) + f(3) + f(1);
  }
  function hexToHsv(hex) {
    const r = parseInt(hex.slice(1, 3), 16) / 255, g = parseInt(hex.slice(3, 5), 16) / 255, b = parseInt(hex.slice(5, 7), 16) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d) {
      if (mx === r) h = ((g - b) / d + 6) % 6;
      else if (mx === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return { h, s: mx ? d / mx : 0, v: mx };
  }

  function openColorSheet(title, start, onPick) {
    const init = /^#[0-9a-f]{6}$/i.test(start) ? start : "#a855f7";
    let { h, s, v } = hexToHsv(init);

    modal.style.zIndex = "85";          // above the Settings page
    openSheet(title, (box) => {
      const wrap = el("div", "colp");

      const area = el("div", "colp-area");
      const areaKnob = el("div", "colp-knob");
      area.appendChild(areaKnob);

      const hue = el("div", "colp-hue");
      const hueKnob = el("div", "colp-knob colp-knob-h");
      hue.appendChild(hueKnob);

      const foot = el("div", "colp-foot");
      const prev = el("div", "colp-prev");
      const hexWrap = el("label", "colp-hex");
      const hash = el("span"); hash.textContent = "#";
      const hexIn = el("input");
      hexIn.type = "text"; hexIn.maxLength = 6; hexIn.spellcheck = false;
      hexIn.autocomplete = "off"; hexIn.setAttribute("autocapitalize", "off");
      hexIn.setAttribute("aria-label", "Hex");
      hexIn.dir = "ltr";
      hexWrap.append(hash, hexIn);
      foot.append(prev, hexWrap);

      wrap.append(area, hue, foot);
      box.appendChild(wrap);

      function paint(fromHex) {
        const hex = hsvToHex(h, s, v);
        area.style.setProperty("--hue", hsvToHex(h, 1, 1));
        areaKnob.style.left = (s * 100) + "%";
        areaKnob.style.top = ((1 - v) * 100) + "%";
        areaKnob.style.background = hex;
        hueKnob.style.left = (h / 360 * 100) + "%";
        hueKnob.style.background = hsvToHex(h, 1, 1);
        prev.style.background = hex;
        if (!fromHex) hexIn.value = hex.slice(1).toUpperCase();
        return hex;
      }
      function commitColor(fromHex) { onPick(paint(fromHex)); }

      function drag(node, move) {
        node.style.touchAction = "none";
        node.addEventListener("pointerdown", (e) => {
          e.preventDefault();
          node.setPointerCapture(e.pointerId);
          const go = (ev) => {
            const r = node.getBoundingClientRect();
            move(Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width)),
                 Math.min(1, Math.max(0, (ev.clientY - r.top) / r.height)));
            commitColor(false);
          };
          go(e);
          const up = () => {
            node.removeEventListener("pointermove", go);
            node.removeEventListener("pointerup", up);
            node.removeEventListener("pointercancel", up);
          };
          node.addEventListener("pointermove", go);
          node.addEventListener("pointerup", up);
          node.addEventListener("pointercancel", up);
        });
      }
      drag(area, (x, y) => { s = x; v = 1 - y; });
      drag(hue, (x) => { h = x * 359.999; });

      hexIn.addEventListener("input", () => {
        hexIn.value = hexIn.value.replace(/[^0-9a-f]/gi, "").slice(0, 6).toUpperCase();
        if (hexIn.value.length === 6) {
          ({ h, s, v } = hexToHsv("#" + hexIn.value));
          commitColor(true);
        }
      });
      hexIn.addEventListener("blur", () => { hexIn.value = hsvToHex(h, s, v).slice(1).toUpperCase(); });

      paint(false);
    });
  }

  // a row of preset colors + a rainbow "any color" picker
  function colorRow(label, presets, value, onChange) {
    const sw = el("div", "swatches");
    sw.setAttribute("role", "radiogroup");
    sw.setAttribute("aria-label", label);

    const buttons = [];
    const custom = el("button", "swatch custom");
    custom.type = "button";
    custom.setAttribute("role", "radio");
    custom.setAttribute("aria-label", t("customColor"));
    const picker = { value: /^#[0-9a-f]{6}$/i.test(value) ? value : "#000000" };

    function select(v) {
      v = v.toLowerCase();
      let matched = false;
      buttons.forEach((b) => {
        const on = b.dataset.v === v;
        if (on) matched = true;
        b.setAttribute("aria-checked", String(on));
      });
      custom.classList.toggle("on", !matched);
      custom.setAttribute("aria-checked", String(!matched));
      custom.style.setProperty("--picked", v);
    }

    presets.forEach(([val, en, ar]) => {
      const b = el("button", "swatch" + (luminance(val) < 0.02 ? " dark" : ""));
      b.type = "button";
      b.style.background = val;
      b.dataset.v = val.toLowerCase();
      b.setAttribute("role", "radio");
      b.setAttribute("aria-label", isRTL() ? ar : en);
      b.addEventListener("click", () => { select(val); picker.value = val; onChange(val); });
      buttons.push(b);
      sw.appendChild(b);
    });

    custom.addEventListener("click", () => {
      openColorSheet(t("customColor"), picker.value, (v) => { picker.value = v; select(v); onChange(v); });
    });
    sw.appendChild(custom);

    select(value);
    return row(label, sw);
  }

  let settingsOpen = false;
  let devOpen = false;
  let optOpen = null;   // which Chat theme / Bubbles / Messaging accordion is open
  let genOpen = null;   // which General accordion is open: "appearance" | "data" | null

  // rebuild the settings page in place (after language change, new photo, …)
  function refreshSettings() {
    if (!settingsOpen) return;
    const body = app.querySelector(".sp-body");
    const top = body ? body.scrollTop : 0;
    openSettings({ instant: true });
    const again = app.querySelector(".sp-body");
    if (again) again.scrollTop = top;
  }

  function closeSettings() {
    const page = app.querySelector(".sp");
    settingsOpen = false;
    if (!page) return;
    page.classList.add("closing");
    setTimeout(() => page.remove(), 220);
  }

  /* Settings is its own page (same background, back "<" on the top-left), not a bottom sheet */
  function openSettings({ instant = false } = {}) {
    let page = app.querySelector(".sp:not(.closing)");
    if (!page) {
      page = el("div", "cp sp");
      page.setAttribute("role", "dialog");
      const bar = el("div", "cp-bar");
      const back = el("button", "glass tap bar-circle");
      back.type = "button";
      back.innerHTML = BACK;
      back.addEventListener("click", closeSettings);
      const ttl = el("div", "sp-title");
      bar.append(back, ttl, el("span"));
      const body = el("div", "sp-body");
      page.append(bar, body);
      if (instant) page.style.animation = "none";
      app.appendChild(page);
    }
    page.setAttribute("aria-label", t("settings"));
    page.querySelector(".sp-title").textContent = t("settings");
    page.querySelector(".bar-circle").setAttribute("aria-label", t("back"));
    const box = page.querySelector(".sp-body");
    box.innerHTML = "";
    {
      settingsOpen = true;

      /* --- Profile --- */
      {
        const pr = el("button", "row row-nav profile-row");
        pr.type = "button";
        const left = el("span", "row-label");
        const av = el("span", "avatar"); av.id = "profileAvatar";
        const col = el("span", "profile-row-col");
        const nm = el("span", "profile-row-name"); nm.id = "profileLabel";
        const sb = el("span", "profile-row-sub"); sb.id = "profileSub";
        col.append(nm, sb);
        left.append(av, col);
        const chev = el("span", "chev"); chev.innerHTML = SVG_CHEV;
        pr.append(left, chev);
        pr.addEventListener("click", () => { modal.style.zIndex = "85"; openProfile(); });
        box.appendChild(group(pr));
        refreshProfileRow();
      }

      /* --- General: language + Appearance / Data & Privacy as accordions (one open at a time) --- */
      box.appendChild(section(t("general")));
      {
        const rows = [
          languageRow(),
          row(t("notifyUpdate"), toggle(settings.notifyUpdate, (v) => { settings.notifyUpdate = v; saveSettings(); }, t("notifyUpdate")))
        ];
        const panels = [];
        const accordion = (key, title, buildRows, noteText) => {
          const head = el("button", "row row-nav collapse-head");
          head.type = "button";
          const isOpen = genOpen === key;
          head.setAttribute("aria-expanded", String(isOpen));
          const hl = el("span", "row-label"); hl.textContent = title;
          const hc = el("span", "chev"); hc.innerHTML = SVG_CHEV;
          head.append(hl, hc);
          const cBox = el("div", "collapse" + (isOpen ? " open" : ""));
          const cIn = el("div", "collapse-in");
          cBox.appendChild(cIn);
          if (!isOpen) cBox.setAttribute("inert", "");
          buildRows().forEach((r) => cIn.appendChild(r));
          if (noteText) cIn.appendChild(foot(noteText));
          panels.push({ key, head, cBox });
          head.addEventListener("click", () => {
            genOpen = genOpen === key ? null : key;
            panels.forEach((p) => {
              const o = p.key === genOpen;
              p.head.setAttribute("aria-expanded", String(o));
              p.cBox.classList.toggle("open", o);
              if (o) p.cBox.removeAttribute("inert"); else p.cBox.setAttribute("inert", "");
            });
          });
          rows.push(head, cBox);
        };

        accordion("appearance", t("appearance"), () => [
          segInline(t("fontSize"), [
            { value: "small",   label: t("fsSmall") },
            { value: "default", label: t("fsDefault") },
            { value: "large",   label: t("fsLarge") }
          ], settings.fontSize, (v) => { settings.fontSize = v; saveSettings(); applyTheme(); }),
          segInline(t("density"), [
            { value: "compact",     label: t("dnCompact") },
            { value: "default",     label: t("dnDefault") },
            { value: "comfortable", label: t("dnComfortable") }
          ], settings.density, (v) => { settings.density = v; saveSettings(); applyTheme(); }),
          navPlain(t("appFont"), () => openFontSheet())
        ], t("appearanceNote"));

        accordion("data", t("dataPrivacy"), () => {
          const del = el("button", "row row-nav danger-row");
          del.type = "button";
          const dl = el("span", "row-label");
          dl.textContent = t("deleteAllData");
          del.appendChild(dl);
          del.addEventListener("click", deleteAllLocalData);
          return [
            navPlain(t("exportChats"),  exportChats),
            navPlain(t("clearChat"),    clearCurrentChat),
            navPlain(t("manageData"),   () => openManageData()),
            navPlain(t("dpPrefs"),      openDataPrefs),
            del
          ];
        }, t("dataNote"));

        box.appendChild(group(...rows));
      }


      /* --- Chat theme: background (one card: mode picker + its options) --- */
      const bgGroup = el("div", "collapse-in");
      const commit = () => { saveSettings(); applyBackground(); };

      function renderBgPanel() {
        while (bgGroup.children.length > 2) bgGroup.removeChild(bgGroup.lastChild);
        const m = settings.bg;

        if (m === "color") {
          bgGroup.appendChild(colorRow(t("color"), BG_COLORS, settings.bgColor, (v) => { settings.bgColor = v; commit(); }));
        } else if (m === "hexagons") {
          bgGroup.appendChild(colorRow(t("hexColor"), HEX_COLORS, settings.hexColor, (v) => { settings.hexColor = v; commit(); }));
        } else if (m === "aurora") {
          bgGroup.appendChild(colorRow(t("auroraColor"), AURORA_COLORS, settings.auroraColor, (v) => { settings.auroraColor = v; commit(); }));
        } else if (m === "photo") {
          if (!photoUrl) {
            bgGroup.appendChild(photoNavRow(t("choosePhoto"), ""));
          } else {
            bgGroup.appendChild(photoNavRow(t("changePhoto"), photoUrl, bgFile, removePhoto));
            bgGroup.appendChild(blurRow());
          }
        } else if (m === "video") {
          bgGroup.appendChild(photoNavRow(videoUrl ? t("changeVideo") : t("chooseVideo"), "", bgVideoFile, videoUrl ? removeVideo : null));
          if (videoUrl) bgGroup.appendChild(blurRow());
        }
      }

      // iOS "Appearance"-style picker: a preview of each theme, its name, and a select circle
      const THEME_OPTS = [
        { value: "color",  label: t("bgColor"),  img: "assets/themes/color.jpg" },
        // hexagons are paused for now: add this option back when they are ready
        { value: "aurora", label: t("bgAurora"), img: "assets/themes/aurora.jpg" },
        { value: "photo",  label: t("bgPhoto"),  img: "assets/themes/photo.jpg" },
        { value: "video",  label: t("bgVideo"),  img: "assets/themes/video.jpg" }
      ];
      const themeRow = el("div", "row theme-row");
      const themePick = el("div", "theme-pick");
      themePick.setAttribute("role", "radiogroup");
      themePick.setAttribute("aria-label", t("chatTheme"));
      THEME_OPTS.forEach((o) => {
        const b = el("button", "theme-opt");
        b.type = "button";
        b.setAttribute("role", "radio");
        b.setAttribute("aria-checked", String(o.value === settings.bg));
        const img = document.createElement("img");
        img.className = "theme-thumb";
        img.src = o.img;
        img.alt = "";
        img.draggable = false;
        const nm = el("span", "theme-name");
        nm.textContent = o.label;
        const radio = el("span", "theme-radio");
        radio.innerHTML = '<img src="assets/icons/check.png" alt="" draggable="false">';
        b.append(img, nm, radio);
        b.addEventListener("click", () => {
          if (settings.bg === o.value) return;
          themePick.querySelectorAll(".theme-opt").forEach((n) => n.setAttribute("aria-checked", "false"));
          b.setAttribute("aria-checked", "true");
          settings.bg = o.value;
          commit();
          renderBgPanel();
        });
        themePick.appendChild(b);
      });
      themeRow.appendChild(themePick);

      // chat style: ChatGPT (plain replies + action row) or iMessage (the bubbles)
      const styleRow = el("div", "row seg-row");
      const styleSeg2 = segmented(t("chatStyle"), [
        { value: "chatgpt",  label: t("styleGpt") },
        { value: "imessage", label: t("styleImsg") }
      ], settings.chatStyle, (v) => { settings.chatStyle = v; saveSettings(); applyBackground(); });
      styleSeg2.classList.add("trash-seg", "chat-style-seg");
      styleRow.appendChild(styleSeg2);
      bgGroup.appendChild(styleRow);
      bgGroup.appendChild(themeRow);
      renderBgPanel();

      /* --- Bubbles --- */
      const bubTiles = el("div", "bub-tiles");
      bubTiles.setAttribute("role", "radiogroup");
      bubTiles.setAttribute("aria-label", t("bubbleStyle"));
      const bubBtns = [];
      [["solid", t("solid")], ["blur", t("blur")]].forEach(([value, label]) => {
        const b = el("button", "bub-tile");
        b.type = "button";
        b.setAttribute("role", "radio");
        const pv = el("span", "bub-prev" + (value === "blur" ? " is-blur" : ""));
        pv.append(el("i", "bp bp-in"), el("i", "bp bp-out"));
        const lb = el("span", "bub-label");
        lb.textContent = label;
        b.append(pv, lb);
        b.addEventListener("click", () => {
          settings.bubbleStyle = value;
          saveSettings();
          applyTheme();
          markBub();
        });
        bubBtns.push([value, b]);
        bubTiles.appendChild(b);
      });
      function markBub() {
        bubBtns.forEach(([v, b]) => {
          const on = (settings.bubbleStyle === "blur" ? "blur" : "solid") === v;
          b.classList.toggle("on", on);
          b.setAttribute("aria-checked", String(on));
        });
      }
      markBub();
      const bubStyleRow = el("div", "row bub-row");
      bubStyleRow.appendChild(bubTiles);

      const bubbleRows = [
        bubStyleRow,
        colorRow(t("myBubbles"),  OUT_COLORS, settings.accent,  (v) => { settings.accent = v;  saveSettings(); applyTheme(); }),
        colorRow(t("imaBubbles"), IN_COLORS,  settings.inColor, (v) => { settings.inColor = v; saveSettings(); applyTheme(); })
      ];

      /* --- Messaging: keyboard + receipts --- */
      const msgRows = [
        row(t("enterSends"), toggle(settings.enterSends, (v) => { settings.enterSends = v; saveSettings(); }, t("enterSends"))),
        row(t("receipts"),   toggle(settings.receipts,   (v) => { settings.receipts = v; saveSettings(); if (!v) clearReceipt(); }, t("receipts")))
      ];

      /* --- Chat theme / Bubbles / Messaging as accordions (one open at a time) --- */
      {
        const items = [];
        const panels = [];
        const addPanel = (key, title, nodes, noteText, inEl) => {
          const head = el("button", "row row-nav collapse-head");
          head.type = "button";
          const isOpen = optOpen === key;
          head.setAttribute("aria-expanded", String(isOpen));
          const hl = el("span", "row-label"); hl.textContent = title;
          const hc = el("span", "chev"); hc.innerHTML = SVG_CHEV;
          head.append(hl, hc);
          const cBox = el("div", "collapse" + (isOpen ? " open" : ""));
          const cIn = inEl || el("div", "collapse-in");
          cBox.appendChild(cIn);
          if (!isOpen) cBox.setAttribute("inert", "");
          nodes.forEach((n) => cIn.appendChild(n));
          if (noteText) cIn.appendChild(foot(noteText));
          panels.push({ key, head, cBox });
          head.addEventListener("click", () => {
            optOpen = optOpen === key ? null : key;
            panels.forEach((p) => {
              const o = p.key === optOpen;
              p.head.setAttribute("aria-expanded", String(o));
              p.cBox.classList.toggle("open", o);
              if (o) p.cBox.removeAttribute("inert"); else p.cBox.setAttribute("inert", "");
            });
          });
          items.push(head, cBox);
        };
        addPanel("theme", t("chatTheme"), [], null, bgGroup);
        addPanel("bubbles", t("bubbles"), bubbleRows, t("blurNote"));
        addPanel("messaging", t("messaging"), msgRows, t("enterNote"));
        box.appendChild(group(...items));
      }

      /* --- About iMai / Developer mode / Trash: one card; the developer options open inside it --- */
      {
        const head = el("button", "row row-nav collapse-head");
        head.type = "button";
        head.setAttribute("aria-expanded", String(devOpen));
        const hl = el("span", "row-label"); hl.textContent = t("devMode");
        const hc = el("span", "chev"); hc.innerHTML = SVG_CHEV;
        head.append(hl, hc);
        head.addEventListener("click", () => {
          devOpen = !devOpen;
          head.setAttribute("aria-expanded", String(devOpen));
          devBox.classList.toggle("open", devOpen);
          if (devOpen) devBox.removeAttribute("inert"); else devBox.setAttribute("inert", "");
        });

        const devBox = el("div", "collapse" + (devOpen ? " open" : ""));
        const devIn = el("div", "collapse-in");
        devBox.appendChild(devIn);
        if (!devOpen) devBox.setAttribute("inert", "");

        /* glass effect */
        devIn.append(
          row(t("glass"), toggle(settings.glass, (v) => { settings.glass = v; saveSettings(); applyTheme(); refreshSettings(); }, t("glass"))),
          ...(settings.glass ? [
            rangeRow(t("glassBlur"), "glassBlur", 0, 60, "px"),
            rangeRow(t("glassDark"), "glassDark", 0, 70, "%"),
            resetRow(t("resetGlass"), ["glassBlur", "glassDark"])
          ] : []),
          foot(t("glassNote"))
        );

        /* the glass buttons in sheet headers: you pick the inner layer, black to white */
        devIn.append(
          section(t("sheetBtns")),
          rangeRow(t("btnTint"), "btnTint", -100, 100, ""),
          rangeRow(t("btnEdge"), "btnEdge", 0, 8, "px", 0.1),
          resetRow(t("resetTint"), ["btnTint", "btnEdge"])
        );

        /* shapes: sizes + roundness (like CSS width / height / border-radius) */
        devIn.append(
          section(t("shapes")),
          rangeRow(t("pillW"), "pillW", 40, 260, "px"),
          rangeRow(t("pillH"), "pillH", 30, 80, "px"),
          rangeRow(t("pillR"), "pillR", 0, 80, "px"),
          rangeRow(t("pillS"), "pillS", 0, 100, ""),
          rangeRow(t("btnSize"), "btnSize", 28, 56, "px"),
          rangeRow(t("bubbleR"), "bubbleR", 0, 30, "px"),
          rangeRow(t("fieldR"), "fieldR", 0, 30, "px"),
          resetRow(t("resetShapes"), ["pillW", "pillH", "pillR", "pillS", "btnSize", "bubbleR", "fieldR"]),
          foot(t("shapesNote"))
        );

        box.appendChild(group(
          navPlain(t("aboutIma"), () => openAbout()),
          head,
          devBox,
          navPlain(t("trash"), () => openTrash())
        ));
      }
      box.appendChild(foot(t("trashNote")));
      decorateSettingsIcons(box);
    }
  }

  /* ---------- Settings > General: Appearance helpers + Data & Privacy ---------- */

  // Settings > About iMai (content comes later)
  function openAbout() {
    modal.style.zIndex = "85";          // above the Settings page
    openSheet(t("aboutIma"), (box) => {
      const wrap = el("div", "about-ima");
      const logo = document.createElement("img");
      logo.src = "assets/icons/logo.png"; logo.alt = ""; logo.draggable = false;
      const nm = el("div", "about-ima-name"); nm.textContent = "iMai";
      const tx = el("div", "about-ima-note"); tx.textContent = t("aboutImaNote");
      const lc = el("div", "about-ima-local"); lc.textContent = t("aboutImaLocal");
      wrap.append(logo, nm, tx, lc);
      box.appendChild(wrap);
    });
  }

  /* ---------- Settings icons: iOS-style colored tiles with SF-Symbol-like glyphs ---------- */
  const G = (body) => '<svg viewBox="0 0 24 24" aria-hidden="true">' + body + "</svg>";
  const GLYPHS = {
    globe:    G('<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.4 3.9 5.3 3.9 8.5s-1.4 6.1-3.9 8.5c-2.5-2.4-3.9-5.3-3.9-8.5S9.5 5.9 12 3.5z"/>'),
    bell:     G('<path d="M6.5 16.5V11a5.5 5.5 0 0 1 11 0v5.5l1.5 1.5H5z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>'),
    halfmoon: G('<circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 1 0 16z" fill="currentColor" stroke="none"/>'),
    shield:   G('<path d="M12 3.5l7 2.6v5.4c0 4.2-2.8 7.4-7 9-4.2-1.6-7-4.8-7-9V6.1z"/><path d="M9 12l2.2 2.2L15.2 10"/>'),
    photo:    G('<rect x="3.5" y="5" width="17" height="14" rx="3.2"/><circle cx="9" cy="10" r="1.5" fill="currentColor" stroke="none"/><path d="M4.5 17l4.6-4.4 3.4 3.2 3-3 4.5 4.2"/>'),
    bubble:   G('<path d="M12 4.5c4.7 0 8 2.9 8 6.5s-3.3 6.5-8 6.5c-.9 0-1.7-.1-2.5-.3L5.5 19.5l1-3.3C5 15 4 13.1 4 11c0-3.6 3.3-6.5 8-6.5z" fill="currentColor" stroke="none"/>'),
    plane:    G('<path d="M20.5 3.5L10 14M20.5 3.5l-6.8 17-3.7-6.5L3.5 10.3z"/>'),
    info:     G('<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.2"/><circle cx="12" cy="7.9" r="1.05" fill="currentColor" stroke="none"/>'),
    code:     G('<path d="M9 8l-4 4 4 4M15 8l4 4-4 4M13.3 6.5l-2.6 11"/>'),
    trash:    G('<path d="M4.5 7h15M9.5 7V5h5v2M6.5 7l.8 12.2h9.4L17.5 7M10.4 11v5M13.6 11v5"/>'),
    textsize: G('<path d="M4 18l4.2-10.5L12.4 18M5.6 14.4h5.2M14.2 18l2.9-7.2 2.9 7.2M15.3 15.6h3.6"/>'),
    font:     G('<path d="M4.5 18L9 6.5 13.5 18M6.2 14h5.6"/><circle cx="17.3" cy="15.2" r="2.5"/><path d="M19.8 12.7V18"/>'),
    share:    G('<path d="M12 15V4M8.6 7.4L12 4l3.4 3.4M7 10.5H6a2 2 0 0 0-2 2v5.5a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5.5a2 2 0 0 0-2-2h-1"/>'),
    reset:    G('<path d="M5.2 12a6.8 6.8 0 1 0 2-4.8M5 4.5v3.7h3.7"/>'),
    folder:   G('<path d="M3.5 7.5a2 2 0 0 1 2-2H10l2 2h6.5a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>'),
    sliders:  G('<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>'),
    enter:    G('<path d="M19 6v6a2 2 0 0 1-2 2H6M9.6 10.4L6 14l3.6 3.6"/>'),
    seen:     G('<circle cx="12" cy="12" r="8.5"/><path d="M8.2 12.3l2.5 2.5 5-5.4"/>')
  };
  // [i18n key, glyph, tile color]
  const SET_ICONS = [
    ["language", "globe", "#0a84ff"], ["notifyUpdate", "bell", "#ff453a"], ["appearance", "halfmoon", "#5e5ce6"], ["dataPrivacy", "shield", "#34aadc"],
    ["chatTheme", "photo", "#ff375f"], ["bubbles", "bubble", "#30d158"], ["messaging", "plane", "#0a84ff"],
    ["aboutIma", "info", "#8e8e93"], ["devMode", "code", "#ff9f0a"], ["trash", "trash", "#ff453a"],
    ["appFont", "font", "#bf5af2"], ["exportChats", "share", "#30d158"], ["clearChat", "reset", "#ff9f0a"],
    ["manageData", "folder", "#0a84ff"], ["dpPrefs", "sliders", "#8e8e93"], ["deleteAllData", "trash", "#ff453a"],
    ["enterSends", "enter", "#8e8e93"], ["receipts", "seen", "#30d158"]
  ];
  function decorateSettingsIcons(root) {
    const byText = new Map();
    SET_ICONS.forEach(([k, g, c]) => byText.set(t(k), { g, c }));
    root.querySelectorAll(".row").forEach((r) => {
      if (r.querySelector(".set-ico") || r.classList.contains("seg-inline") || r.classList.contains("profile-row")) return;
      const first = r.firstElementChild;
      if (!first) return;
      const hit = byText.get((first.textContent || "").trim());
      if (!hit) return;
      const tile = el("span", "set-ico");
      tile.style.setProperty("--c", hit.c);
      tile.innerHTML = GLYPHS[hit.g];
      if (first.classList.contains("row-label")) first.insertBefore(tile, first.firstChild);
      else { const w = el("span", "row-label"); r.insertBefore(w, first); w.append(tile, first); }
    });
  }

  // a plain Settings row with a chevron (Settings rows carry no icons, like Trash)
  function navPlain(label, onClick) {
    const r = navRow(label, "", onClick);
    const ico = r.querySelector(".row-ico");
    if (ico) ico.remove();
    return r;
  }

  // label and segmented control on ONE line; buttons size to their text so nothing is clipped
  function segInline(label, options, value, onChange) {
    const r = el("div", "row seg-inline");
    const l = el("span", "seg-inline-label"); l.textContent = label;
    const seg = segmented(label, options, value, onChange);
    seg.classList.add("seg-fit");
    r.append(l, seg);
    const place = () => {
      const on = seg.querySelector('button[aria-checked="true"]');
      const th = seg.querySelector(".seg-thumb");
      if (!on || !th || !on.offsetWidth) return;
      th.style.width = on.offsetWidth + "px";
      th.style.left = on.offsetLeft + "px";
    };
    seg.addEventListener("click", () => requestAnimationFrame(place));
    if (window.ResizeObserver) new ResizeObserver(place).observe(seg);
    requestAnimationFrame(place);
    return r;
  }

  // a label row with a full-width segmented control underneath (3 options need the room)
  function segBlock(label, options, value, onChange) {
    const head = el("div", "row seg-label");
    const l = el("span"); l.textContent = label;
    head.appendChild(l);
    const body = el("div", "row seg-row");
    body.appendChild(segmented(label, options, value, onChange));
    return [head, body];
  }

  // a settings row that shows a value on the right; tappable when onClick is given
  function dataRow(label, value, onClick) {
    const r = el(onClick ? "button" : "div", "row" + (onClick ? " row-nav" : ""));
    if (onClick) r.type = "button";
    const l = el("span"); l.textContent = label;
    const v = el("span", "row-val"); v.textContent = value;
    r.append(l, v);
    if (onClick) r.addEventListener("click", onClick);
    return r;
  }

  const fmtBytes = (n) => n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(n < 10240 ? 1 : 0) + " KB" : (n / 1048576).toFixed(1) + " MB";

  // alerts launched from Settings open above the Settings page
  function settingsAlert(title, message, actions) {
    modal.style.zIndex = "85";
    openAlert(title, message, actions);
  }

  function exportChats() {
    if (!chats.length) { showToast(t("exportNone")); return; }
    const iso = (n) => (n ? new Date(n).toISOString() : null);
    const data = {
      app: "iMa!",
      exportedAt: new Date().toISOString(),
      chats: chats.map((c) => ({
        title: c.title,
        created: iso(c.ts),
        updated: iso(c.updated),
        pinned: !!c.pin,
        archived: !!c.arch,
        messages: (c.msgs || []).map((m) => {
          const o = { role: m.role === "out" ? "user" : "assistant", text: m.text || "" };
          if (m.quote) o.replyingTo = m.quote;
          if (m.images && m.images.length) o.webImages = m.images;
          const n = (m.pids ? m.pids.length : 0) + (m.pics || 0);
          if (n) o.pictures = n;
          return o;
        })
      }))
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "ima-chats-" + new Date().toISOString().slice(0, 10) + ".json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    showToast(t("exportDone"));
  }

  function clearCurrentChat() {
    if (busy) { showToast(t("chatBusy")); return; }
    const hasMsgs = thread.querySelector(".msg.out") || chatId;
    if (!hasMsgs) { showToast(t("nothingToClear")); return; }
    settingsAlert(t("clearChatTitle"), t("clearChatMsg"), [
      { label: t("cancel") },
      { label: t("clearBtn"), danger: true, onClick: () => {
        if (chatId && chats.some((c) => c.id === chatId)) trashChats([chatId]);
        startChat();
        renderChatList();
        closeSettings();
        showToast(t("clearChatDone"));
      } }
    ]);
  }

  function clearHistory() {
    if (busy) { showToast(t("chatBusy")); return; }
    if (!chats.length) { showToast(t("nothingToClear")); return; }
    settingsAlert(t("clearHistTitle"), t("clearHistMsg"), [
      { label: t("cancel") },
      { label: t("clearBtn"), danger: true, onClick: () => {
        trashChats(chats.map((c) => c.id));
        startChat();
        renderChatList();
        showToast(t("clearHistDone"));
      } }
    ]);
  }

  const cacheKeys = () => {
    const out = [];
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.startsWith("ima-news:")) out.push(k); } } catch (e) {}
    return out;
  };

  async function openManageData() {
    let pics = [];
    try { pics = (await PicDB.all()) || []; } catch (e) {}
    const picBytes = pics.reduce((s, r) => s + ((r.blob && r.blob.size) || 0), 0);
    let chatBytes = 0;
    try { chatBytes = (localStorage.getItem(CHATS_KEY) || "").length * 2; } catch (e) {}
    const trashN = trash.chats.length + trash.files.length;
    const cache = cacheKeys();

    modal.style.zIndex = "85";
    openSheet(t("manageData"), (box) => {
      box.appendChild(group(
        dataRow(t("mdChats"), chats.length + " · " + fmtBytes(chatBytes)),
        dataRow(t("mdPics"), pics.length + " · " + fmtBytes(picBytes), () => {
          if (!pics.length) { showToast(t("mdEmpty")); return; }
          settingsAlert(t("mdPicsTitle"), t("mdPicsMsg"), [
            { label: t("cancel"), onClick: () => openManageData() },
            { label: t("delete"), danger: true, onClick: async () => {
              const all = (await PicDB.all().catch(() => [])) || [];
              await eraseFiles(all.map((r) => ({ kind: "db", id: r.id })));
              trash.files = trash.files.filter((f) => f.kind !== "db");
              writeTrash();
              showToast(t("mdDone"));
              openManageData();
            } }
          ]);
        }),
        dataRow(t("mdTrash"), String(trashN), () => {
          if (!trashN) { showToast(t("mdEmpty")); return; }
          settingsAlert(t("mdTrashTitle"), t("mdTrashMsg"), [
            { label: t("cancel"), onClick: () => openManageData() },
            { label: t("delete"), danger: true, onClick: async () => {
              const old = trash;
              trash = { chats: [], files: [] };
              writeTrash();
              eraseChats(old.chats);
              await eraseFiles(old.files);
              showToast(t("mdDone"));
              openManageData();
            } }
          ]);
        }),
        dataRow(t("mdCache"), String(cache.length), () => {
          if (!cache.length) { showToast(t("mdEmpty")); return; }
          settingsAlert(t("mdCacheTitle"), t("mdCacheMsg"), [
            { label: t("cancel"), onClick: () => openManageData() },
            { label: t("delete"), danger: true, onClick: () => {
              cacheKeys().forEach((k) => { try { localStorage.removeItem(k); } catch (e) {} });
              showToast(t("mdDone"));
              openManageData();
            } }
          ]);
        })
      ));
      box.appendChild(foot(t("mdNote")));
    });
  }

  function openDataPrefs() {
    modal.style.zIndex = "85";
    openSheet(t("dpPrefs"), (box) => {
      box.appendChild(group(
        row(t("saveHistory"), toggle(settings.saveHistory, (v) => { settings.saveHistory = v; saveSettings(); }, t("saveHistory")))
      ));
      box.appendChild(foot(t("saveHistoryNote")));
      box.appendChild(group(
        row(t("aiTitles"), toggle(settings.aiTitles, (v) => { settings.aiTitles = v; saveSettings(); }, t("aiTitles")))
      ));
      box.appendChild(foot(t("aiTitlesNote")));
    });
  }

  function deleteAllLocalData() {
    settingsAlert(t("delAllTitle"), t("delAllMsg"), [
      { label: t("cancel") },
      { label: t("delAllBtn"), danger: true, onClick: async () => {
        const gone = ["ima", "ima-pics", "ima-music"].map((name) => new Promise((resolve) => {
          try {
            const r = indexedDB.deleteDatabase(name);
            r.onsuccess = r.onerror = r.onblocked = () => resolve();     // a blocked delete finishes once the page reloads
          } catch (e) { resolve(); }
        }));
        await Promise.race([Promise.all(gone), new Promise((r) => setTimeout(r, 700))]);
        try {
          const keys = [];
          for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && /^ima[-.]/.test(k)) keys.push(k); }
          keys.forEach((k) => localStorage.removeItem(k));
        } catch (e) {}
        location.reload();
      } }
    ]);
  }

  let trashUrls = [];

  // Settings > Trash: deleted chats and pictures, kept apart; restore them or delete them for good
  async function openTrash(state = {}) {
    purgeTrash();
    trashUrls.forEach((u) => URL.revokeObjectURL(u));
    trashUrls = [];

    // thumbnails for the picture tab
    const pics = [];
    for (const f of trash.files) {
      if (f.kind === "web") { pics.push({ key: "web:" + f.src, src: f.src, f }); continue; }
      try {
        const rec = await PicDB.get(f.id);
        if (rec && rec.blob) { const u = URL.createObjectURL(rec.blob); trashUrls.push(u); pics.push({ key: "db:" + f.id, src: u, f }); }
      } catch (e) {}
    }
    const chatRows = trash.chats.map((c) => ({ key: c.id, c }));

    let tab = state.tab === "files" ? "files" : "chats";
    const picked = new Set(state.picked || []);

    modal.style.zIndex = "85";          // opens above the Settings page it is launched from
    openSheet(t("trash"), (box) => {
      const tabs = segmented(t("trash"), [
        { value: "chats", label: t("trashChats") + " (" + chatRows.length + ")" },
        { value: "files", label: t("trashFiles") + " (" + pics.length + ")" }
      ], tab, (v) => { tab = v; picked.clear(); renderBody(); });
      tabs.classList.add("trash-seg");
      const tabRow = el("div", "row seg-row");
      tabRow.appendChild(tabs);
      const tabGroup = group(tabRow);
      tabGroup.classList.add("group-bare");     // just the Chats / Files control, no box around it
      box.appendChild(tabGroup);

      const body = el("div", "trash-body");
      const bar = el("div", "trash-bar");
      const countEl = el("div", "trash-count");
      const btns = el("div", "trash-btns");
      const restoreBtn = el("button", "tb-restore"); restoreBtn.type = "button";
      const allBtn = el("button", "tb-all"); allBtn.type = "button";
      const delBtn = el("button", "tb-delete"); delBtn.type = "button";
      btns.append(restoreBtn, allBtn, delBtn);
      bar.append(countEl, btns);
      box.append(body, foot(t("trashNote")), bar);

      const items = () => tab === "chats" ? chatRows : pics;

      function refreshBar() {
        const n = picked.size, total = items().length;
        bar.classList.toggle("has-sel", n > 0);
        countEl.textContent = n + " / " + total;
        restoreBtn.textContent = t("restore");
        allBtn.textContent = t(n && n === total ? "deselectAll" : "selectAll");
        delBtn.textContent = t("delete");
        restoreBtn.disabled = !n;
        delBtn.disabled = !n;
        allBtn.disabled = !total;
      }

      function renderBody() {
        body.innerHTML = "";
        const list = items();
        if (!list.length) {
          const e = el("div", "empty");
          e.textContent = t("trashEmpty");
          body.appendChild(e);
        } else if (tab === "chats") {
          const wrap = el("div", "trash-list");
          list.forEach(({ key, c }) => {
            const r = el("button", "trash-row" + (picked.has(key) ? " picked" : ""));
            r.type = "button";
            const name = el("span", "trash-name"); name.dir = "auto"; name.textContent = c.title || t("newChat");
            const sub = el("span", "trash-sub"); sub.textContent = t("daysLeft", daysLeft(c));
            const txt = el("span", "trash-text"); txt.append(name, sub);
            r.append(el("span", "trash-tick"), txt);
            r.addEventListener("click", () => {
              if (picked.has(key)) picked.delete(key); else picked.add(key);
              r.classList.toggle("picked", picked.has(key));
              refreshBar();
            });
            wrap.appendChild(r);
          });
          body.appendChild(wrap);
        } else {
          const grid = el("div", "files selecting");
          list.forEach(({ key, src }) => {
            const cell = el("div", "file" + (picked.has(key) ? " picked" : ""));
            const img = document.createElement("img");
            img.referrerPolicy = "no-referrer";
            img.src = src;
            img.alt = t("uploadedPic");
            cell.append(img, el("span", "tick"));
            cell.addEventListener("click", () => {
              if (picked.has(key)) picked.delete(key); else picked.add(key);
              cell.classList.toggle("picked", picked.has(key));
              refreshBar();
            });
            grid.appendChild(cell);
          });
          body.appendChild(grid);
        }
        refreshBar();
      }

      allBtn.addEventListener("click", () => {
        const list = items();
        const everything = list.length && picked.size === list.length;
        picked.clear();
        if (!everything) list.forEach((x) => picked.add(x.key));
        renderBody();
      });

      restoreBtn.addEventListener("click", () => {
        const n = picked.size;
        if (!n) return;
        if (tab === "chats") {
          const back = trash.chats.filter((c) => picked.has(c.id));
          back.forEach((c) => { const { deletedAt, ...rest } = c; if (!chats.some((x) => x.id === rest.id)) chats.push(rest); });
          chats.sort((a, b) => (b.updated || b.ts || 0) - (a.updated || a.ts || 0));
          trash.chats = trash.chats.filter((c) => !picked.has(c.id));
          writeChats();
          renderChatList();
        } else {
          trash.files = trash.files.filter((f) => !picked.has(f.kind === "db" ? "db:" + f.id : "web:" + f.src));
        }
        writeTrash();
        showToast(t("restored", n));
        openTrash({ tab, again: true });
      });

      delBtn.addEventListener("click", () => {
        const n = picked.size;
        if (!n) return;
        openAlert(t("eraseTitle", n), t("eraseMsg"), [
          { label: t("cancel"), onClick: () => openTrash({ tab, picked: Array.from(picked), again: true }) },
          { label: t("delete"), danger: true, onClick: async () => {
              if (tab === "chats") {
                const gone = trash.chats.filter((c) => picked.has(c.id));
                trash.chats = trash.chats.filter((c) => !picked.has(c.id));
                writeTrash();
                eraseChats(gone);
              } else {
                const gone = trash.files.filter((f) => picked.has(f.kind === "db" ? "db:" + f.id : "web:" + f.src));
                trash.files = trash.files.filter((f) => !gone.includes(f));
                writeTrash();
                await eraseFiles(gone);
                renderChatList();
              }
              showToast(t("erased", n));
              openTrash({ tab, again: true });
            } }
        ]);
      });

      renderBody();
    }, { instant: !!state.again });
  }

  function openMemory() {
    openSheet(t("memory"), (box) => {
      box.appendChild(group(
        row(t("rememberAcross"), toggle(settings.memory, (v) => { settings.memory = v; saveSettings(); }, t("rememberAcross")))
      ));
      box.appendChild(foot(t("rememberNote")));
    });
  }

  let filesUrls = [];

  // every picture kept on this device (uploads, AI-made) plus the web photos found in any chat
  async function collectPictures() {
    filesUrls.forEach((u) => URL.revokeObjectURL(u));
    filesUrls = [];
    const out = [];
    const hiddenIds = trashedPicIds();
    const hiddenUrls = new Set(trash.files.filter((f) => f.kind === "web").map((f) => f.src));
    try {
      const recs = await PicDB.all();
      (recs || []).forEach((r) => {
        if (!r || !r.blob || hiddenIds.has(r.id)) return;
        const u = URL.createObjectURL(r.blob);
        filesUrls.push(u);
        out.push({ src: u, ts: r.ts || 0, key: "db:" + r.id, kind: "db", id: r.id });
      });
    } catch (e) { console.error("[iMa! pictures]", e); }
    const seen = new Set();
    chats.forEach((c) => (c.msgs || []).forEach((m) => (m.images || []).forEach((u) => {
      if (!seen.has(u) && !hiddenUrls.has(u)) { seen.add(u); out.push({ src: u, ts: c.updated || 0, key: "web:" + u, kind: "web" }); }
    })));
    uploads.forEach((u) => {
      if (/^https?:/i.test(u) && !seen.has(u) && !hiddenUrls.has(u)) { seen.add(u); out.push({ src: u, ts: Date.now(), key: "web:" + u, kind: "web" }); }
    });
    out.sort((x, y) => y.ts - x.ts);
    return out;
  }

  async function openFiles(state = {}) {
    const items = state.items || await collectPictures();
    let selecting = !!state.select;
    const picked = new Set(state.picked || []);

    openSheet(t("files"), (box) => {
      if (!items.length) {
        const e = el("div", "empty");
        e.textContent = t("empty");
        box.appendChild(e);
        return;
      }

      const head = box.querySelector(".sheet-head");
      const selBtn = el("button", "sheet-select");
      selBtn.type = "button";
      head.appendChild(selBtn);

      const grid = el("div", "files");
      const bar = el("div", "files-bar");
      const allBtn = el("button"); allBtn.type = "button";
      const delBtn = el("button", "danger"); delBtn.type = "button";
      bar.append(allBtn, delBtn);

      const cells = items.map((it) => {
        const cell = el("div", "file");
        const img = document.createElement("img");
        img.referrerPolicy = "no-referrer";
        img.src = it.src;
        img.alt = t("uploadedPic");
        const tick = el("span", "tick");
        cell.append(img, tick);
        cell.addEventListener("click", () => {
          if (!selecting) { openViewer(it.src); return; }
          if (picked.has(it.key)) picked.delete(it.key); else picked.add(it.key);
          refresh();
        });
        grid.appendChild(cell);
        return { it, cell };
      });

      function refresh() {
        grid.classList.toggle("selecting", selecting);
        bar.classList.toggle("show", selecting);
        selBtn.textContent = t(selecting ? "cancel" : "select");
        cells.forEach(({ it, cell }) => cell.classList.toggle("picked", selecting && picked.has(it.key)));
        const n = picked.size;
        allBtn.textContent = t(n && n === items.length ? "deselectAll" : "selectAll");
        delBtn.textContent = t("delN", n);
        delBtn.disabled = !n;
      }

      selBtn.addEventListener("click", () => { selecting = !selecting; picked.clear(); refresh(); });
      allBtn.addEventListener("click", () => {
        const everything = picked.size === items.length;
        picked.clear();
        if (!everything) items.forEach((it) => picked.add(it.key));
        refresh();
      });
      delBtn.addEventListener("click", () => {
        const chosen = items.filter((it) => picked.has(it.key));
        const n = chosen.length;
        if (!n) return;
        openAlert(t("delPicsTitle", n), t("delPicsMsg"), [
          { label: t("cancel"), onClick: () => openFiles({ items, select: true, picked: Array.from(picked), again: true }) },
          { label: t("delete"), danger: true, onClick: async () => {
              trashPictures(chosen);
              showToast(t("picsDeleted", n));
              openFiles({ again: true });
            } }
        ]);
      });

      box.append(grid, bar);
      refresh();
    }, { instant: !!state.again });
  }

  /* ---------- Code preview: paste HTML / CSS / JS, tap Run to see it ---------- */

  // kept while the app stays open, so Back never loses what was pasted
  let cpCode = "";                                  // "One code" mode
  let cpParts = { html: "", css: "", js: "", py: "" };      // "Separate" mode
  let cpMode = "one";                               // "one" | "sep"
  let cpLang = "html";                              // active tab in "Separate" mode

  /* --- tiny syntax colouring (no libraries) --- */
  const hlEsc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const hlSpan = (c, s) => `<span class="${c}">${hlEsc(s)}</span>`;

  const JS_KEYWORDS = new Set(("async await break case catch class const continue debugger default delete do else export extends " +
    "finally for from function if import in instanceof let new of return static super switch throw try typeof var void while with yield get set").split(" "));
  const JS_LITERALS = new Set(["true", "false", "null", "undefined", "this", "NaN", "Infinity"]);

  function hlJS(src) {
    const re = /(\/\*[\s\S]*?(?:\*\/|$)|\/\/[^\n]*)|("(?:\\.|[^"\\\n])*"?|'(?:\\.|[^'\\\n])*'?|`(?:\\[\s\S]|[^`\\])*`?)|(\b0x[\da-f]+\b|\b\d[\d_]*\.?\d*(?:e[+-]?\d+)?\b)|([A-Za-z_$][\w$]*)|([^\w\s]|\s+|\w+)/gi;
    let out = "", m;
    while ((m = re.exec(src))) {
      if (m[1]) out += hlSpan("t-c", m[1]);
      else if (m[2]) out += hlSpan("t-s", m[2]);
      else if (m[3]) out += hlSpan("t-n", m[3]);
      else if (m[4]) {
        const w = m[4];
        if (JS_KEYWORDS.has(w)) out += hlSpan("t-k", w);
        else if (JS_LITERALS.has(w)) out += hlSpan("t-n", w);
        else if (/^\s*\(/.test(src.slice(re.lastIndex, re.lastIndex + 40))) out += hlSpan("t-f", w);
        else out += hlEsc(w);
      } else if (/^[{}()[\];,.:=<>+\-*/%!&|?^~]$/.test(m[5])) out += hlSpan("t-p", m[5]);
      else out += hlEsc(m[5]);
    }
    return out;
  }

  function hlCSS(src) {
    const re = /(\/\*[\s\S]*?(?:\*\/|$))|("(?:\\.|[^"\\\n])*"?|'(?:\\.|[^'\\\n])*'?)|(@[\w-]+)|(#[\da-f]{3,8}\b)|(-?\d*\.?\d+(?:px|em|rem|%|vh|vw|vmin|vmax|ms|s|deg|fr|ch)?)|([.#]?-?[A-Za-z_][\w-]*)|([^\w\s]|\s+|\w+)/gi;
    let out = "", m;
    while ((m = re.exec(src))) {
      const rest = src.slice(re.lastIndex, re.lastIndex + 400);
      if (m[1]) out += hlSpan("t-c", m[1]);
      else if (m[2]) out += hlSpan("t-s", m[2]);
      else if (m[3]) out += hlSpan("t-k", m[3]);
      else if (m[4]) out += hlSpan("t-n", m[4]);
      else if (m[5]) out += hlSpan("t-n", m[5]);
      else if (m[6]) {
        const w = m[6];
        if (/^\(/.test(rest)) out += hlSpan("t-f", w);
        else if (/^\s*:(?!:)[^;{}]*[;}]/.test(rest) && !/^[.#]/.test(w)) out += hlSpan("t-a", w);
        else if (/^[^;{}]*\{/.test(rest)) out += hlSpan("t-t", w);
        else out += hlSpan("t-v", w);
      } else if (/^[{}()[\];,:>+~*=]$/.test(m[7])) out += hlSpan("t-p", m[7]);
      else out += hlEsc(m[7]);
    }
    return out;
  }

  function hlTag(tag) {
    const m = /^(<\/?)([\w:-]+)([\s\S]*?)(\/?>?)$/.exec(tag);
    if (!m) return hlEsc(tag);
    let out = hlSpan("t-p", m[1]) + hlSpan("t-t", m[2]);
    const re = /(\s+)|([^\s=]+)(\s*=\s*)?("[^"]*"?|'[^']*'?|[^\s"'>]+)?/g;
    let a;
    while ((a = re.exec(m[3])) && a[0] !== "") {
      if (a[1]) out += hlEsc(a[1]);
      else {
        out += hlSpan("t-a", a[2]);
        if (a[3]) out += hlSpan("t-p", a[3]);
        if (a[4]) out += hlSpan("t-s", a[4]);
      }
    }
    return out + hlSpan("t-p", m[4]);
  }

  function hlHTML(src) {
    const re = /(<!--[\s\S]*?(?:-->|$))|(<!DOCTYPE[^>]*>?)|(<style\b[^>]*>)([\s\S]*?)(<\/style\s*>|$)|(<script\b[^>]*>)([\s\S]*?)(<\/script\s*>|$)|(<\/?[A-Za-z][^>]*>?)|([^<]+|<)/gi;
    let out = "", m;
    while ((m = re.exec(src))) {
      if (m[1]) out += hlSpan("t-c", m[1]);
      else if (m[2]) out += hlSpan("t-k", m[2]);
      else if (m[3]) out += hlTag(m[3]) + hlCSS(m[4]) + (m[5] ? hlTag(m[5]) : "");
      else if (m[6]) out += hlTag(m[6]) + hlJS(m[7]) + (m[8] ? hlTag(m[8]) : "");
      else if (m[9]) out += hlTag(m[9]);
      else out += hlEsc(m[10]);
    }
    return out;
  }

  /* --- which language is this? So plain text isn't shown as code, and the colours fit the language --- */
  const LANG_ALIAS = {
    js: "javascript", javascript: "javascript", mjs: "javascript", cjs: "javascript", jsx: "javascript", node: "javascript", nodejs: "javascript",
    ts: "typescript", typescript: "typescript", tsx: "typescript",
    html: "html", htm: "html", xhtml: "html", svg: "html", vue: "html", xml: "xml",
    css: "css", scss: "css", sass: "css", less: "css",
    json: "json", jsonc: "json", json5: "json",
    py: "python", python: "python", python3: "python", py3: "python",
    sh: "bash", bash: "bash", shell: "bash", zsh: "bash", console: "bash", terminal: "bash", cmd: "bash", powershell: "bash", ps1: "bash",
    sql: "sql", mysql: "sql", postgres: "sql", postgresql: "sql", sqlite: "sql",
    java: "java", kotlin: "kotlin", kt: "kotlin", c: "c", h: "c", cpp: "cpp", "c++": "cpp", cc: "cpp", hpp: "cpp",
    cs: "csharp", csharp: "csharp", "c#": "csharp", go: "go", golang: "go", rust: "rust", rs: "rust",
    php: "php", ruby: "ruby", rb: "ruby", swift: "swift", dart: "dart", lua: "lua", r: "r",
    yaml: "yaml", yml: "yaml", toml: "toml", ini: "toml", dockerfile: "docker", docker: "docker",
    diff: "diff", patch: "diff", markdown: "markdown", md: "markdown", latex: "latex", tex: "latex"
  };

  function detectLang(code) {
    const txt = String(code || "").trim();
    if (txt.length < 4) return "";
    if (/^[{\[]/.test(txt) && /[}\]]$/.test(txt)) {
      try { JSON.parse(txt); if (/^\[/.test(txt) || txt.indexOf(":") > 0) return "json"; } catch (e) {}
    }
    const sc = {};
    const add = (k, n) => { if (n) sc[k] = (sc[k] || 0) + n; };
    const has = (re) => re.test(txt);
    const count = (re) => (txt.match(re) || []).length;

    // html
    if (has(/^\s*<!doctype html/i) || has(/<html[\s>]/i)) add("html", 6);
    add("html", Math.min(8, count(/<\/?(?:div|span|p|a|img|ul|ol|li|head|body|script|style|link|meta|title|button|input|form|label|select|option|textarea|h[1-6]|table|tr|td|th|section|nav|header|footer|main|article|canvas|svg|path|br|hr|iframe|video|audio)\b[^<>]*>/gi) * 2));
    // css (rules, or a pile of "property: value;" lines)
    add("css", count(/(?:^|[}\n])\s*(?:[.#\w\-*:>+~, ]|\[[^\]]*\])+\{[^{}]*?[\w-]+\s*:\s*[^{};]+;[^{}]*\}/g) * 3);
    add("css", count(/^\s*@(?:media|import|keyframes|font-face|tailwind|apply)\b/gm) * 3);
    // javascript / typescript
    add("javascript", count(/\b(?:const|let|var)\s+[\w$]+\s*(?:=|;)/g) * 2);
    add("javascript", count(/\bfunction\s*[\w$]*\s*\(/g) * 2);
    add("javascript", count(/=>/g));
    add("javascript", count(/===|!==/g));
    add("javascript", count(/\b(?:console\.(?:log|error|warn)|document\.|window\.|addEventListener|querySelector|getElementById|require\(|module\.exports|export\s+(?:default|const|function)|import\s+[\w{},*\s]+\s+from\s+['"])/g) * 3);
    if (sc.javascript && count(/;\s*$/gm) >= 2) add("javascript", 1);
    // python
    add("python", count(/^\s*def\s+\w+\s*\([^)]*\)\s*(?:->\s*[\w\[\], .]+)?\s*:/gm) * 4);
    add("python", count(/^\s*class\s+\w+(?:\([^)]*\))?\s*:/gm) * 4);
    add("python", count(/^\s*(?:from\s+[\w.]+\s+import\s+\S|import\s+[\w.]+(?:\s+as\s+\w+)?\s*$)/gm) * 3);
    add("python", count(/\bprint\s*\(/g));
    add("python", count(/^\s*(?:elif\b.*:|else\s*:|try\s*:|except\b.*:|finally\s*:|with\b.*:|for\b.*\bin\b.*:|while\b.*:|if\b.*:)\s*$/gm) * 2);
    add("python", count(/\b(?:self\.|__init__|__name__)/g) * 2);
    add("python", has(/\bif\s+__name__\s*==/) ? 4 : 0);
    // shell
    add("bash", has(/^#!\/(?:usr\/)?bin\/(?:env\s+)?(?:ba|z)?sh/) ? 6 : 0);
    add("bash", count(/^\s*(?:\$\s+)?(?:sudo|apt(?:-get)?|npm|npx|yarn|pip3?|git|cd|ls|mkdir|rm|cp|mv|chmod|export|brew|docker|kubectl|source|touch|curl|wget)\s+\S/gm) * 2);
    // sql
    add("sql", count(/\b(?:SELECT\s+[\s\S]+?\s+FROM|INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM|CREATE\s+(?:TABLE|DATABASE|INDEX)|ALTER\s+TABLE|DROP\s+TABLE)\b/gi) * 4);
    // java, c-family, go, rust, php
    add("java", count(/\b(?:public|private|protected)\s+(?:static\s+)?(?:final\s+)?(?:class|void|int|String|boolean)\b/g) * 3);
    add("java", count(/System\.out\.print/g) * 4);
    add("c", count(/#include\s*[<"]/g) * 4);
    add("c", count(/\bint\s+main\s*\(/g) * 3);
    add("c", count(/\b(?:printf|scanf|malloc)\s*\(/g) * 2);
    add("cpp", count(/\bstd::|\bcout\s*<<|\bcin\s*>>|#include\s*<iostream>|\btemplate\s*<|\bnamespace\s+\w+\s*\{/g) * 3);
    add("csharp", count(/\busing\s+System\b/g) * 4);
    add("csharp", count(/\bConsole\.Write(?:Line)?\s*\(/g) * 4);
    add("go", count(/^package\s+\w+/gm) * 3);
    add("go", count(/\bfunc\s+(?:\(\w+\s+\*?\w+\)\s*)?\w+\s*\(/g) * 3);
    add("go", count(/\bfmt\.\w+\(/g) * 3);
    add("rust", count(/\bfn\s+\w+\s*[(<]/g) * 3);
    add("rust", count(/\blet\s+mut\b/g) * 3);
    add("rust", count(/\bprintln!\s*\(/g) * 4);
    add("rust", count(/\buse\s+std::/g) * 3);
    add("php", has(/<\?php/) ? 6 : 0);
    add("php", count(/\$\w+\s*=[^=]/g));

    let best = "", top = 0;
    Object.keys(sc).forEach((k) => { if (sc[k] > top) { top = sc[k]; best = k; } });
    if (top < 3) return "";
    if (best === "javascript" && has(/:\s*(?:string|number|boolean|any|void)\b|\binterface\s+\w+|\btype\s+\w+\s*=/)) return "typescript";
    if (best === "c" && sc.cpp) return "cpp";
    return best;
  }

  /* --- colours --- */
  const KW = (s) => new Set(s.split(" "));
  const GENERIC = {
    python: { c: "hash", kw: KW("def class return if elif else for while in not and or is import from as with try except finally raise pass break continue lambda yield global nonlocal del assert async await"), lit: KW("True False None self cls") },
    bash: { c: "hash", kw: KW("if then else elif fi for while do done case esac function in return export local source alias unset"), lit: KW("") },
    sql: { c: "dash", ci: true, kw: KW("select from where and or not insert into values update set delete create table drop alter add index primary key foreign references join left right inner outer on group by order having limit offset as distinct union all null is in like between exists case when then else end count sum avg min max database"), lit: KW("true false null") },
    java: { c: "c", kw: KW("abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for if implements import instanceof int interface long new package private protected public return short static super switch this throw throws try void volatile while var"), lit: KW("true false null") },
    kotlin: { c: "c", kw: KW("fun val var class object interface if else when for while do return break continue in is as import package try catch finally throw override open data sealed private public protected internal suspend"), lit: KW("true false null this") },
    c: { c: "c", kw: KW("auto break case char const continue default do double else enum extern float for goto if int long register return short signed sizeof static struct switch typedef union unsigned void volatile while include define"), lit: KW("NULL true false") },
    cpp: { c: "c", kw: KW("auto bool break case catch char class const constexpr continue default delete do double else enum explicit extern float for friend if inline int long namespace new operator private protected public return short signed sizeof static struct switch template this throw try typedef typename union unsigned using virtual void volatile while include define"), lit: KW("NULL nullptr true false") },
    csharp: { c: "c", kw: KW("abstract as base bool break byte case catch char class const continue decimal default delegate do double else enum event extern finally float for foreach if in int interface internal is lock long namespace new object operator out override params private protected public readonly ref return sealed short static string struct switch this throw try typeof uint ulong using var virtual void while async await"), lit: KW("true false null") },
    go: { c: "c", kw: KW("break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var"), lit: KW("true false nil iota") },
    rust: { c: "c", kw: KW("as async await break const continue crate dyn else enum extern fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait type unsafe use where while"), lit: KW("true false None Some Ok Err") },
    php: { c: "c+hash", kw: KW("abstract and array as break case catch class clone const continue default do echo else elseif empty extends final finally for foreach function global if implements include instanceof interface namespace new or private protected public require return static switch throw trait try use var while"), lit: KW("true false null TRUE FALSE NULL") },
    ruby: { c: "hash", kw: KW("alias and begin break case class def defined do else elsif end ensure for if in module next not or redo rescue retry return self super then undef unless until when while yield puts require"), lit: KW("true false nil") },
    swift: { c: "c", kw: KW("class struct enum func let var if else guard switch case default for while repeat return break continue import init self super extension protocol where in is as try catch throw throws private public internal open static"), lit: KW("true false nil") },
    dart: { c: "c", kw: KW("abstract as async await break case catch class const continue default do else enum extends final finally for if implements import in is new return static super switch this throw try var void while with"), lit: KW("true false null") },
    lua: { c: "dash", kw: KW("and break do else elseif end for function if in local not or repeat return then until while"), lit: KW("true false nil") },
    r: { c: "hash", kw: KW("function if else for while repeat break next return in"), lit: KW("TRUE FALSE NULL NA") },
    yaml: { c: "hash", kw: KW(""), lit: KW("true false null yes no") },
    toml: { c: "hash", kw: KW(""), lit: KW("true false") },
    docker: { c: "hash", ci: true, kw: KW("from run cmd label expose env add copy entrypoint volume user workdir arg onbuild healthcheck shell"), lit: KW("") }
  };

  function hlGeneric(src, spec) {
    const cm = spec.c === "hash" ? "#[^\\n]*" : spec.c === "dash" ? "--[^\\n]*"
      : spec.c === "c+hash" ? "\\/\\/[^\\n]*|#[^\\n]*|\\/\\*[\\s\\S]*?(?:\\*\\/|$)"
      : "\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?(?:\\*\\/|$)";
    const re = new RegExp("(" + cm + ")|(\"\"\"[\\s\\S]*?(?:\"\"\"|$)|'''[\\s\\S]*?(?:'''|$)|\"(?:\\\\.|[^\"\\\\\\n])*\"?|'(?:\\\\.|[^'\\\\\\n])*'?|`(?:\\\\[\\s\\S]|[^`\\\\])*`?)|(\\b0x[\\da-f]+\\b|\\b\\d[\\d_]*\\.?\\d*(?:e[+-]?\\d+)?\\b)|([A-Za-z_$][\\w$]*)|(\\s+|[^\\w\\s]|\\w+)", "gi");
    const defWord = /^(?:def|class|fn|func|function|struct|interface|enum|trait|impl|type)$/;
    let out = "", m, prev = "";
    while ((m = re.exec(src))) {
      if (m[1]) out += hlSpan("t-c", m[1]);
      else if (m[2]) out += hlSpan("t-s", m[2]);
      else if (m[3]) out += hlSpan("t-n", m[3]);
      else if (m[4]) {
        const w = m[4], k = spec.ci ? w.toLowerCase() : w;
        if (spec.kw.has(k)) { out += hlSpan("t-k", w); prev = k; continue; }
        if (spec.lit.has(k)) out += hlSpan("t-n", w);
        else if (defWord.test(prev) || /^\s*\(/.test(src.slice(re.lastIndex, re.lastIndex + 40))) out += hlSpan("t-f", w);
        else out += hlEsc(w);
      } else if (/^[{}()[\];,.:=<>+\-*/%!&|?^~@]$/.test(m[5])) out += hlSpan("t-p", m[5]);
      else out += hlEsc(m[5]);
      if (m[5] === undefined || !/^\s+$/.test(m[5])) prev = "";
    }
    return out;
  }

  function hlDiff(src) {
    return src.split("\n").map((l) => {
      if (/^(\+\+\+|---)/.test(l)) return hlSpan("t-k", l);
      if (/^@@/.test(l)) return hlSpan("t-f", l);
      if (/^\+/.test(l)) return hlSpan("t-s", l);
      if (/^-/.test(l)) return hlSpan("t-t", l);
      return hlEsc(l);
    }).join("\n");
  }

  function hlCode(lang, code) {
    switch (lang) {
      case "html": case "xml": return hlHTML(code);
      case "css": return hlCSS(code);
      case "javascript": case "typescript": case "json": return hlJS(code);
      case "diff": return hlDiff(code);
      default: return GENERIC[lang] ? hlGeneric(code, GENERIC[lang]) : hlEsc(code);
    }
  }

  // decides what a fenced block really is: { lang, label, mono }; lang "" = not code
  function resolveCode(hint, code) {
    const h = String(hint || "").trim().toLowerCase();
    const alias = LANG_ALIAS[h] || "";
    const found = detectLang(code);
    if (alias) {
      const web = alias === "html" || alias === "css" || alias === "javascript";
      const sameFamily = (alias === "javascript" && found === "typescript") || (alias === "typescript" && found === "javascript");
      // trust the label, unless the code is clearly another language (e.g. Python inside an "html" block)
      if (web && found && found !== alias && !sameFamily) return { lang: found, label: found };
      return { lang: alias, label: h };
    }
    if (found) return { lang: found, label: found };
    // no language: prose (lyrics, a poem, a quote...) is shown as plain text; aligned/ASCII text keeps a mono box
    return { lang: "", label: h || "text", mono: /[│├└┌┐┘┬┴┼═║╔╗╚╝]|\S {3,}\S|^\t/m.test(code) };
  }

  // the "one code" box colours whatever was pasted, by what it really is
  function hlAuto(src) {
    const d = detectLang(src);
    return d && d !== "html" ? hlCode(d, src) : hlHTML(src);
  }
  const hlFor = (lang, s) => lang === "auto" ? hlAuto(s) : lang === "css" ? hlCSS(s) : lang === "js" ? hlJS(s) : lang === "py" ? hlCode("python", s) : hlHTML(s);

  /* --- one code box: line numbers + coloured text under a transparent textarea --- */
  function makeEditor(lang, value, placeholder, onInput) {
    const root = el("div", "cp-ed");
    const gut = el("div", "cp-gut");
    gut.setAttribute("aria-hidden", "true");
    const nums = el("div", "cp-nums");
    gut.appendChild(nums);

    const sc = el("div", "cp-sc");
    const pre = el("pre", "cp-hl");
    pre.setAttribute("aria-hidden", "true");

    const ta = document.createElement("textarea");
    ta.className = "cp-code";
    ta.value = value;
    ta.placeholder = placeholder;
    ta.setAttribute("aria-label", placeholder);
    ta.setAttribute("wrap", "off");
    ta.spellcheck = false;
    ta.autocomplete = "off";
    ta.setAttribute("autocapitalize", "off");
    ta.setAttribute("autocorrect", "off");

    sc.append(pre, ta);
    root.append(gut, sc);

    function sync() {
      pre.style.transform = `translate(${-ta.scrollLeft}px, ${-ta.scrollTop}px)`;
      nums.style.transform = `translateY(${-ta.scrollTop}px)`;
    }
    function paint() {
      const v = ta.value;
      pre.innerHTML = hlFor(lang, v) + "\n";
      const n = v.split("\n").length;
      let s = "";
      for (let i = 1; i <= n; i++) s += i + "\n";
      nums.textContent = s;
      gut.style.width = (Math.max(2, String(n).length) * 8.4 + 22) + "px";
      sync();
    }
    ta.addEventListener("input", () => { paint(); onInput(ta.value); });
    ta.addEventListener("scroll", sync, { passive: true });
    paint();
    return { root, ta, paint };
  }

  /* ---------- Projects: code the AI wrote in any chat is saved here automatically, with a name ---------- */
  const projDB = {
    async all() { const a = await photoDB.run("readonly", (s) => s.get("projects")).catch(() => null); return Array.isArray(a) ? a : []; },
    save(list)  { return photoDB.run("readwrite", (s) => s.put(list.slice(0, 80), "projects")).catch(() => null); }
  };
  let projLock = Promise.resolve();
  const projQueue = (fn) => { const run = projLock.then(fn); projLock = run.catch(() => {}); return run; };

  const NOT_CODE = new Set(["bash", "sh", "shell", "zsh", "console", "terminal", "text", "txt", "plaintext", "json", "yaml", "yml", "markdown", "md", "diff", "csv", "mermaid", "log", "output", "toml", "ini"]);

  // one AI reply -> a project (or null when it has no real code)
  function extractProject(text) {
    const re = /```([^\n`]*)\n([\s\S]*?)```/g;
    const by = { html: [], css: [], js: [], py: [], other: [] };
    let m, found = 0;
    while ((m = re.exec(String(text || "")))) {
      let lang = (m[1] || "").trim().split(/\s+/)[0].toLowerCase();
      const code = m[2].replace(/\s+$/, "");
      if (code.trim().length < 25) continue;                    // one-liners (an install command...) are not projects
      if (!lang) { const k = detectLang(code); lang = k === "javascript" ? "js" : k === "python" ? "py" : (k || "other"); }
      if (["html", "htm", "svg"].includes(lang)) by.html.push(code);
      else if (lang === "css") by.css.push(code);
      else if (["js", "javascript", "jsx", "mjs"].includes(lang)) by.js.push(code);
      else if (["py", "python", "python3"].includes(lang)) by.py.push(code);
      else if (!NOT_CODE.has(lang)) by.other.push(code);
      else continue;
      found++;
    }
    if (!found) return null;
    const j = (a) => a.join("\n\n");
    let html = j(by.html), css = j(by.css), js = j(by.js), py = j(by.py);
    if (/<style[\s>]/i.test(html)) css = "";
    if (/<script(?![^>]*\bsrc\b)[^>]*>\s*\S/i.test(html)) js = "";
    const kinds = [html, css, js, py].filter(Boolean).length;
    let p;
    if (!kinds) { const o = j(by.other); p = { mode: "one", code: o, parts: { html: "", css: "", js: "", py: "" } }; }
    else if (kinds === 1) p = { mode: "one", code: html || css || js || py, parts: { html: "", css: "", js: "", py: "" } };
    else p = { mode: "sep", code: "", parts: { html, css, js, py } };
    const main = p.mode === "one" ? p.code : (html || js || py || css);
    p.snip = main.replace(/\s+/g, " ").trim().slice(0, 140);
    return p;
  }

  function projFallbackName(rec) {
    const hay = rec.mode === "one" ? rec.code : (rec.parts.html || "");
    const ti = /<title[^>]*>([^<]{2,40})<\/title>/i.exec(hay);
    if (ti) return ti[1].trim();
    const words = String(rec.ask || "").replace(/\s+/g, " ").trim().split(" ").slice(0, 4).join(" ");
    return words || "Untitled project";
  }

  // the AI gives the project a short name
  async function nameProject(id) {
    try {
      const rec = (await projDB.all()).find((x) => x.id === id);
      if (!rec || rec.named) return;
      const body = rec.mode === "one" ? rec.code : [rec.parts.html, rec.parts.css, rec.parts.js, rec.parts.py].filter(Boolean).join("\n\n");
      const raw = await groq(GPT_KEY, {
        model: GPT_MODEL,
        messages: [
          { role: "system", content: "Name this coding project in 2 to 4 words, in the same language as the user's request. Reply with the name only: no quotes, no markdown, no final punctuation." },
          { role: "user", content: "Request: " + String(rec.ask || "").slice(0, 300) + "\n\nCode:\n" + body.slice(0, 1200) }
        ],
        temperature: 0.3, max_completion_tokens: 1000, stream: false
      }, 30000);
      const name = raw.split("\n")[0].replace(/^[\"'“”«»\s#*_-]+|[\"'“”«»\s*_.:!؟?،,]+$/g, "").slice(0, 40).trim();
      if (!name) return;
      await projQueue(async () => {
        const list = await projDB.all();
        const cur = list.find((x) => x.id === id);
        if (cur && !cur.named) { cur.name = name; cur.named = 1; await projDB.save(list); }
      });
    } catch (e) { console.error("[iMa! project name]", e); }
  }

  // after an AI reply: keep its code as this chat's project (the newest code replaces the older version)
  function captureProject(text, ask, cid) {
    const p = extractProject(text);
    if (!p || !cid) return;
    projQueue(async () => {
      const list = await projDB.all();
      let rec = list.find((x) => x.chatId === cid);
      const isNew = !rec;
      if (isNew) { rec = { id: newId("p"), chatId: cid, name: "", named: 0 }; list.unshift(rec); }
      Object.assign(rec, { ts: Date.now(), ask: String(ask || "").slice(0, 300), mode: p.mode, code: p.code, parts: p.parts, snip: p.snip });
      if (isNew) rec.name = projFallbackName(rec);
      await projDB.save(list);
      if (isNew) nameProject(rec.id);
    }).catch(() => {});
  }

  // chats made before Projects existed: pick up their code too (named after the chat)
  async function backfillProjects() {
    await projQueue(async () => {
      const list = await projDB.all();
      let changed = false;
      chats.forEach((c) => {
        if (list.some((x) => x.chatId === c.id)) return;
        const msgs = (c.msgs || []).slice().reverse();
        for (const mm of msgs) {
          if (mm.role !== "in" || !mm.text || mm.text.indexOf("```") < 0) continue;
          const p = extractProject(mm.text);
          if (!p) continue;
          const q = (c.msgs || []).find((x) => x.role === "out");
          list.push({ id: newId("p"), chatId: c.id, name: String(c.title || "").slice(0, 40) || "Untitled project", named: 1, ts: c.updated || c.ts || Date.now(),
            ask: q ? String(q.text || "").slice(0, 300) : "", mode: p.mode, code: p.code, parts: p.parts, snip: p.snip });
          changed = true;
          break;
        }
      });
      if (changed) { list.sort((a, b) => b.ts - a.ts); await projDB.save(list); }
    }).catch(() => {});
  }

  async function updateProj(id, fn) {
    await projQueue(async () => {
      const list = await projDB.all();
      const r = list.find((x) => x.id === id);
      if (r) { fn(r); await projDB.save(list); }
    });
  }

  // Python runs right in the browser through Pyodide (downloaded from a CDN the first time you run it)
  const PY_URL = "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js";
  function cpPyTags(code) {
    const j = JSON.stringify(code).replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
    const boot = '(async()=>{const o=document.getElementById("__py");' +
      'const add=(s,e)=>{const d=document.createElement("div");d.textContent=s;if(e)d.style.color="#ff8a80";o.appendChild(d)};' +
      'const st=document.createElement("div");st.textContent=' + JSON.stringify(t("pyLoading")) + ';st.style.color="#8e8e93";o.appendChild(st);' +
      'try{const py=await loadPyodide({stdout:s=>add(s),stderr:s=>add(s,1)});st.remove();await py.runPythonAsync(' + j + ');}' +
      'catch(e){st.remove();add(String(e.message||e),1)}})();';
    return '<pre id="__py" style="margin:12px 0 0;padding:16px;border-radius:12px;background:#111214;color:#e6e6ea;font:13.5px/1.6 ui-monospace,Menlo,Consolas,monospace;white-space:pre-wrap;word-break:break-word"></pre>' +
      '<script src="' + PY_URL + '"><\/script><script>' + boot + '<\/script>';
  }
  function cpPyPage(code) {
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body style="margin:0;padding:0 12px 12px;background:#000">' + cpPyTags(code) + "</body></html>";
  }

  /* --- join HTML + CSS + JS into one page, like any code editor preview --- */
  function cpBuild() {
    if (cpMode === "one") {
      const k = detectLang(cpCode);
      const shell = (inner) => '<!DOCTYPE html>\n<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head>' + inner + "</html>";
      // plain JavaScript runs on a blank page; other languages can't run in a browser preview
      if (k === "python") return cpPyPage(cpCode);
      if (k === "javascript") return shell("<body><script>\n" + cpCode.replace(/<\/script/gi, "<\\/script") + "\n</script></body>");
      if (k && k !== "html" && k !== "css" && k !== "xml") return shell('<body style="font:16px/1.5 system-ui,sans-serif;padding:24px;color:#555">' + escHtml(t("cantRun", k)) + "</body>");
      return cpCode;
    }
    if (cpParts.py.trim() && !cpParts.html.trim() && !cpParts.css.trim() && !cpParts.js.trim()) return cpPyPage(cpParts.py);
    const css = cpParts.css.replace(/<\/style/gi, "<\\/style");
    const js  = cpParts.js.replace(/<\/script/gi, "<\\/script");
    const styleTag  = css.trim() ? `<style>\n${css}\n</style>` : "";
    const scriptTag = (js.trim()  ? `<script>\n${js}\n</script>` : "") + (cpParts.py.trim() ? cpPyTags(cpParts.py) : "");
    let h = cpParts.html;

    if (/<\/head\s*>/i.test(h)) h = h.replace(/<\/head\s*>/i, () => styleTag + "\n</head>");
    else if (/<html[\s>]/i.test(h) || /<!doctype/i.test(h)) h = h.replace(/(<html[^>]*>)/i, (x) => x + "\n<head>" + styleTag + "</head>");
    else h = '<!DOCTYPE html>\n<html>\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n' + styleTag + "\n</head>\n<body>\n" + h + "\n</body>\n</html>";

    if (/<\/body\s*>/i.test(h)) h = h.replace(/<\/body\s*>/i, () => scriptTag + "\n</body>");
    else h += "\n" + scriptTag;
    return h;
  }

  function cpHasCode() {
    return cpMode === "one" ? !!cpCode.trim() : !!(cpParts.html.trim() || cpParts.css.trim() || cpParts.js.trim() || cpParts.py.trim());
  }

  function openCodePreview(startOpts = {}) {
    if (app.querySelector(".cp")) return;

    const page = el("div", "cp");
    page.setAttribute("role", "dialog");
    page.setAttribute("aria-label", t("codePreview"));

    /* top bar: "<" on the left, Code / Run slider in the middle */
    const bar = el("div", "cp-bar");

    const back = el("button", "glass tap bar-circle");
    back.type = "button";
    back.setAttribute("aria-label", t("back"));
    back.innerHTML = BACK;

    const seg = el("div", "seg cp-seg");
    seg.setAttribute("role", "radiogroup");
    seg.setAttribute("aria-label", t("codePreview"));
    seg.style.setProperty("--n", "2");
    seg.style.setProperty("--i", "0");
    const thumb = el("span", "seg-thumb");
    thumb.setAttribute("aria-hidden", "true");
    seg.appendChild(thumb);

    const mkTab = (icon, label, checked) => {
      const b = el("button");
      b.type = "button";
      b.setAttribute("role", "radio");
      b.setAttribute("aria-checked", String(checked));
      b.setAttribute("aria-label", label);
      b.innerHTML = `<img src="assets/icons/${icon}.png" alt="">`;
      return b;
    };
    const codeTab = mkTab("code", t("codeTab"), true);
    const runTab  = mkTab("run",  t("runTab"),  false);
    seg.append(codeTab, runTab);

    const projBtn = el("button", "glass tap bar-circle cp-proj-btn");
    projBtn.type = "button";
    projBtn.setAttribute("aria-label", t("projects"));
    projBtn.title = t("projects");
    projBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.8"/></svg>';
    const left = el("div", "cp-left glass");
    left.append(back, projBtn);

    /* "..." on the right: pick the language (Web: separated / one code, or Python) */
    const langBtn = el("button", "glass tap bar-circle cp-lang-btn");
    langBtn.type = "button";
    langBtn.setAttribute("aria-label", t("langMenu"));
    langBtn.title = t("langMenu");
    langBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5.5" cy="12" r="1.9"/><circle cx="12" cy="12" r="1.9"/><circle cx="18.5" cy="12" r="1.9"/></svg>';
    bar.append(left, seg, langBtn);

    /* file tabs (plain text, no slider): only for Web > Separated */
    const LANGS = ["html", "css", "js", "py"];
    const opts = el("div", "cp-opts cp-ftabs");
    const ftabs = ["HTML", "CSS", "JS"].map((label, i) => {
      const b = el("button", "cp-ftab");
      b.type = "button";
      b.setAttribute("role", "tab");
      b.textContent = label;
      b.addEventListener("click", () => { cpLang = LANGS[i]; showEditor(); });
      opts.appendChild(b);
      return b;
    });

    /* body: the code boxes, and the preview */
    const body = el("div", "cp-body");
    const fab = el("button", "cp-fab");
    fab.type = "button";
    fab.setAttribute("aria-label", t("runTab"));
    fab.innerHTML = '<img src="assets/icons/run.png" alt="">';
    fab.addEventListener("click", () => show("run"));

    const editors = {
      one:  makeEditor("auto", cpCode,       t("pasteCode"), (v) => { cpCode = v; }),
      html: makeEditor("html", cpParts.html, t("pasteHtml"), (v) => { cpParts.html = v; }),
      css:  makeEditor("css",  cpParts.css,  t("pasteCss"),  (v) => { cpParts.css = v; }),
      js:   makeEditor("js",   cpParts.js,   t("pasteJs"),   (v) => { cpParts.js = v; }),
      py:   makeEditor("py",   cpParts.py,   t("pastePy"),   (v) => { cpParts.py = v; })
    };

    const view = el("div", "cp-view");
    view.hidden = true;
    const frame = document.createElement("iframe");
    frame.className = "cp-frame";
    frame.title = t("runTab");
    // scripts run, but in their own sandbox: pasted code can't reach iMa!'s chats or settings
    frame.setAttribute("sandbox", "allow-scripts allow-forms allow-modals allow-popups");
    const none = el("div", "empty cp-none");
    none.textContent = t("nothingToRun");
    none.hidden = true;
    view.append(frame, none);

    const projView = el("div", "cp-projview");
    projView.hidden = true;
    body.append(editors.one.root, editors.html.root, editors.css.root, editors.js.root, editors.py.root, view, projView, fab);
    page.append(bar, opts, body);

    let running = false;

    function showEditor() {
      const key = cpMode === "one" ? "one" : cpLang;
      Object.keys(editors).forEach((k) => { editors[k].root.hidden = running || inProj || k !== key; });
      const web = cpMode === "sep" && cpLang !== "py";
      opts.hidden = running || inProj || !web;
      ftabs.forEach((b, i) => b.setAttribute("aria-selected", String(LANGS[i] === cpLang)));
      fab.hidden = running || inProj;
    }

    function show(which) {
      const run = which === "run";
      inProj = false; projView.hidden = true; closePMenu(); closeLMenu(); projBtn.classList.remove("on"); seg.classList.remove("idle");
      running = run;
      seg.style.setProperty("--i", run ? "1" : "0");
      codeTab.setAttribute("aria-checked", String(!run));
      runTab.setAttribute("aria-checked", String(run));
      view.hidden = !run;
      showEditor();
      if (run) {
        document.activeElement && document.activeElement.blur && document.activeElement.blur();
        const has = cpHasCode();
        frame.hidden = !has;
        none.hidden = has;
        frame.srcdoc = has ? cpBuild() : "";
      }
    }

    /* language menu */
    let lmenu = null, lscrim = null;
    function closeLMenu() { if (lmenu) { lmenu.remove(); lmenu = null; } if (lscrim) { lscrim.remove(); lscrim = null; } langBtn.classList.remove("on"); }
    function curKind() { return cpLang === "py" && cpMode === "sep" ? "py" : cpMode === "one" ? "one" : "sep"; }
    function pickKind(k) {
      if (k === "py") { cpMode = "sep"; cpLang = "py"; }
      else if (k === "sep") { cpMode = "sep"; if (cpLang === "py") cpLang = "html"; }
      else { cpMode = "one"; }
      show(running ? "run" : "code");
    }
    let webOpen = true;
    function openLMenu() {
      if (lmenu) { closeLMenu(); return; }
      closePMenu();
      document.activeElement && document.activeElement.blur && document.activeElement.blur();
      langBtn.classList.add("on");
      lscrim = el("div", "cp-pscrim");
      lscrim.addEventListener("click", closeLMenu);
      lmenu = el("div", "menu menu--attach material cp-pmenu cp-lmenu");
      lmenu.setAttribute("role", "menu");
      const cur = curKind();
      const mkCheck = (b) => { const img = el("img", "mi"); img.src = "assets/icons/check.png"; img.alt = ""; b.appendChild(img); };

      /* Web: accordion with Separated / One code */
      const acc = el("div", "cp-acc" + (webOpen ? " open" : ""));
      const head = el("button", "menu-item cp-litem cp-acc-head");
      head.type = "button"; head.setAttribute("aria-expanded", String(webOpen));
      const hl = el("span", "menu-label"); const hn = el("span"); hn.textContent = t("webLang"); hl.appendChild(hn);
      const chev = el("span", "cp-chev");
      chev.innerHTML = '<svg viewBox="0 0 12 8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.5 1.5L6 6l4.5-4.5"/></svg>';
      head.append(hl, chev);
      head.addEventListener("click", () => { webOpen = !webOpen; acc.classList.toggle("open", webOpen); head.setAttribute("aria-expanded", String(webOpen)); });
      const accBody = el("div", "cp-acc-body"); const inner = el("div", "cp-acc-in");
      const row = (host, k, label, sub, cls) => {
        const b = el("button", "menu-item cp-litem " + (cls || ""));
        b.type = "button"; b.setAttribute("role", "menuitemradio"); b.setAttribute("aria-checked", String(cur === k));
        const lab = el("span", "menu-label");
        const nm = el("span"); nm.textContent = label; lab.appendChild(nm);
        if (sub) { const sb = el("small"); sb.textContent = sub; sb.dir = "ltr"; lab.appendChild(sb); }
        b.appendChild(lab);
        if (cur === k) mkCheck(b);
        b.addEventListener("click", () => { closeLMenu(); pickKind(k); });
        host.appendChild(b);
      };
      row(inner, "sep", t("separatedOpt"), "HTML, CSS, JS", "sub");
      row(inner, "one", t("oneCode"), "index.html", "sub");
      accBody.appendChild(inner);
      acc.append(head, accBody);
      lmenu.appendChild(acc);

      /* Python: normal row */
      row(lmenu, "py", "Python", "", "");
      page.append(lscrim, lmenu);
    }
    langBtn.addEventListener("click", openLMenu);

    /* Projects: a page of its own (like the Code and Run tabs): every chat where the AI wrote code */
    let inProj = false;
    let pmenu = null, pscrim = null;
    function closePMenu() { if (pmenu) { pmenu.remove(); pmenu = null; } if (pscrim) { pscrim.remove(); pscrim = null; } }

    function loadProject(rec) {
      if (rec.mode === "sep") {
        cpMode = "sep";
        cpParts = Object.assign({ html: "", css: "", js: "", py: "" }, rec.parts);
        cpLang = LANGS.find((k) => cpParts[k]) || "html";
      } else { cpMode = "one"; cpCode = rec.code || ""; }
      editors.one.ta.value = cpCode;
      LANGS.forEach((k) => { editors[k].ta.value = cpParts[k]; });
      Object.keys(editors).forEach((k) => editors[k].paint());
      show("code");
    }

    function renameProject(rec) {
      modal.style.zIndex = "85";                                 // above this page
      openSheet(t("rename"), (box) => {
        const r = el("div", "row row-text");
        const input = document.createElement("input");
        input.type = "text"; input.className = "rename-input"; input.maxLength = 40; input.dir = "auto"; input.autocomplete = "off";
        input.value = rec.name || "";
        input.setAttribute("aria-label", t("rename"));
        input.addEventListener("input", () => {
          const v = input.value.trim().slice(0, 40);
          if (v) { rec.name = v; updateProj(rec.id, (x) => { x.name = v; x.named = 1; }).then(() => { if (inProj) drawProjects(); }); }
        });
        r.appendChild(input);
        box.appendChild(group(r));
      });
    }

    // press and hold a project: pin, rename, delete
    function openPMenu(anchor, rec) {
      closePMenu();
      pscrim = el("div", "cp-pscrim");
      pscrim.addEventListener("click", closePMenu);
      pmenu = el("div", "menu menu--attach material cp-pmenu");
      pmenu.setAttribute("role", "menu");
      const items = [
        { label: t(rec.pin ? "unpin" : "pin"), icon: "label-pin", run: async () => { await updateProj(rec.id, (x) => { x.pin = x.pin ? 0 : 1; }); drawProjects(); } },
        { label: t("rename"), icon: "rename", run: () => renameProject(rec) },
        { label: t("delete"), icon: "trash-red", danger: true, run: async () => { await projQueue(async () => { await projDB.save((await projDB.all()).filter((x) => x.id !== rec.id)); }); drawProjects(); } }
      ];
      items.forEach((it) => {
        const b = el("button", "menu-item" + (it.danger ? " danger" : ""));
        b.type = "button"; b.setAttribute("role", "menuitem");
        const lab = el("span", "menu-label"); const nm = el("span"); nm.textContent = it.label; lab.appendChild(nm);
        const img = el("img", "mi"); img.src = "assets/icons/" + it.icon + ".png"; img.alt = "";
        b.append(lab, img);
        b.addEventListener("click", () => { closePMenu(); it.run(); });
        pmenu.appendChild(b);
      });
      page.append(pscrim, pmenu);
      const pr = page.getBoundingClientRect(), r = anchor.getBoundingClientRect();
      const top = Math.min(r.bottom - pr.top - 6, pr.height - pmenu.offsetHeight - 14);
      pmenu.style.top = Math.max(70, top) + "px";
      pmenu.style.insetInlineStart = "28px";
    }

    async function drawProjects() {
      const list = (await projDB.all()).sort((a, b) => (b.pin ? 1 : 0) - (a.pin ? 1 : 0) || (b.ts || 0) - (a.ts || 0));
      projView.innerHTML = "";
      const card = el("div", "cp-pcard");
      if (!list.length) {
        const none = el("div", "cp-pnone"); none.textContent = t("noProjects");
        card.appendChild(none);
      }
      list.forEach((rec) => {
        const main = el("button", "cp-pmain");
        main.type = "button";
        const ti = el("div", "cp-ptitle");
        if (rec.pin) { const pi = el("img", "cp-ppin"); pi.src = "assets/icons/label-pin.png"; pi.alt = ""; ti.appendChild(pi); }
        const tx = el("span"); tx.textContent = rec.name || "Untitled project"; tx.dir = "auto";
        ti.appendChild(tx);
        const meta = el("div", "cp-pmeta");
        const d = el("span", "cp-pdate"); d.textContent = new Date(rec.ts || Date.now()).toLocaleDateString("en-US", { month: "2-digit", day: "2-digit", year: "2-digit" });
        const sn = el("span", "cp-psnip"); sn.textContent = rec.snip || "";
        meta.append(d, sn);
        main.append(ti, meta);

        let timer = null, fired = false, sx = 0, sy = 0;
        const stop = () => { clearTimeout(timer); timer = null; };
        const pop = () => { fired = true; openPMenu(main, rec); };
        main.addEventListener("pointerdown", (e) => { fired = false; sx = e.clientX; sy = e.clientY; timer = setTimeout(pop, 420); });
        main.addEventListener("pointermove", (e) => { if (timer && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) stop(); });
        ["pointerup", "pointerleave", "pointercancel"].forEach((ev) => main.addEventListener(ev, stop));
        main.addEventListener("contextmenu", (e) => { e.preventDefault(); stop(); pop(); });
        main.addEventListener("click", () => { if (fired) { fired = false; return; } loadProject(rec); });
        card.appendChild(main);
      });
      projView.appendChild(card);
    }

    async function openProjects() {
      if (inProj) { show(running ? "run" : "code"); return; }
      document.activeElement && document.activeElement.blur && document.activeElement.blur();
      inProj = true;
      projBtn.classList.add("on");
      seg.classList.add("idle");
      codeTab.setAttribute("aria-checked", "false");
      runTab.setAttribute("aria-checked", "false");
      closeLMenu();
      view.hidden = true;
      projView.hidden = false;
      showEditor();
      await backfillProjects();
      if (inProj) drawProjects();
    }
    projBtn.addEventListener("click", openProjects);

    codeTab.addEventListener("click", () => show("code"));
    runTab.addEventListener("click",  () => show("run"));

    const onKey = (e) => { if (e.key === "Escape") close(); };
    function close() {
      document.removeEventListener("keydown", onKey);
      frame.srcdoc = "";                       // stop anything still running
      closePMenu(); closeLMenu();
      page.classList.add("closing");
      setTimeout(() => page.remove(), 220);
    }
    back.addEventListener("click", close);
    document.addEventListener("keydown", onKey);

    app.appendChild(page);
    showEditor();
    if (startOpts.run) show("run");
  }

  function confirmDelete() {
    openAlert(t("deleteTitle"), t("deleteMsg"), [
      { label: t("cancel") },
      { label: t("delete"), danger: true, onClick: () => { if (chatId) removeSaved(chatId); startChat(); showToast(t("deleted")); } }
    ]);
  }

  async function shareChat() {
    const text = history.map((m) => {
      const who = m.role === "out" ? t("you") : "iMa!";
      const pics = m.images ? t("pics", m.images) : "";
      return `${who}: ${m.text}${pics}`.trim();
    }).join("\n");

    try {
      if (navigator.share) { await navigator.share({ title: "iMa! chat", text }); return; }
    } catch (e) {
      if (e && e.name === "AbortError") return;
    }

    try {
      await navigator.clipboard.writeText(text);
      showToast(t("copied"));
    } catch (e) {
      showToast(t("shareFail"));
    }
  }


  /* ---------- Composer ---------- */

  function growInput() {
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 132) + "px";
    syncCommand();
    fitComposer();
  }

  function syncSend() {
    const hasText = !!((modes.image || modes.tool) ? input.value.replace(CMD_RE, "") : input.value).trim();
    // "Create image" needs a description; tools need a query (weather / news may stay empty); otherwise a picture alone is enough
    const ready = modes.image ? hasText : modes.tool ? (hasText || TOOL_OPTIONAL.has(modes.tool)) : (hasText || pending.length > 0);
    sendBtn.disabled = busy || !ready;
  }

  function fitComposer() {
    root.style.setProperty("--composer-h", composer.offsetHeight + "px");
  }

  async function send() {
    syncCommand();
    const imageMode = modes.image, toolMode = modes.tool;
    const typed = ((imageMode || toolMode) ? input.value.replace(CMD_RE, "") : input.value).trim();
    if (busy) return;
    if (toolMode ? (!typed && !TOOL_OPTIONAL.has(toolMode)) : (!typed && !pending.length)) return;
    if (imageMode && !typed) return;
    const text = typed || (toolMode === "weather" ? t("wxHere") : toolMode === "news" ? t("newsTop") : "");
    if (editing) commitEdit();

    const images = pending.map((p) => p.url);
    uploads.push(...images);
    pending = [];
    input.value = "";
    renderTray();
    growInput();

    const quote = replyTo ? replyTo.text : "";
    const qrole = replyTo ? replyTo.role : "in";
    replyTo = null;
    renderModes();
    const mine = addMessage("out", { text, images, quote, qrole, md: !!text });
    if (images.length) mine._pids = storePics(images);
    showReceipt(mine);
    saveChat();

    busy = true;
    syncSend();
    setTimeout(showTyping, 350);

    let titleNow = false, codeText = "";
    if (imageMode) {
      let url = "";
      try { url = await getImage({ text, images, model }); } catch (e) {}
      busy = false;
      clearReceipt();
      if (url) {
        uploads.push(url);
        const made = addMessage("in", { text: t("imageReady"), images: [url] });
        made._pids = storePics([url]);
      }
      else addMessage("in", { text: t("aiError") });
    } else if (toolMode) {
      // live data first (weather / news / web / pictures / map), then GPT writes the answer from it
      let tool;
      try { tool = await runTool(toolMode, typed); } catch (e) { console.error("[iMa! tool]", e); tool = { fail: t(TOOL_FAIL[toolMode]) }; }
      if (tool.fail) {
        busy = false;
        clearReceipt();
        addMessage("in", { text: tool.fail });
      } else {
        const reply = await getReply({ text, images, quote, model, modes: { ...modes, tool: "" }, extra: tool.block });
        busy = false;
        clearReceipt();
        const photos = reply.ok ? (tool.photos || []) : [];
        photos.forEach((u) => uploads.push(u));
        const answer = addMessage("in", { text: reply.text, images: photos, md: reply.ok });
        if (reply.ok) { answer._ci = reply.ci; if (tool.map) attachMap(answer, tool.map); } else answer._noRegen = true;
        titleNow = reply.ok;
      }
    } else {
      const reply = await getReply({ text, images, quote, model, modes: { ...modes } });
      busy = false;
      clearReceipt();
      if (reply.ok && reply.photos) reply.photos.forEach((u) => uploads.push(u));
      const answer = addMessage("in", { text: reply.text, images: reply.photos || [], md: reply.ok });
      if (reply.ok) answer._ci = reply.ci; else answer._noRegen = true;
      titleNow = reply.ok;
      if (reply.ok) codeText = reply.text;
    }
    saveChat();
    if (codeText) captureProject(codeText, text, chatId);
    if (titleNow) autoTitle(chatId);
    syncSend();
  }

  /* ---------- "/" commands: type / in the message box to see them ---------- */
  const COMMANDS = [
    { name: "imagine", ico: "", label: () => t("cmdImagine"), desc: () => t("cmdImagineDesc") },
    { name: "weather", ico: "", label: () => t("cmdWeather"), desc: () => t("cmdWeatherDesc") },
    { name: "news",    ico: "",    label: () => t("cmdNews"),    desc: () => t("cmdNewsDesc") },
    { name: "map",     ico: "",     label: () => t("cmdMap"),     desc: () => t("cmdMapDesc") }
  ];
  const slashMenu = el("div", "slash-menu material");
  slashMenu.setAttribute("role", "listbox");
  slashMenu.hidden = true;
  slashMenu.addEventListener("pointerdown", (e) => e.preventDefault());   // keep the keyboard open
  // the list lives inside the message box itself, above where you type
  const slashField = composer.querySelector(".field");
  slashField.insertBefore(slashMenu, slashField.firstChild);
  let slashList = [];

  function slashMatches() {
    const m = /^\/([a-z]*)$/i.exec(input.value);
    if (!m) return [];
    const q = m[1].toLowerCase();
    return COMMANDS.filter((c) => c.name.startsWith(q));
  }
  function closeSlash() { slashMenu.hidden = true; slashList = []; }
  function pickSlash(c) {
    closeSlash();
    pickedCmd = c.name;
    input.value = "/" + c.name;      // the command word turns blue; a space is added when you start typing
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
    growInput(); syncSend();
  }
  function updateSlash() {
    slashList = slashMatches();
    if (!slashList.length || menuState) { closeSlash(); return; }
    slashMenu.innerHTML = "";
    slashList.forEach((c, i) => {
      const b = el("button", "slash-item" + (i === 0 ? " first" : ""));
      b.type = "button";
      b.setAttribute("role", "option");
      const ic = c.ico ? el("img", "mi") : null;     // no icon: no empty slot, the text sits close to the edge
      if (ic) { ic.src = icon(c.ico); ic.alt = ""; ic.draggable = false; }
      const tx = el("span", "slash-text");
      const nm = el("span", "slash-name"); nm.textContent = "/" + c.name;
      const ds = el("span", "slash-desc"); ds.textContent = c.desc();
      tx.append(nm, ds);
      if (ic) b.append(ic);
      b.append(tx);
      b.addEventListener("click", () => pickSlash(c));
      slashMenu.appendChild(b);
    });
    slashMenu.hidden = false;
  }

  input.addEventListener("input", () => {
    if (pickedCmd) {
      const base = "/" + pickedCmd, v = input.value;
      if (v.toLowerCase() !== base) {
        if (v.length > base.length && v.slice(0, base.length).toLowerCase() === base && !/^\s/.test(v.slice(base.length))) {
          input.value = v.slice(0, base.length) + " " + v.slice(base.length);
          input.setSelectionRange(input.value.length, input.value.length);
        }
        pickedCmd = "";
      }
    }
    growInput(); syncSend(); updateSlash();
  });
  input.addEventListener("blur", () => setTimeout(closeSlash, 120));

  input.addEventListener("keydown", (e) => {
    if (!slashMenu.hidden && slashList.length) {
      if ((e.key === "Enter" && !e.shiftKey && !e.isComposing) || e.key === "Tab") { e.preventDefault(); pickSlash(slashList[0]); return; }
      if (e.key === "Escape") { e.preventDefault(); closeSlash(); return; }
    }
    const touch = window.matchMedia("(pointer: coarse)").matches;
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing && !touch && settings.enterSends) {
      e.preventDefault();
      send();
    }
  });

  sendBtn.addEventListener("pointerdown", (e) => e.preventDefault());
  sendBtn.addEventListener("click", send);


  /* ---------- New chat ---------- */

  function startChat(blank = false) {
    pending.forEach((p) => URL.revokeObjectURL(p.url));
    uploads.forEach((u) => URL.revokeObjectURL(u));
    pending = [];
    uploads = [];
    history = [];
    convo = [];
    chatId = null;
    chatTs = 0;
    busy = false;
    editing = null;
    renderModes();
    lastMsg = receipt = typingEl = null;
    thread.innerHTML = "";
    input.value = "";
    renderTray();
    growInput();
    syncSend();

    stamp();
    scrollToEnd(false);
  }


  /* ---------- Left drawer ---------- */

  function openDrawer() {
    closeMenu();
    renderChatList();
    drawer.classList.add("open");
    scrim.classList.add("open");
    drawer.setAttribute("aria-hidden", "false");
    drawerBtn.setAttribute("aria-expanded", "true");
  }

  function closeDrawer() {
    if (selMode) exitSelect();
    if (drawer.classList.contains("searching")) setSearching(false);
    drawer.classList.remove("open");
    scrim.classList.remove("open");
    drawer.setAttribute("aria-hidden", "true");
    drawerBtn.setAttribute("aria-expanded", "false");
  }

  drawerBtn.addEventListener("click", () => {
    drawer.classList.contains("open") ? closeDrawer() : openDrawer();
  });

  scrim.addEventListener("click", closeDrawer);

  drawer.querySelectorAll(".drawer-item").forEach((btn) => {
    btn.addEventListener("click", () => {
      closeDrawer();
      const action = btn.dataset.action;
      if (action === "settings") openSettings();
      if (action === "memory")   openMemory();
      if (action === "files")    openFiles();
      if (action === "codepreview") openCodePreview();
      if (action === "profile")  openProfile();
    });
  });


  /* ---------- Recent chats (kept in this browser) ---------- */

  const CHATS_KEY  = "ima-chats";
  const MAX_CHATS  = 40;
  const chatList   = $("chatList");
  const chatSearch = $("chatSearch");
  let showArchived = false;
  let opening = false;

  const newId = (prefix) => prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  // Pictures (uploads and AI-made) are kept in IndexedDB: localStorage is far too small for them.
  const PicDB = (() => {
    let opened = null;
    const open = () => opened || (opened = new Promise((resolve, reject) => {
      const r = indexedDB.open("ima-pics", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("pics", { keyPath: "id" });
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    }));
    const run = (mode, fn) => open().then((db) => new Promise((resolve, reject) => {
      const tx = db.transaction("pics", mode);
      const req = fn(tx.objectStore("pics"));
      tx.oncomplete = () => resolve(req && req.result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    }));
    return {
      put: (rec) => run("readwrite", (st) => st.put(rec)),
      get: (id) => run("readonly", (st) => st.get(id)),
      all: () => run("readonly", (st) => st.getAll()),
      del: (id) => run("readwrite", (st) => st.delete(id))
    };
  })();

  // returns the ids right away; the pictures are written in the background
  function storePics(urls) {
    return urls.map((u) => {
      const id = newId("p");
      fetch(u).then((r) => r.blob()).then((b) => shrinkImage(b, 1600))
        .then((b) => PicDB.put({ id, blob: b, ts: Date.now() }))
        .catch((e) => console.error("[iMa! pictures]", e));
      return id;
    });
  }

  async function loadPicUrls(ids) {
    const map = new Map();
    await Promise.all(ids.map(async (id) => {
      try {
        const rec = await PicDB.get(id);
        if (rec && rec.blob) map.set(id, URL.createObjectURL(rec.blob));
      } catch (e) {}
    }));
    return map;
  }

  function loadChats() {
    try { const a = JSON.parse(localStorage.getItem(CHATS_KEY) || "[]"); return Array.isArray(a) ? a : []; }
    catch (e) { return []; }
  }

  let chats = loadChats();

  function writeChats() {
    chats = chats.slice(0, MAX_CHATS);
    for (;;) {
      try { localStorage.setItem(CHATS_KEY, JSON.stringify(chats)); return; }
      catch (e) { if (chats.length <= 1) return; chats.pop(); }     // storage full: drop the oldest chat
    }
  }

  /* ---------- Trash: deleted chats and pictures wait here for 30 days ---------- */

  const TRASH_KEY = "ima-trash";
  const TRASH_DAYS = 30;
  const DAY_MS = 864e5;

  let trash = (() => {
    try {
      const o = JSON.parse(localStorage.getItem(TRASH_KEY) || "{}");
      return { chats: Array.isArray(o.chats) ? o.chats : [], files: Array.isArray(o.files) ? o.files : [] };
    } catch (e) { return { chats: [], files: [] }; }
  })();

  function writeTrash() {
    try { localStorage.setItem(TRASH_KEY, JSON.stringify(trash)); } catch (e) {}
  }

  const daysLeft = (it) => Math.max(0, Math.ceil(((it.deletedAt || 0) + TRASH_DAYS * DAY_MS - Date.now()) / DAY_MS));

  // pictures that belong to chats sitting in the Trash (kept out of Uploaded files)
  function trashedPicIds() {
    const ids = new Set();
    trash.chats.forEach((c) => (c.msgs || []).forEach((m) => (m.pids || []).forEach((p) => ids.add(p))));
    trash.files.forEach((f) => { if (f.kind === "db") ids.add(f.id); });
    return ids;
  }

  function trashChats(ids) {
    const now = Date.now();
    ids.forEach((id) => {
      const c = chats.find((x) => x.id === id);
      if (c) trash.chats.unshift({ ...c, deletedAt: now });
    });
    chats = chats.filter((x) => !ids.includes(x.id));
    writeChats();
    writeTrash();
  }

  function trashPictures(list) {
    const now = Date.now();
    list.forEach((it) => trash.files.unshift(it.kind === "db"
      ? { kind: "db", id: it.id, ts: it.ts || 0, deletedAt: now }
      : { kind: "web", src: it.src, ts: it.ts || 0, deletedAt: now }));
    writeTrash();
  }

  // forever: a chat's stored pictures go with it
  function eraseChats(list) {
    list.forEach((c) => (c.msgs || []).forEach((m) => (m.pids || []).forEach((pid) => PicDB.del(pid).catch(() => {}))));
  }

  // forever: the picture file is deleted and taken out of every saved chat
  async function eraseFiles(list) {
    const dbIds = new Set(list.filter((f) => f.kind === "db").map((f) => f.id));
    const urls = new Set(list.filter((f) => f.kind === "web").map((f) => f.src));
    for (const id of dbIds) { try { await PicDB.del(id); } catch (e) {} }
    urls.forEach((u) => removedWeb.add(u));
    uploads = uploads.filter((u) => !urls.has(u));
    chats.forEach((c) => {
      c.msgs = (c.msgs || []).filter((m) => {
        if (m.images) { m.images = m.images.filter((u) => !urls.has(u)); if (!m.images.length) delete m.images; }
        if (m.pids) { m.pids = m.pids.filter((pid) => !dbIds.has(pid)); if (!m.pids.length) delete m.pids; }
        return m.text || m.pics || m.images || m.pids || m.quote;      // a message that was only the deleted picture goes too
      });
    });
    writeChats();
  }

  function purgeTrash() {
    const cutoff = Date.now() - TRASH_DAYS * DAY_MS;
    const oldChats = trash.chats.filter((c) => (c.deletedAt || 0) < cutoff);
    const oldFiles = trash.files.filter((f) => (f.deletedAt || 0) < cutoff);
    if (!oldChats.length && !oldFiles.length) return;
    trash.chats = trash.chats.filter((c) => !oldChats.includes(c));
    trash.files = trash.files.filter((f) => !oldFiles.includes(f));
    writeTrash();
    eraseChats(oldChats);
    eraseFiles(oldFiles);
  }

  // What is kept of the open chat: text, web-photo links, and the ids of pictures stored in IndexedDB.
  function snapshotMessages() {
    const out = [];
    thread.querySelectorAll(".msg").forEach((m) => {
      const bubble = m.querySelector(".bubble");
      if (!m._h || (bubble && bubble.dataset.i18n)) return;          // typing dots, greeting
      const shown = Array.from(m.querySelectorAll("img.photo")).map((p) => p.src);
      const web = shown.filter((u) => /^https?:/i.test(u) && !removedWeb.has(u));
      const rec = { role: m._h.role, text: m._h.text || "" };
      const quote = m.querySelector(".quote");
      if (quote) { rec.quote = quote.querySelector(".quote-text").textContent; rec.qr = quote.dataset.qrole || "in"; }
      if (web.length) rec.images = web;
      if (m._pids && m._pids.length) rec.pids = m._pids;
      const lost = shown.length - web.length - (m._pids ? m._pids.length : 0);
      if (lost > 0) rec.pics = lost;
      if (m._raw != null) rec.md = 1;
      if (m._ci != null) rec.ci = m._ci;
      if (m._noRegen) rec.nr = 1;
      if (m._map) rec.map = m._map;
      out.push(rec);
    });
    return out;
  }

  function saveChat() {
    if (!settings.saveHistory) return;           // Settings > Data & Privacy: history off
    const msgs = snapshotMessages();
    const first = msgs.find((m) => m.role === "out");
    if (!first) return;
    if (!chatId) { chatId = newId("c"); chatTs = Date.now(); }

    const prev = chats.find((c) => c.id === chatId);
    const keepTitle = prev && (prev.custom || prev.ai);
    const title = keepTitle
      ? prev.title
      : (first.text || (first.pics || first.pids ? t("pics", first.pics || first.pids.length) : "")).replace(/\s+/g, " ").trim().slice(0, 60) || t("newChat");

    const rec = { id: chatId, title, ts: chatTs, updated: Date.now(), msgs: msgs.slice(-200), convo: convo.slice() };
    if (prev) { if (prev.pin) rec.pin = 1; if (prev.custom) rec.custom = 1; if (prev.ai) rec.ai = 1; }   // continuing a chat takes it out of the archive
    chats = [rec].concat(chats.filter((c) => c.id !== chatId));
    writeChats();
    renderChatList();
  }

  // Asks the AI for a short, fitting name once the first answer is in (never over a name the user chose)
  async function autoTitle(id) {
    if (!settings.aiTitles) return;              // Settings > Data & Privacy: AI names off
    const c = chats.find((x) => x.id === id);
    if (!c || c.custom || c.ai || chatId !== id || convo.length < 2) return;
    const clip = (v) => String(v || "").split("\n\n[Picture notes]")[0].replace(/^\(Replying to:[^\n]*\)\n/, "").slice(0, 500);
    try {
      const raw = await groq(GPT_KEY, {
        model: GPT_MODEL,
        messages: [
          { role: "system", content: "Write a short, specific title for this chat: 2 to 5 words, in the same language as the user's message. Reply with the title only, with no quotes, no markdown and no final punctuation." },
          { role: "user", content: "User: " + clip(convo[0].content) + "\n\nAssistant: " + clip(convo[1].content) }
        ],
        temperature: 0.3,
        max_completion_tokens: 1000,
        stream: false
      }, 30000);
      const title = raw.split("\n")[0].replace(/^["'“”«»\s#*_-]+|["'“”«»\s*_.:!؟?،,]+$/g, "").slice(0, 40).trim();
      const cur = chats.find((x) => x.id === id);
      if (title && cur && !cur.custom) { cur.title = title; cur.ai = 1; writeChats(); renderChatList(); }
    } catch (e) { console.error("[iMa! title]", e); }
  }

  function removeSaved(id) {
    trashChats([id]);
    renderChatList();
  }

  async function openSaved(id) {
    const c = chats.find((x) => x.id === id);
    if (!c || opening) return;
    if (busy) { showToast(t("chatBusy")); return; }
    closeDrawer();
    if (id === chatId) return;

    opening = true;
    try {
      const wanted = Array.from(new Set((c.msgs || []).flatMap((m) => m.pids || [])));
      const urls = await loadPicUrls(wanted);

      startChat(true);
      chatId = c.id;
      chatTs = c.ts || Date.now();
      convo = Array.isArray(c.convo) ? c.convo.slice() : [];
      const st = thread.querySelector(".stamp");
      if (st) { st.dataset.ts = String(chatTs); renderStamp(st); }

      (c.msgs || []).forEach((m) => {
        const mine = (m.pids || []).map((pid) => urls.get(pid)).filter(Boolean);
        const imgs = (Array.isArray(m.images) ? m.images : []).concat(mine);
        const msg = addMessage(m.role, {
          text: m.text || (m.pics ? t("pics", m.pics).trim() : ""),
          images: imgs,
          quote: m.quote || "",
          qrole: m.qr || "in",
          md: !!m.md || (m.role === "out" && !!m.text)
        });
        if (m.pids && m.pids.length) msg._pids = m.pids;
        if (m.ci != null) msg._ci = m.ci;
        if (m.nr) msg._noRegen = true;
        if (m.map) attachMap(msg, m.map);
        uploads.push(...imgs);
      });
      scrollToEnd(false);
    } finally {
      opening = false;
    }
  }

  const matches = (c, q) => (c.title || "").toLowerCase().includes(q) || (c.msgs || []).some((m) => (m.text || "").toLowerCase().includes(q));

  function renderChatList() {
    if (selMode) updateSelBar();
    const q = chatSearch.value.trim().toLowerCase();
    const all = q ? chats.filter((c) => matches(c, q)) : chats;
    const pinned   = all.filter((c) => c.pin && !c.arch);
    const recent   = all.filter((c) => !c.pin && !c.arch);
    const archived = all.filter((c) => c.arch);

    chatList.innerHTML = "";
    if (!all.length) {
      const e = el("div", "chat-empty");
      e.textContent = t(q ? "noResults" : "noChats");
      chatList.appendChild(e);
      return;
    }

    const label = (key, ico) => {
      const l = el("div", "chat-label");
      const im = el("img");
      im.src = icon(ico);
      im.alt = "";
      const sp = el("span");
      sp.textContent = t(key);
      l.append(im, sp);
      chatList.appendChild(l);
    };
    if (pinned.length) { label("pinned", "pin"); pinned.forEach(addChatItem); }
    if (recent.length) { label("recent", "recent"); recent.forEach(addChatItem); }
    if (archived.length) {
      const open = showArchived || !!q;
      const tg = el("button", "chat-label chat-toggle" + (open ? " open" : ""));
      tg.type = "button";
      tg.innerHTML = "<span></span>" + SVG_CHEV;
      tg.firstChild.textContent = t("archived") + " (" + archived.length + ")";
      tg.addEventListener("click", () => { showArchived = !showArchived; renderChatList(); });
      chatList.appendChild(tg);
      if (open) archived.forEach(addChatItem);
    }
  }

  function addChatItem(c) {
    const b = el("button", "chat-item" + (c.id === chatId ? " active" : ""));
    b.type = "button";
    b.dir = "auto";
    b.textContent = c.title || t("newChat");

    // select mode: a tap ticks / unticks the chat
    if (selMode) {
      b.classList.add("selectable");
      if (selSet.has(c.id)) b.classList.add("picked");
      b.setAttribute("aria-pressed", selSet.has(c.id) ? "true" : "false");
      b.addEventListener("click", () => {
        if (selSet.has(c.id)) selSet.delete(c.id); else selSet.add(c.id);
        b.classList.toggle("picked", selSet.has(c.id));
        b.setAttribute("aria-pressed", selSet.has(c.id) ? "true" : "false");
        updateSelBar();
      });
      chatList.appendChild(b);
      return;
    }

    // tap opens the chat; press and hold (or right-click) opens its menu
    let timer = null, fired = false, sx = 0, sy = 0;
    const stop = () => { clearTimeout(timer); timer = null; };
    const pop = () => {
      if (!menu.hidden && menuState && menuState.anchor === b) return;
      fired = true;
      openChatMenu(b, c.id);
    };
    b.addEventListener("pointerdown", (e) => { fired = false; sx = e.clientX; sy = e.clientY; timer = setTimeout(pop, 420); });
    b.addEventListener("pointermove", (e) => { if (timer && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) stop(); });
    ["pointerup", "pointerleave", "pointercancel"].forEach((ev) => b.addEventListener(ev, stop));
    b.addEventListener("contextmenu", (e) => { e.preventDefault(); stop(); pop(); });
    // one tap opens the chat (after a short wait), two quick taps show a preview of it
    let tapTimer = null;
    b.addEventListener("click", () => {
      if (fired) { fired = false; return; }
      if (tapTimer) { clearTimeout(tapTimer); tapTimer = null; openChatPreview(c.id); return; }
      tapTimer = setTimeout(() => { tapTimer = null; openSaved(c.id); }, 280);
    });
    chatList.appendChild(b);
  }

  function chatMenuItems(id, forPreview) {
    const c = chats.find((x) => x.id === id);
    if (!c) return [];
    const items = [];
    if (forPreview) items.push({ label: t("openShort"), icon: "open", action: () => openSaved(id) });
    if (!c.arch) items.push({ label: t(c.pin ? "unpin" : "pin"), icon: "label-pin", action: () => updateChat(id, (x) => { x.pin = x.pin ? 0 : 1; }) });
    items.push({ label: t("rename"), icon: "rename", action: () => openRename(id) });
    if (!forPreview) {
      items.push({ label: t("select"), icon: "select", action: () => enterSelect(id) });
      items.push({ label: t("chatInfo"), icon: "info", action: () => openChatInfo(id) });
      if (c.arch) items.push({ label: t("unarchive"), icon: "unarchive", action: () => updateChat(id, (x) => { x.arch = 0; }) });
    }
    items.push({ label: t("delete"), icon: "trash-red", danger: true, action: () => confirmDeleteSaved(id) });
    return items;
  }

  function openChatInfo(id) {
    const c = chats.find((x) => x.id === id);
    if (!c) return;
    const msgs = c.msgs || [];
    const mine = msgs.filter((m) => m.role === "out").length;
    const photos = msgs.reduce((n, m) => n + (m.images ? m.images.length : 0) + (m.pids ? m.pids.length : 0) + (m.pics || 0), 0);
    const when = (ts) => ts ? new Date(ts).toLocaleString(timeLocale(), { year: "numeric", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "\u2014";
    const rows = [
      [t("infoTitle"), c.title || "\u2014"],
      [t("infoCreated"), when(c.ts)],
      [t("infoUpdated"), when(c.updated)],
      [t("infoMessages"), String(msgs.length)],
      [t("infoYours"), String(mine)],
      [t("infoReplies"), String(msgs.length - mine)],
      [t("infoPhotos"), String(photos)],
      [t("infoStatus"), t(c.arch ? "infoArchived" : c.pin ? "infoPinned" : "infoNormal")]
    ];
    openSheet(t("chatInfo"), (box) => {
      const list = el("div", "info-list");
      rows.forEach(([k, v]) => {
        const row = el("div", "info-row");
        const a = el("span", "info-k"); a.textContent = k;
        const b = el("span", "info-v"); b.textContent = v; b.setAttribute("dir", "auto");
        row.append(a, b);
        list.appendChild(row);
      });
      box.appendChild(list);
    });
  }

  function openChatMenu(anchor, id) {
    const items = chatMenuItems(id);
    if (!items.length) return;
    openMenu(anchor, "down", items, true);
  }

  /* ---------- Chat preview (double-tap a chat name, iMessage style) ---------- */

  let cpv = null;

  function closeChatPreview() {
    if (!cpv) return;
    const c = cpv;
    cpv = null;
    c.classList.remove("open");
    setTimeout(() => c.remove(), 240);
  }

  function openChatPreview(id) {
    const c = chats.find((x) => x.id === id);
    if (!c || cpv) return;
    closeMenu();

    const layer = el("div", "cpv");
    const back = el("div", "cpv-back");
    back.addEventListener("click", closeChatPreview);

    const card = el("div", "cpv-card material");
    card.setAttribute("role", "button");
    card.setAttribute("aria-label", t("openChat") + ": " + (c.title || t("newChat")));
    const col = el("div", "cpv-thread");
    const recent = (c.msgs || []).slice(-8);
    recent.forEach((m, i) => {
      const same = i > 0 && recent[i - 1].role === m.role;
      const msg = el("div", "msg " + m.role + (same ? " same" : ""));
      const photos = (m.images ? m.images.length : 0) + (m.pids ? m.pids.length : 0) + (m.pics || 0);
      let txt = String(m.text || "").trim().slice(0, 700);
      if (!txt && photos) txt = t("attached");
      if (!txt) return;
      const bub = el("div", "bubble md");
      bub.innerHTML = renderMarkdown(txt);
      msg.appendChild(bub);
      col.appendChild(msg);
    });
    if (!col.children.length) { const e = el("div", "chat-empty"); e.textContent = t("noChats"); col.appendChild(e); }
    card.appendChild(col);
    card.addEventListener("click", () => { closeChatPreview(); openSaved(c.id); });

    const pm = el("div", "cpv-menu material");
    pm.setAttribute("role", "menu");
    chatMenuItems(id, true).forEach((it) => {
      const b = el("button", "menu-item" + (it.danger ? " danger" : ""));
      b.type = "button";
      b.setAttribute("role", "menuitem");
      const span = el("span");
      span.textContent = it.label;
      const img = el("img", "mi");
      img.src = icon(it.icon);
      img.alt = "";
      b.append(span, img);
      b.addEventListener("click", () => { closeChatPreview(); it.action(); });
      pm.appendChild(b);
    });

    const wrap = el("div", "cpv-wrap");
    wrap.append(card, pm);
    layer.append(back, wrap);
    app.appendChild(layer);
    // only bubbles that really are taller than the preview allows get the cut-off look
    col.querySelectorAll(".bubble").forEach((b) => { if (b.scrollHeight > b.clientHeight + 1) b.classList.add("clip"); });
    cpv = layer;
    requestAnimationFrame(() => layer.classList.add("open"));
    if (navigator.vibrate) { try { navigator.vibrate(12); } catch (e) {} }
  }

  function updateChat(id, fn) {
    const c = chats.find((x) => x.id === id);
    if (!c) return;
    fn(c);
    writeChats();
    renderChatList();
  }

  function openRename(id) {
    const c = chats.find((x) => x.id === id);
    if (!c) return;
    openSheet(t("renameChat"), (box) => {
      const r = el("div", "row row-text");
      const input = document.createElement("input");
      input.type = "text";
      input.className = "rename-input";
      input.maxLength = 60;
      input.dir = "auto";
      input.autocomplete = "off";
      input.value = c.title || "";
      input.placeholder = t("chatName");
      input.setAttribute("aria-label", t("chatName"));
      input.addEventListener("input", () => {
        const v = input.value.trim().slice(0, 60);
        if (v) updateChat(id, (x) => { x.title = v; x.custom = 1; });
      });
      r.appendChild(input);
      box.appendChild(group(r));
    });
  }

  function confirmDeleteSaved(id) {
    openAlert(t("deleteTitle"), t("deleteMsg"), [
      { label: t("cancel") },
      { label: t("delete"), danger: true, onClick: () => {
          const wasOpen = id === chatId;
          removeSaved(id);
          if (wasOpen) startChat();
          showToast(t("deleted"));
        } }
    ]);
  }

  function setSearching(on) {
    drawer.classList.toggle("searching", on);
    if (on) chatSearch.focus(); else { chatSearch.value = ""; chatSearch.blur(); }
    renderChatList();
  }

  /* ---------- Select chats: pick one, some or all, then delete ---------- */

  const selBar = el("div", "drawer-selbar");
  const selCancel = el("button"); selCancel.type = "button";
  const selAll = el("button");    selAll.type = "button";
  const selDel = el("button", "danger"); selDel.type = "button";
  selBar.append(selCancel, selAll, selDel);
  drawer.appendChild(selBar);

  // the chats currently listed (search + collapsed archive respected), so "all" never reaches hidden ones
  function visibleChatIds() {
    const q = chatSearch.value.trim().toLowerCase();
    const all = q ? chats.filter((c) => matches(c, q)) : chats;
    return all.filter((c) => !c.arch || showArchived || !!q).map((c) => c.id);
  }

  function updateSelBar() {
    const vis = visibleChatIds();
    Array.from(selSet).forEach((id) => { if (!vis.includes(id)) selSet.delete(id); });
    const n = selSet.size;
    selCancel.textContent = t("cancel");
    selAll.textContent = t(n && n === vis.length ? "deselectAll" : "selectAll");
    selAll.disabled = !vis.length;
    selDel.textContent = t("delN", n);
    selDel.disabled = !n;
  }

  function enterSelect(id) {
    selMode = true;
    selSet.clear();
    if (id) selSet.add(id);
    drawer.classList.add("selecting");
    renderChatList();
  }

  function exitSelect() {
    if (!selMode) return;
    selMode = false;
    selSet.clear();
    drawer.classList.remove("selecting");
    renderChatList();
  }

  function removeSavedMany(ids) {
    trashChats(ids);
  }

  function deleteSelectedChats() {
    const ids = Array.from(selSet);
    const n = ids.length;
    if (!n) return;
    openAlert(t("delChatsTitle", n), t(n === 1 ? "deleteMsg" : "delChatsMsg"), [
      { label: t("cancel") },
      { label: t("delete"), danger: true, onClick: () => {
          const wasOpen = ids.includes(chatId);
          removeSavedMany(ids);
          exitSelect();
          if (wasOpen) startChat();
          showToast(t("chatsDeleted", n));
        } }
    ]);
  }

  selCancel.addEventListener("click", exitSelect);
  selAll.addEventListener("click", () => {
    const vis = visibleChatIds();
    const everything = vis.length && vis.every((id) => selSet.has(id));
    selSet.clear();
    if (!everything) vis.forEach((id) => selSet.add(id));
    renderChatList();
  });
  selDel.addEventListener("click", deleteSelectedChats);

  // the search pill sits at the bottom: focusing it gives the chat list the room
  chatSearch.addEventListener("focus", () => drawer.classList.add("searching"));
  chatSearch.addEventListener("blur", () => {
    setTimeout(() => {
      if (!chatSearch.value.trim() && document.activeElement !== chatSearch) drawer.classList.remove("searching");
    }, 250);
  });
  chatSearch.addEventListener("input", renderChatList);
  chatSearch.addEventListener("keydown", (e) => { if (e.key === "Enter") chatSearch.blur(); });

  renderChatList();
  purgeTrash();                       // anything older than 30 days in the Trash is deleted for good

  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (cpv) { closeChatPreview(); return; }
    if (!modal.hidden) closeModal();
    else if (app.querySelector(".sp:not(.closing)")) closeSettings();
    else if (menuState) closeMenu();
    else closeDrawer();
  });


  /* ---------- Mobile keyboard: keep the composer above it ---------- */

  const vv = window.visualViewport;
  if (vv) {
    const fit = () => {
      app.style.height = vv.height + "px";
      window.scrollTo(0, 0);
      if (menuState) placeMenu();
    };
    vv.addEventListener("resize", fit);
    vv.addEventListener("scroll", fit);
    fit();
  }

  window.addEventListener("resize", () => { fitComposer(); if (menuState) placeMenu(); });
  if ("ResizeObserver" in window) new ResizeObserver(fitComposer).observe(composer);


  /* =========================================================
     MESSAGE MENU — long-press a message (iMessage style)
     blur + options
  ========================================================= */

  let ctx = null;

  // reads text from a message for select / expand
  function openTextSheet(title, text, { select = false, full = false, md = false } = {}) {
    openSheet(title, (box) => {
      if (full) box.classList.add("sheet--full");
      const body = el("div", "sheet-text" + (full ? " big" : ""));
      if (md) { body.classList.add("md"); body.innerHTML = renderMarkdown(text); }
      else body.textContent = text;
      body.setAttribute("dir", "auto");
      box.appendChild(body);
    });
  }

  // Replace with your real translation request. Resolve to the translated string.
  function getTranslation(text) {
    return Promise.resolve("");
  }

  async function regenerate(msg) {
    if (busy || msg._ci == null) return;
    const bubble = msg.querySelector(".bubble");
    if (!bubble) return;
    const before = msg._raw != null ? msg._raw : bubble.textContent;
    busy = true;
    syncSend();
    bubble.classList.add("typing");
    bubble.innerHTML = "<span></span><span></span><span></span>";
    const reply = await getReply({ text: "", images: [], regen: msg._ci, model, modes: { ...modes } });
    bubble.classList.remove("typing");
    if (reply.ok) {
      bubble.innerHTML = renderMarkdown(reply.text);
      msg._raw = reply.text;
      if (msg._h) msg._h.text = reply.text;
      saveChat();
    } else {
      bubble.innerHTML = renderMarkdown(before);
      showToast(reply.text);
    }
    busy = false;
    syncSend();
  }

  async function translateMsg(msg, text) {
    let out = "";
    try { out = await getTranslation(text); } catch (e) {}
    if (!out) { showToast(t("translateSoon")); return; }
    let tr = msg.querySelector(".translation");
    if (!tr) { tr = el("div", "translation"); msg.appendChild(tr); }
    tr.textContent = out;
  }

  function closeCtx() {
    if (!ctx) return;
    const c = ctx;
    ctx = null;
    c.layer.classList.remove("open");
    c.clone.style.top = c.y + "px";
    c.clone.style.height = c.h + "px";
    setTimeout(() => { c.msg.style.visibility = ""; c.layer.remove(); }, 260);
  }

  // Edit: your message goes back into the box; sending it replaces that message and everything after it
  function editMessage(msg) {
    if (busy) { showToast(t("chatBusy")); return; }
    const bubble = msg.querySelector(".bubble");
    const text = msg._raw != null ? msg._raw : (bubble ? bubble.textContent : "");
    if (!text) return;
    editing = msg;
    const q = msg.querySelector(".quote");
    replyTo = q ? { text: q.querySelector(".quote-text").textContent, role: q.dataset.qrole || "in" } : null;
    input.value = text;
    renderModes();
    growInput();
    syncSend();
    input.focus();
    try { input.setSelectionRange(text.length, text.length); } catch (e) {}
  }

  function cancelEdit() {
    editing = null;
    replyTo = null;
    input.value = "";
    renderModes();
    growInput();
    syncSend();
  }

  function commitEdit() {
    const msg = editing;
    editing = null;
    if (!msg || !msg.isConnected) { renderModes(); return; }
    const all = Array.from(thread.querySelectorAll(".msg"));
    const i = all.indexOf(msg);
    if (i < 0) { renderModes(); return; }
    const gone = all.slice(i);
    // cut what the AI remembers at this message
    const next = gone.find((m) => m._ci != null);
    if (next) {
      const cut = next._ci - 1;
      if (cut >= 0 && convo[cut] && convo[cut].role === "user") convo = convo.slice(0, cut);
    }
    gone.forEach((m) => {
      if (m._h) { const k = history.indexOf(m._h); if (k >= 0) history.splice(k, 1); }
      m.remove();
    });
    clearReceipt();
    const left = thread.querySelectorAll(".msg");
    lastMsg = left.length ? left[left.length - 1] : null;
  }

  function replyToMessage(msg) {
    const bubble = msg.querySelector(".bubble");
    const text = msg._raw != null ? msg._raw : (bubble ? bubble.textContent : "");
    replyTo = { text: (text || t("attached")).slice(0, 80), role: msg.classList.contains("out") ? "out" : "in" };
    renderModes();
    input.focus();
  }

  function openCtx(msg) {
    if (ctx || msg.querySelector(".typing")) return;

    const isOut = msg.classList.contains("out");
    const bubble = msg.querySelector(".bubble");
    const text = msg._raw != null ? msg._raw : (bubble ? bubble.textContent : "");
    const hasPhoto = !!msg.querySelector(".photo");

    const A = app.getBoundingClientRect();
    const r = msg.getBoundingClientRect();
    const W = A.width, H = A.height;
    // real size, not the on-screen size: the message is slightly squeezed while it is held
    let sc = 1;
    try { sc = new DOMMatrix(getComputedStyle(msg).transform).a || 1; } catch (e) {}
    const w = r.width / sc;
    const x = r.left - A.left - (w - r.width) / 2;
    let h = r.height / sc;
    const y = r.top - A.top - (h - r.height) / 2;

    // ----- options -----
    const items = [{ ico: "reply", label: t("reply"), run: () => replyToMessage(msg) }];
    if (isOut && text && !hasPhoto) items.push({ ico: "rename", label: t("edit"), run: () => editMessage(msg) });
    if (!isOut && text && !hasPhoto && !msg._noRegen) {
      items.push({ ico: "regenerate", label: t("regenerate"), run: () => regenerate(msg) });
    }
    if (text) {
      items.push({ ico: "select", label: t("select"), run: () => openTextSheet(t("select"), text, { select: true, full: true, md: msg._raw != null }) });
      items.push({ ico: "copy", label: t("copy"), run: () => {
        const done = () => showToast(t("msgCopied"));
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, done);
        else done();
      } });
    }

    // ----- layer -----
    const layer = el("div", "ctx");
    const back = el("div", "ctx-back");
    layer.appendChild(back);

    const clone = msg.cloneNode(true);
    clone.querySelectorAll(".receipt, .gpt-bar").forEach((n) => n.remove());
    clone.className = msg.className.replace(/\b(new|same)\b/g, "").replace(/\s+/g, " ") + " ctx-msg";
    clone.removeAttribute("style");
    clone.style.left = x + "px";
    clone.style.top = y + "px";
    clone.style.width = "max-content";                       // never narrower than its own text
    clone.style.setProperty("max-width", w + "px", "important");
    layer.appendChild(clone);

    const menu = el("div", "ctx-menu material");
    menu.setAttribute("role", "menu");
    items.forEach((it) => {
      if (it.sep) { menu.appendChild(el("div", "menu-sep")); return; }
      const b = el("button", "menu-item");
      b.type = "button";
      b.setAttribute("role", "menuitem");
      const span = el("span");
      span.textContent = it.label;
      const img = el("img", "mi mi-" + it.ico);
      img.src = icon(it.ico);
      img.alt = "";
      b.append(span, img);
      b.addEventListener("click", () => { closeCtx(); it.run(); });
      menu.appendChild(b);
    });
    layer.appendChild(menu);

    app.appendChild(layer);

    // ----- layout -----
    const GAP = 10, EDGE = 12, TOP = 56;
    const lift = Math.ceil(h * 0.015) + 4;        // the opened message grows a little, keep clear of it
    const MENU_W = Math.min(W - EDGE * 2, 190);
    const menuH = menu.offsetHeight;

    const maxH = H - TOP - EDGE - menuH - GAP * 2 - lift * 2;
    if (h > maxH) { h = Math.max(60, maxH); clone.style.height = h + "px"; clone.style.overflow = "hidden"; }
    clone.style.height = clone.style.height || r.height + "px";

    const total = GAP + lift + h + lift + GAP + menuH;
    const groupTop = Math.min(Math.max(y - GAP - lift, TOP), H - EDGE - total);
    const bubbleTop = groupTop + GAP + lift;

    const right = x + w / 2 > W / 2;
    const place = (node, width) => {
      let left = right ? x + w - width : x;
      left = Math.min(Math.max(left, EDGE), W - EDGE - width);
      node.style.left = left + "px";
      node.style.width = width + "px";
      node.style.transformOrigin = (right ? "100%" : "0%");
    };
    place(menu, MENU_W);
    menu.style.top = bubbleTop + h + lift + GAP + "px";
    menu.style.transformOrigin = (right ? "100% 0%" : "0% 0%");

    msg.style.visibility = "hidden";
    ctx = { layer, clone, msg, y, h: r.height / sc, t0: Date.now() };
    requestAnimationFrame(() => {
      layer.classList.add("open");
      clone.style.top = bubbleTop + "px";
    });

    back.addEventListener("click", () => { if (Date.now() - ctx.t0 > 350) closeCtx(); });
    if (navigator.vibrate) { try { navigator.vibrate(12); } catch (e) {} }
  }

  /* ---------- ChatGPT theme: action row under each iMa! reply (reply, copy, select, regenerate) ---------- */
  function addGptBar(msg) {
    if (msg._gpt || msg.querySelector(".typing")) return;
    const bubble = msg.querySelector(".bubble");
    if (!bubble || msg.querySelector(".photo")) return;
    msg._gpt = true;
    const text = () => (msg._raw != null ? msg._raw : bubble.textContent);
    const bar = el("div", "gpt-bar");
    const add = (ico, label, run) => {
      const b = el("button", "gpt-btn");
      b.type = "button";
      b.setAttribute("aria-label", label);
      const img = el("img");
      img.src = icon(ico); img.alt = ""; img.draggable = false;
      b.appendChild(img);
      b.addEventListener("click", (e) => { e.stopPropagation(); run(); });
      bar.appendChild(b);
    };
    add("copy", t("copy"), () => {
      const done = () => showToast(t("msgCopied"));
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text()).then(done, done);
      else done();
    });
    add("select", t("select"), () => openTextSheet(t("select"), text(), { select: true, full: true, md: msg._raw != null }));
    if (!msg._noRegen) add("regenerate", t("regenerate"), () => regenerate(msg));
    msg.appendChild(bar);
  }
  function scanGptBars() { thread.querySelectorAll(".msg.in").forEach(addGptBar); }
  new MutationObserver(scanGptBars).observe(thread, { childList: true });
  scanGptBars();

  // long-press detection
  (() => {
    let timer = null, hold = null, pressed = null, sx = 0, sy = 0;

    const cancel = () => {
      clearTimeout(timer);
      clearTimeout(hold);
      timer = hold = null;
      if (pressed) { pressed.classList.remove("pressing"); pressed = null; }
    };

    thread.addEventListener("pointerdown", (e) => {
      if (e.button > 0) return;
      const target = e.target.closest(".bubble:not(.typing), .photo");
      if (!target) return;
      const msg = target.closest(".msg");
      if (!msg) return;
      cancel();
      sx = e.clientX; sy = e.clientY;
      pressed = msg;
      // the squeeze only starts once the finger stays down, so a plain tap never twitches
      hold = setTimeout(() => { if (pressed === msg) msg.classList.add("pressing"); }, 130);
      timer = setTimeout(() => {
        const m = pressed;
        cancel();
        if (m) openCtx(m);
      }, 420);
    });

    thread.addEventListener("pointermove", (e) => {
      if (timer && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) cancel();
    });
    ["pointerup", "pointercancel", "pointerleave"].forEach((ev) => thread.addEventListener(ev, cancel));
    thread.addEventListener("scroll", cancel, { passive: true });

    // desktop right-click / native long-press menu
    thread.addEventListener("contextmenu", (e) => {
      const target = e.target.closest(".bubble:not(.typing), .photo");
      if (!target) return;
      e.preventDefault();
      cancel();
      const msg = target.closest(".msg");
      if (msg) openCtx(msg);
    });

    document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeCtx(); });
  })();


  /* ---------- Swipe a message sideways to reply ---------- */
  (() => {
    const THRESHOLD = 58, LIMIT = 96;
    let msg = null, badge = null, id = null, sx = 0, sy = 0, dir = 1, mode = "idle", armed = false, swiped = false;

    const finish = (reply) => {
      const m = msg, b = badge;
      if (m) {
        m.style.transition = "transform 0.3s cubic-bezier(0.2, 0.9, 0.3, 1)";
        m.style.transform = "";
        setTimeout(() => { if (m !== msg) { m.style.transition = ""; m.style.position = ""; } }, 340);
      }
      if (b) { b.style.opacity = "0"; setTimeout(() => b.remove(), 340); }
      msg = badge = null;
      mode = "idle";
      armed = false;
      if (reply && m) replyToMessage(m);
    };

    thread.addEventListener("pointerdown", (e) => {
      if (e.button > 0 || msg) return;
      if (e.target.closest(".gallery, .md-table, .code pre, .katex-display, .code-copy")) return;   // these scroll sideways themselves
      const m = e.target.closest(".msg");
      if (!m || m.querySelector(".typing") || m.classList.contains("ctx-msg")) return;
      msg = m; id = e.pointerId; sx = e.clientX; sy = e.clientY;
      dir = isRTL() ? -1 : 1;
      mode = "pending";
    });

    thread.addEventListener("pointermove", (e) => {
      if (!msg || e.pointerId !== id) return;
      const dx = (e.clientX - sx) * dir, dy = e.clientY - sy;

      if (mode === "pending") {
        if (Math.abs(dy) > 10 && Math.abs(dy) > Math.abs(dx)) { msg = null; mode = "idle"; return; }   // it is a scroll
        if (dx > 10 && dx > Math.abs(dy) * 1.2) {
          mode = "drag";
          try { thread.setPointerCapture(e.pointerId); } catch (err) {}
          const tr = thread.getBoundingClientRect(), mr = msg.getBoundingClientRect();
          const gap = dir > 0 ? mr.left - tr.left : tr.right - mr.right;
          msg.style.transition = "none";
          msg.style.position = "relative";
          badge = el("span", "swipe-reply");
          badge.style.insetInlineStart = (10 - gap) + "px";
          const im = document.createElement("img");
          im.src = icon("reply");
          im.alt = "";
          badge.appendChild(im);
          msg.insertBefore(badge, msg.firstChild);
        } else return;
      }

      const pull = Math.max(0, dx);
      const shown = Math.min(LIMIT, pull <= THRESHOLD ? pull : THRESHOLD + (pull - THRESHOLD) * 0.35);
      const p = Math.min(1, pull / THRESHOLD);
      msg.style.transform = "translateX(" + (shown * dir) + "px)";
      badge.style.opacity = String(p);
      badge.style.transform = "translate(" + (-shown * dir) + "px, -50%) scale(" + (0.6 + 0.4 * p) + ")";

      if (!armed && pull >= THRESHOLD) {
        armed = true;
        badge.classList.add("armed");
        if (navigator.vibrate) { try { navigator.vibrate(10); } catch (err) {} }
      } else if (armed && pull < THRESHOLD * 0.9) {
        armed = false;
        badge.classList.remove("armed");
      }
    });

    const end = (e, ok) => {
      if (!msg || e.pointerId !== id) return;
      if (mode === "drag") {
        swiped = true;
        setTimeout(() => { swiped = false; }, 350);
        finish(ok && armed);
      } else { msg = null; mode = "idle"; }
    };
    thread.addEventListener("pointerup", (e) => end(e, true));
    thread.addEventListener("pointercancel", (e) => end(e, false));
    // a swipe must not also count as a tap on a picture or link
    thread.addEventListener("click", (e) => { if (swiped) { e.stopPropagation(); e.preventDefault(); } }, true);
  })();


  /* ---------- Markdown for iMa!'s replies (own tiny renderer, HTML is always escaped) ---------- */

  const escHtml = (v) => String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  function mdInline(text) {
    const codes = [];
    const keep = [];
    let x = escHtml(text);
    x = x.replace(/`([^`\n]+)`/g, (_, c) => { codes.push(c); return "\u0001" + (codes.length - 1) + "\u0001"; });
    x = x.replace(/\\([\\`*_{}[\]()#+\-.!|~>])/g, (_, c) => { keep.push(c); return "\u0004" + (keep.length - 1) + "\u0004"; });
    x = x.replace(/&lt;br\s*\/?&gt;/gi, "<br>");
    x = x.replace(/!\[([^\]\n]*)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    x = x.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    x = x.replace(/(^|[\s(])(https?:\/\/[^\s<)]+[^\s<).,;:!?])/g, '$1<a href="$2" target="_blank" rel="noopener noreferrer">$2</a>');
    x = x.replace(/\*\*\*([^*\n]+?)\*\*\*/g, "<strong><em>$1</em></strong>");
    x = x.replace(/\*\*([^\n]+?)\*\*/g, "<strong>$1</strong>");
    x = x.replace(/(^|[^\w])__([^_\n]+?)__(?![\w])/g, "$1<strong>$2</strong>");
    x = x.replace(/(^|[^*\w])\*([^*\s][^*\n]*?)\*(?![*\w])/g, "$1<em>$2</em>");
    x = x.replace(/(^|[^_\w])_([^_\s][^_\n]*?)_(?![_\w])/g, "$1<em>$2</em>");
    x = x.replace(/~~([^~\n]+?)~~/g, "<del>$1</del>");
    x = x.replace(/\u0004(\d+)\u0004/g, (_, i) => keep[+i]);
    return x.replace(/\u0001(\d+)\u0001/g, (_, i) => "<code>" + codes[+i] + "</code>");
  }

  // which way a piece of text reads: first strong letter decides (Arabic / Hebrew = rtl)
  function mdDir(s) {
    const m = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]|[A-Za-z\u00C0-\u024F\u0370-\u03FF\u0400-\u04FF]/.exec(String(s || ""));
    if (!m) return isRTL() ? "rtl" : "ltr";
    return /[A-Za-z\u00C0-\u024F\u0370-\u03FF\u0400-\u04FF]/.test(m[0]) ? "ltr" : "rtl";
  }

  // which kind of web code a (resolved) language is: "html" | "css" | "js" | "" (not previewable)
  function webLang(l) {
    l = String(l || "").trim().toLowerCase();
    if (l === "html") return "html";
    if (l === "css") return "css";
    if (l === "javascript") return "js";
    return "";
  }

  const blockInfo = (b) => b._r || (b._r = resolveCode(b.lang, b.code));

  function mdCodeBlock(b, all) {
    const r = blockInfo(b);

    // not code (lyrics, a poem, a quote...): plain text, not a code box
    if (!r.lang && !r.mono) return '<div class="textblock" dir="auto">' + escHtml(b.code).replace(/\n/g, "<br>") + "</div>";

    const kind = webLang(r.lang);
    // HTML always can be previewed; CSS / JS only when the same message has a page to run them on
    const canRun = kind === "html" || (kind && (all || []).some((x) => webLang(blockInfo(x).lang) === "html"));
    const run = canRun
      ? '<button class="code-preview on" type="button" aria-label="' + escHtml(t("previewBtn")) + '">' + SVG_CODE_PLAY + '</button>'
      : "";
    return '<div class="code" data-kind="' + kind + '"><div class="code-bar">' +
      '<span class="code-actions"><span class="seg-thumb"></span>' + run +
      '<button class="code-copy' + (run ? "" : " on") + '" type="button" aria-label="' + escHtml(t("copy")) + '">' + SVG_CODE_COPY + SVG_CODE_CHECK + '</button></span>' +
      '<span class="code-lang">' + escHtml(r.label) + '</span></div>' +
      '<pre><code>' + (r.lang ? hlCode(r.lang, b.code) : escHtml(b.code)) + '</code></pre></div>';
  }

  // LaTeX -> HTML with KaTeX; if KaTeX is not available the formula stays readable as plain text
  function mdMath(tex, display) {
    try {
      if (window.katex) return window.katex.renderToString(tex, { displayMode: display, throwOnError: false, output: "html", strict: "ignore" });
    } catch (e) {}
    return '<span class="md-math-raw">' + escHtml((display ? "\\[" : "\\(") + tex + (display ? "\\]" : "\\)")) + "</span>";
  }

  function renderMarkdown(src) {
    const blocks = [];
    const maths = [];
    const text = String(src || "").replace(/[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, "").replace(/\r\n?/g, "\n").replace(/```([^\n`]*)\n([\s\S]*?)(?:```|$)/g, (_, lang, code) => {
      blocks.push({ lang: lang.trim().split(/\s+/)[0], code: code.replace(/\n$/, "") });
      return "\n\u0002" + (blocks.length - 1) + "\u0002\n";
    }).replace(/(`[^`\n]*`)|\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)/g, (all, code, d1, d2, i1) => {
      // LaTeX is pulled out before Markdown runs, so _ * | inside formulas stay untouched
      if (code) return all;
      const tex = String(d1 != null ? d1 : d2 != null ? d2 : i1).trim();
      if (!tex) return all;
      const display = i1 == null;
      maths.push({ tex, display });
      return "\u0003" + (display ? "d" : "i") + (maths.length - 1) + "\u0003";
    });

    const lines = text.split("\n");
    const out = [];
    let i = 0;

    const listRe  = /^(\s*)([-*+•◦▪]|[\d٠-٩]+[.)])\s+(.*)$/;
    const headRe  = /^\s{0,3}(#{1,6})[ \t]*(\S.*?)[ \t]*#*[ \t]*$/;
    const ruleRe  = /^\s*([-*_])(\s*\1){2,}\s*$/;
    const codeRe  = /^\u0002(\d+)\u0002$/;
    const mathLineRe = /^\s*\u0003d\d+\u0003\s*$/;
    const sepRe   = /^\s*\|?\s*:?[-–—]{2,}:?\s*(\|\s*:?[-–—]{2,}:?\s*)*\|?\s*$/;
    const cellsOf = (l) => l.trim().replace(/\\\|/g, "\u0005").replace(/^\||\|$/g, "").split("|").map((c) => c.trim().replace(/\u0005/g, "\\|"));
    const sepHeadRe = /^\s*\|\s*:?[-\u2013\u2014]{2,}:?\s*(\|\s*:?[-\u2013\u2014]{2,}:?\s*)*\|?/;
    const isTable = (k) => k + 1 < lines.length && lines[k].indexOf("|") >= 0 &&
      ((sepRe.test(lines[k + 1]) && lines[k + 1].indexOf("-") >= 0) || (lines[k + 1].indexOf("|") >= 0 && sepHeadRe.test(lines[k + 1])));
    const startsBlock = (k) => {
      const l = lines[k];
      return codeRe.test(l) || headRe.test(l) || ruleRe.test(l) || listRe.test(l) || /^\s*>/.test(l) || isTable(k);
    };

    function readList() {
      const items = [];
      while (i < lines.length) {
        const m = lines[i].match(listRe);
        if (!m) {
          // blank lines and displayed equations between two items keep the same list going
          let k = i;
          const extra = [];
          while (k < lines.length && (!lines[k].trim() || mathLineRe.test(lines[k]))) { if (lines[k].trim()) extra.push(lines[k].trim()); k++; }
          const next = items.length && k > i && k < lines.length ? lines[k].match(listRe) : null;
          if (next && (next[1].length > 0 || /[\d٠-٩]/.test(next[2]) === items[items.length - 1].ordered)) {
            extra.forEach((x) => { items[items.length - 1].text += "\n" + x; });
            i = k;
            continue;
          }
          if (items.length && /^\s{2,}\S/.test(lines[i]) && !codeRe.test(lines[i].trim())) { items[items.length - 1].text += "\n" + lines[i].trim(); i++; continue; }
          break;
        }
        items.push({ ind: m[1].replace(/\t/g, "    ").length, ordered: /[\d٠-٩]/.test(m[2]), num: parseInt(m[2].replace(/[٠-٩]/g, (d) => d.charCodeAt(0) - 1632), 10), text: m[3] });
        i++;
      }
      return items;
    }

    function buildList(items) {
      let html = "";
      const stack = [];
      items.forEach((it) => {
        while (stack.length && it.ind < stack[stack.length - 1].ind) html += "</li></" + stack.pop().tag + ">";
        const top = stack[stack.length - 1];
        if (!top || it.ind > top.ind) {
          const tag = it.ordered ? "ol" : "ul";
          html += "<" + tag + ' dir="' + mdDir(it.text) + '"' + (it.ordered && it.num > 1 ? ' start="' + it.num + '"' : "") + ">";
          stack.push({ ind: it.ind, tag });
        } else {
          html += "</li>";
        }
        const task = /^\[([ xX])\]\s+/.exec(it.text);
        html += '<li dir="auto">' + (task ? (task[1] === " " ? "\u2610 " : "\u2611 ") : "") + mdInline(task ? it.text.slice(task[0].length) : it.text).replace(/\n/g, "<br>");
      });
      while (stack.length) html += "</li></" + stack.pop().tag + ">";
      return html;
    }

    while (i < lines.length) {
      const line = lines[i];
      let m;
      if (!line.trim()) { i++; continue; }

      if ((m = line.match(codeRe))) { out.push(mdCodeBlock(blocks[+m[1]], blocks)); i++; continue; }

      if ((m = line.match(headRe))) {
        out.push('<div dir="auto" class="md-h md-h' + m[1].length + '">' + mdInline(m[2]) + "</div>");
        i++; continue;
      }

      if (ruleRe.test(line)) { out.push("<hr>"); i++; continue; }

      if (/^\s*>/.test(line)) {
        const q = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) { q.push(lines[i].replace(/^\s*>\s?/, "")); i++; }
        out.push('<blockquote dir="auto">' + q.map(mdInline).join("<br>") + "</blockquote>");
        continue;
      }

      if (isTable(i)) {
        const head = cellsOf(lines[i]);
        const sepLine = lines[i + 1];
        i += 2;

        // a separator line with a row glued to its end: keep the separator, the rest is the first row
        let glued = "";
        if (!sepRe.test(sepLine)) glued = sepLine.slice(sepLine.match(sepHeadRe)[0].length);

        const rawRows = [];
        // a row that does not close with "|" carries on over the next lines
        const readRow = (row, lead) => {
          while (!/\|\s*$/.test(row) && lead && i < lines.length && lines[i].trim() && !/^\s*\|/.test(lines[i]) && !codeRe.test(lines[i])) { row += "\n" + lines[i]; i++; }
          rawRows.push(row);
        };
        if (glued.trim()) readRow(glued, true);
        while (i < lines.length && lines[i].trim() && !codeRe.test(lines[i])) {
          const row = lines[i];
          if (row.indexOf("|") < 0) break;
          i++;
          readRow(row, /^\s*\|/.test(row));
        }

        const blank = (c) => (/^[.\s]*BLANK\]?\s*$/i.test(c) ? "" : c);
        let rows = rawRows.map((r) => {
          const cs = cellsOf(r.replace(/\n/g, "\u0006")).map(blank);
          while (cs.length < head.length) cs.push("");
          return cs;
        });

        // "first column empty + second column holds '• **Name** – text' items" = one row per item
        const split = [];
        rows.forEach((r) => {
          if (r.length === head.length && r[0] === "" && r[1]) {
            const parts = r[1].replace(/\u0006|<br\s*\/?>/gi, "\n").split(/\n\s*(?=\u2022\s*\*\*)/).map((p) => p.trim()).filter(Boolean);
            const items = parts.map((p) => /^\u2022\s*\*\*(.+?)\*\*\s*[\u2013\u2014-]\s*([\s\S]*)$/.exec(p));
            if (parts.length && items.every(Boolean)) {
              items.forEach((m) => { const row = r.slice(); row[0] = m[1]; row[1] = m[2].trim(); split.push(row); });
              return;
            }
          }
          split.push(r);
        });
        rows = split;

        // cell text: line breaks, "• item" lines and "- sub item" lines
        const cell = (c) => {
          const ls = c.replace(/\u0006/g, "\n").replace(/<br\s*\/?>/gi, "\n").split("\n").filter((l) => l.trim());
          if (ls.length === 1 && !/^\s*[-\u2022*]\s+/.test(ls[0])) return mdInline(ls[0].trim());
          return ls.map((l) => {
            const m = /^(\s*)([-\u2022*])\s+(.*)$/.exec(l);
            return m
              ? '<span dir="auto" class="md-cl li' + (m[1].length >= 2 ? " sub" : "") + '">' + mdInline(m[3]) + "</span>"
              : '<span dir="auto" class="md-cl">' + mdInline(l.trim()) + "</span>";
          }).join("");
        };
        out.push('<div class="md-table"><table dir="auto"><thead><tr>' + head.map((c) => "<th>" + cell(c) + "</th>").join("") + "</tr></thead><tbody>" +
          rows.map((r) => "<tr>" + r.map((c) => "<td>" + cell(c) + "</td>").join("") + "</tr>").join("") + "</tbody></table></div>");
        continue;
      }

      if (listRe.test(line)) { out.push(buildList(readList())); continue; }

      const para = [];
      while (i < lines.length && lines[i].trim() && !(para.length && startsBlock(i))) { para.push(lines[i]); i++; }
      out.push('<p dir="auto">' + para.map(mdInline).join("<br>") + "</p>");
    }

    return out.join("").replace(/(<br>)?\u0003([di])(\d+)\u0003(<br>)?/g, (all, b1, kind, n, b2) => {
      const m = maths[+n];
      const html = mdMath(m.tex, m.display);
      return m.display ? html : (b1 || "") + html + (b2 || "");
    });
  }

  /* ---------- Copy a code block / open a picture full screen ---------- */

  function copyText(value, done) {
    const fallback = () => {
      try {
        const ta = document.createElement("textarea");
        ta.value = value;
        ta.style.cssText = "position:fixed;opacity:0;top:0;left:0";
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        ta.remove();
      } catch (e) {}
      done();
    };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(value).then(done, fallback);
    else fallback();
  }

  function openViewer(src) {
    if (!src || app.querySelector(".viewer")) return;
    const v = el("div", "viewer");
    const img = document.createElement("img");
    img.src = src;
    img.alt = "";
    img.referrerPolicy = "no-referrer";
    const done = el("button", "viewer-done");
    done.type = "button";
    done.textContent = t("done");
    const onKey = (e) => { if (e.key === "Escape") close(); };
    const close = () => { v.remove(); document.removeEventListener("keydown", onKey); };
    v.addEventListener("click", close);
    document.addEventListener("keydown", onKey);
    v.append(img, done);
    app.appendChild(v);
  }

  /* "Preview" beside a code block's language: run that code in the Code preview page */
  const SVG_CODE_PLAY = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 4.8v14.4a.8.8 0 0 0 1.2.7l11.4-7.2a.8.8 0 0 0 0-1.4L8.2 4.1A.8.8 0 0 0 7 4.8z"/></svg>';
  const SVG_CODE_COPY = '<svg class="ic ic-copy" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="8.5" y="8.5" width="11.5" height="11.5" rx="3"/><path d="M15.5 8.5V7a3 3 0 0 0-3-3H7a3 3 0 0 0-3 3v5.5a3 3 0 0 0 3 3h1.5"/></svg>';
  const SVG_CODE_CHECK = '<svg class="ic ic-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

  // the Preview / Copy pill: a white thumb slides to the tapped button, then back
  function codeSlide(btn, back) {
    const seg = btn.closest(".code-actions");
    if (!seg) return;
    const btns = Array.from(seg.querySelectorAll("button"));
    btns.forEach((b) => b.classList.toggle("on", b === btn));
    seg.style.setProperty("--i", String(btns.indexOf(btn)));
    clearTimeout(seg._t);
    seg._t = setTimeout(() => {
      btn.classList.remove("done");
      btns.forEach((b, i) => b.classList.toggle("on", i === 0));
      seg.style.setProperty("--i", "0");
    }, back);
  }

  app.addEventListener("click", (e) => {
    const pv = e.target.closest(".code-preview");
    if (!pv) return;
    const box = pv.closest(".code");
    const kind = box.dataset.kind;
    if (!kind) return;
    codeSlide(pv, 700);
    const scope = box.closest(".bubble, .sheet-text") || box.parentNode;
    const blocks = Array.from(scope.querySelectorAll(".code"))
      .map((b) => ({ el: b, kind: b.dataset.kind, code: b.querySelector("code").textContent }))
      .filter((b) => b.kind);
    const page = kind === "html" ? blocks.find((b) => b.el === box) : blocks.find((b) => b.kind === "html");
    if (!page) { showToast(t("nothingToRun")); return; }
    const hasStyle  = /<style[\s>]/i.test(page.code);
    const hasScript = /<script(?![^>]*\bsrc\b)[^>]*>\s*\S/i.test(page.code);
    const join = (k) => blocks.filter((b) => b.kind === k).map((b) => b.code).join("\n\n");
    const css = hasStyle  ? "" : join("css");
    const js  = hasScript ? "" : join("js");
    if (css || js) { cpMode = "sep"; cpParts = { html: page.code, css, js, py: "" }; cpLang = "html"; }
    else { cpMode = "one"; cpCode = page.code; }
    if (!modal.hidden) closeModal();
    openCodePreview({ run: true });
  });

  app.addEventListener("click", (e) => {
    const btn = e.target.closest(".code-copy");
    if (!btn) return;
    const code = btn.closest(".code").querySelector("code").textContent;
    copyText(code, () => {
      btn.classList.add("done");
      codeSlide(btn, 1300);
    });
  });

  thread.addEventListener("click", (e) => {
    const photo = e.target.closest(".photo");
    if (photo && !ctx) openViewer(photo.src);
  });


  /* ---------- Start ---------- */
  applyTheme();
  applyLang();
  applyBackground();
  startChat();

  // bring back the saved background picture
  photoDB.get().then((blob) => {
    if (blob) { setPhotoUrl(blob); applyBackground(); refreshSettings(); }
    else if (settings.bg === "photo") { settings.bg = "color"; saveSettings(); applyBackground(); }
  });
  // bring back the saved background video
  videoDB.get().then((blob) => {
    if (blob) { setVideoUrl(blob); applyBackground(); refreshSettings(); }
    else if (settings.bg === "video") { settings.bg = "color"; saveSettings(); applyBackground(); }
  });

  /* =========================================================
     MUSIC (iTunes search + 30s previews) — tiny player in the island
  ========================================================= */
  (() => {
    const input = $("musicSearch"), list = $("mpList"), box = $("musicPlayer");
    if (!input || !list || !box) return;
    const title = $("mpTitle"), artist = $("mpArtist");
    const toggle = $("mpToggle"), prevBtn = $("mpPrev"), nextBtn = $("mpNext"), fill = $("mpFill");
    // now-playing card (opens when a song is tapped)
    const npArt = $("npArt"), npTitle = $("npTitle"), npArtist = $("npArtist"), npToggle = $("npToggle"), npPrev = $("npPrev"), npNext = $("npNext");
    const npFill = $("npFill"), npCur = $("npCur"), npLeft = $("npLeft"), npTrack = $("npTrack");
    const fmt = (x) => { x = Math.max(0, Math.floor(x || 0)); return Math.floor(x / 60) + ":" + String(x % 60).padStart(2, "0"); };
    // long title / artist: scroll back and forth instead of "…"
    function mq(el) {
      const inner = el.firstElementChild, over = inner.scrollWidth - el.clientWidth;
      if (over > 2) {
        inner.style.setProperty("--mq", -(over + 4) + "px");
        inner.style.setProperty("--mq-t", Math.max(4, Math.round(over / 18 + 3)) + "s");
        el.classList.add("mq");
      } else { el.classList.remove("mq"); inner.style.removeProperty("--mq"); }
    }
    const checkMq = () => { mq(npTitle); mq(npArtist); };
    if (window.ResizeObserver) new ResizeObserver(checkMq).observe(npTitle.parentElement);
    const setMode = (m) => { box.dataset.mode = m; if (window.imaSize) window.imaSize(); };   // the island resizes with the mode
    window.imaMusicMode = () => box.dataset.mode;
    box.dataset.mode = "list";
    window.imaMusicBack = () => { if (box.dataset.mode === "now") { setMode("list"); return true; } return false; };
    // tint the artist line with the artwork's colour (needs CORS on the artwork; silently skipped otherwise)
    function tint(url) {
      box.style.removeProperty("--np-tint");
      if (!url) return;
      const im = new Image(); im.crossOrigin = "anonymous";
      im.onload = () => {
        try {
          const c = document.createElement("canvas"); c.width = c.height = 8;
          const x = c.getContext("2d"); x.drawImage(im, 0, 0, 8, 8);
          const d = x.getImageData(0, 0, 8, 8).data; let r = 0, g = 0, b = 0, n = 0;
          for (let i = 0; i < d.length; i += 4) { r += d[i]; g += d[i + 1]; b += d[i + 2]; n++; }
          const m = (v) => Math.round(v / n * 0.55 + 255 * 0.45);   // lighten so it reads on glass
          box.style.setProperty("--np-tint", "rgb(" + m(r) + "," + m(g) + "," + m(b) + ")");
        } catch (_) { /* tainted canvas */ }
      };
      im.src = url;
    }
    const audio = new Audio();
    audio.preload = "auto";
    let tracks = [], queue = [], current = null, note = "", reqId = 0;
    // two sources: "itunes" (30s previews) and "local" (songs picked from this phone, kept in IndexedDB)
    const seg = $("mpSeg"), fileIn = $("mpFile");
    let src = "itunes";
    try { if (localStorage.getItem("ima.musicSrc") === "local") src = "local"; } catch (_) { /* private mode */ }
    let itTracks = [], itNote = "", itQuery = "", localAll = [];
    const DEF_ART = "assets/icons/app-music.png";

    const map = (s) => {
      if (!s || !s.trackId || !s.previewUrl) return null;
      return {
        id: String(s.trackId), title: s.trackName || "", artist: s.artistName || "",
        art: (s.artworkUrl100 || "").replace("100x100bb", "200x200bb"), big: (s.artworkUrl100 || "").replace("100x100bb", "400x400bb"), url: s.previewUrl,
      };
    };
    const getJSON = async (url) => {
      const r = await fetch(url);
      if (!r.ok) throw new Error("net");
      return r.json();
    };
    const searchSongs = async (q) => {
      const d = await getJSON("https://itunes.apple.com/search?term=" + encodeURIComponent(q) + "&media=music&entity=song&limit=20");
      return (d.results || []).map(map).filter(Boolean);
    };
    // "available music": Apple's top songs chart, falling back to a plain search if the chart is unreachable
    const topSongs = async () => {
      try {
        const rss = await getJSON("https://itunes.apple.com/us/rss/topsongs/limit=16/explicit=false/json");
        const e = rss.feed && rss.feed.entry;
        const ids = (Array.isArray(e) ? e : e ? [e] : []).map((x) => x.id && x.id.attributes && x.id.attributes["im:id"]).filter(Boolean);
        if (ids.length) {
          const d = await getJSON("https://itunes.apple.com/lookup?id=" + ids.join(","));
          const out = (d.results || []).map(map).filter(Boolean);
          if (out.length) return out;
        }
      } catch (_) { /* fall through */ }
      return searchSongs("top hits");
    };

    /* ---- local songs: IndexedDB store + light ID3 tag reader ---- */
    const idb = {
      open: () => new Promise((res, rej) => {
        const r = indexedDB.open("ima-music", 1);
        r.onupgradeneeded = () => r.result.createObjectStore("songs", { keyPath: "id" });
        r.onsuccess = () => res(r.result);
        r.onerror = () => rej(r.error);
      }),
      async run(mode, fn) {
        const d = await this.open();
        return new Promise((res, rej) => {
          const tx = d.transaction("songs", mode), q = fn(tx.objectStore("songs"));
          tx.oncomplete = () => { d.close(); res(q && q.result); };
          tx.onerror = tx.onabort = () => { d.close(); rej(tx.error); };
        });
      },
      all() { return this.run("readonly", (s) => s.getAll()); },
      put(rec) { return this.run("readwrite", (s) => s.put(rec)); },
      del(id) { return this.run("readwrite", (s) => s.delete(id)); },
    };
    const decode = (bytes, enc) => {
      try {
        if (enc === 1) { const le = bytes[0] === 0xFF && bytes[1] === 0xFE; return new TextDecoder(le ? "utf-16le" : "utf-16be").decode(bytes.subarray(2)); }
        return new TextDecoder(enc === 2 ? "utf-16be" : enc === 3 ? "utf-8" : "windows-1252").decode(bytes);
      } catch (_) { return ""; }
    };
    const clean = (s) => String(s || "").replace(/\u0000/g, "").trim();
    async function readTags(file) {
      const out = {};
      try {
        const head = new Uint8Array(await file.slice(0, 10).arrayBuffer());
        if (head[0] !== 0x49 || head[1] !== 0x44 || head[2] !== 0x33) return out;   // "ID3"
        const ver = head[3], total = ((head[6] & 127) << 21) | ((head[7] & 127) << 14) | ((head[8] & 127) << 7) | (head[9] & 127);
        if (ver < 3) return out;
        const u = new Uint8Array(await file.slice(10, 10 + Math.min(total, 8 * 1024 * 1024)).arrayBuffer());
        const dv = new DataView(u.buffer);
        let p = 0;
        while (p + 10 <= u.length) {
          const id = String.fromCharCode(u[p], u[p + 1], u[p + 2], u[p + 3]);
          if (!/^[A-Z0-9]{4}$/.test(id)) break;
          const size = ver === 4 ? ((u[p + 4] & 127) << 21) | ((u[p + 5] & 127) << 14) | ((u[p + 6] & 127) << 7) | (u[p + 7] & 127) : dv.getUint32(p + 4);
          const body = u.subarray(p + 10, p + 10 + size);
          if (size <= 0 || p + 10 + size > u.length) break;
          if (id === "TIT2") out.title = clean(decode(body.subarray(1), body[0]));
          else if (id === "TPE1") out.artist = clean(decode(body.subarray(1), body[0]));
          else if (id === "APIC" && !out.art) {
            const enc = body[0]; let i = 1;
            let mime = ""; while (i < body.length && body[i] !== 0) mime += String.fromCharCode(body[i++]);
            i += 2;                                                   // null + picture type
            if (enc === 1 || enc === 2) { while (i + 1 < body.length && !(body[i] === 0 && body[i + 1] === 0)) i += 2; i += 2; }
            else { while (i < body.length && body[i] !== 0) i++; i++; }
            const img = body.subarray(i);
            if (img.length > 100) out.art = new Blob([img], { type: /^image\//.test(mime) ? mime : (img[0] === 0x89 ? "image/png" : "image/jpeg") });
          }
          p += 10 + size;
        }
      } catch (_) { /* keep whatever was read */ }
      return out;
    }
    const nameTags = (file) => {
      let n = file.name.replace(/\.[^.]+$/, "").replace(/_/g, " ").trim(), a = "";
      const m = n.match(/^(.+?)\s+-\s+(.+)$/);
      if (m) { a = m[1]; n = m[2]; }
      return { title: n, artist: a };
    };
    const mkLocal = (r) => {
      const art = r.art ? URL.createObjectURL(r.art) : DEF_ART;
      return { id: "l" + r.id, rid: r.id, title: r.title, artist: r.artist, art, big: art, url: URL.createObjectURL(r.blob), local: true, added: r.added };
    };
    const freeLocal = (tr) => { try { URL.revokeObjectURL(tr.url); if (tr.art !== DEF_ART) URL.revokeObjectURL(tr.art); } catch (_) { /* ignore */ } };
    async function loadLocalDb() {
      try {
        const recs = (await idb.all()) || [];
        localAll.forEach(freeLocal);
        localAll = recs.sort((a, b) => b.added - a.added).map(mkLocal);
      } catch (_) { localAll = []; }
    }
    function showLocal() {
      const q = input.value.trim().toLowerCase();
      tracks = q ? localAll.filter((x) => (x.title + " " + x.artist).toLowerCase().includes(q)) : localAll.slice();
      note = localAll.length ? t("mpNone") : t("mpLocalNone");
      renderList();
    }
    const syncPlaceholder = () => {
      if (!window.imaView || window.imaView() !== "music") return;
      input.placeholder = src === "local" ? t("mpSearchLocal") : t("musicSearch");
      input.setAttribute("aria-label", input.placeholder);
    };
    window.imaMusicShow = (on) => { if (on) syncPlaceholder(); };
    function setSrc(s) {
      if (s === src) return;
      if (src === "itunes") itQuery = input.value; 
      src = s; box.dataset.src = s;
      try { localStorage.setItem("ima.musicSrc", s); } catch (_) { /* ignore */ }
      seg.querySelectorAll("button").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.src === s)));
      reqId++;                                    // drop any iTunes request still in flight
      setMode("list");
      input.value = s === "local" ? "" : itQuery;
      syncPlaceholder();
      if (s === "local") showLocal();
      else if (itTracks.length) { tracks = itTracks; note = itNote; renderList(); }
      else load(itQuery.trim());
    }
    async function addFiles(files) {
      const ok = files.filter((f) => /^audio\//.test(f.type) || /\.(mp3|m4a|aac|wav|flac|ogg|oga|opus|weba)$/i.test(f.name));
      if (!ok.length) return;
      tracks = []; note = t("mpLoading"); renderList();
      let failed = false;
      for (let i = 0; i < ok.length; i++) {
        const f = ok[i];
        if (localAll.some((x) => x.size === f.size && x.fname === f.name)) continue;   // already added
        try {
          const tg = await readTags(f), nm = nameTags(f);
          await idb.put({
            id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7), fname: f.name, size: f.size,
            title: tg.title || nm.title, artist: tg.artist || nm.artist, art: tg.art || null, blob: f, added: Date.now() + i,
          });
        } catch (_) { failed = true; }
      }
      await loadLocalDb();
      if (src === "local") { showLocal(); if (failed) { tracks = []; note = t("mpLocalFail"); if (!localAll.length) renderList(); } }
    }
    async function removeLocal(rid) {
      const tr = localAll.find((x) => x.rid === rid);
      if (!tr) return;
      try { await idb.del(rid); } catch (_) { return; }
      if (current && current.id === tr.id) {
        audio.pause(); audio.removeAttribute("src"); audio.load();
        current = null; fill.style.width = "0"; npFill.style.width = "0"; renderNow();
      }
      localAll = localAll.filter((x) => x !== tr);
      queue = queue.filter((x) => x !== tr);
      freeLocal(tr);
      if (src === "local") showLocal();
    }

    function renderNow() {
      const on = !!current;
      title.textContent = on ? current.title : t("mpPick");
      artist.textContent = on ? current.artist : "";
      toggle.disabled = prevBtn.disabled = nextBtn.disabled = !on;
      npTitle.firstElementChild.textContent = on ? current.title : "";
      npArtist.firstElementChild.textContent = on ? current.artist : "";
      if (on && npArt.getAttribute("src") !== current.big) { npArt.src = current.big; tint(current.art); }
      requestAnimationFrame(checkMq);
    }
    function renderList() {
      list.textContent = "";
      if (src === "local") {
        const a = document.createElement("button");
        a.type = "button"; a.className = "mp-add"; a.dataset.add = "1";
        const ic = document.createElement("span"); ic.className = "add-ico"; ic.appendChild(document.createElement("i"));
        const lb = document.createElement("b"); lb.textContent = t("mpAdd");
        a.append(ic, lb);
        list.appendChild(a);
      }
      if (!tracks.length) {
        const p = document.createElement("div");
        p.className = "mp-note";
        p.textContent = note;
        list.appendChild(p);
        return;
      }
      tracks.forEach((tr) => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "mp-item" + (current && current.id === tr.id ? " on" : "");
        b.setAttribute("role", "listitem");
        b.dataset.id = tr.id;
        b.title = tr.title + " — " + tr.artist;
        b.setAttribute("aria-label", b.title);
        const im = document.createElement("img");
        im.alt = ""; im.loading = "lazy"; im.src = tr.art;
        const tx = document.createElement("span"); tx.className = "li-txt";
        const t1 = document.createElement("b"); t1.textContent = tr.title;
        const t2 = document.createElement("span"); t2.textContent = tr.artist || "";
        tx.append(t1, t2);
        b.append(im, tx);
        if (tr.local) {
          const row = document.createElement("div"); row.className = "mp-row";
          const x = document.createElement("button");
          x.type = "button"; x.className = "mp-del"; x.dataset.rid = tr.rid;
          x.setAttribute("aria-label", t("mpRemove") + ": " + tr.title);
          x.appendChild(document.createElement("i"));
          row.append(b, x);
          list.appendChild(row);
        } else list.appendChild(b);
      });
    }
    function play(tr) {
      current = tr;
      audio.src = tr.url;
      audio.play().catch(() => {});
      renderNow();
      setMode("now");
      list.querySelectorAll(".mp-item").forEach((x) => x.classList.toggle("on", x.dataset.id === tr.id));
    }
    async function load(q) {
      const my = ++reqId;
      setMode("list");
      tracks = itTracks = []; note = itNote = t("mpLoading"); renderList();
      try {
        const out = q ? await searchSongs(q) : await topSongs();
        if (my !== reqId) return;
        tracks = itTracks = out; note = itNote = out.length ? "" : t("mpNone");
      } catch (_) {
        if (my !== reqId) return;
        tracks = itTracks = []; note = itNote = t("mpOffline");
      }
      renderList();
      list.scrollLeft = 0;
    }

    list.addEventListener("click", (e) => {
      if (e.target.closest(".mp-add")) { fileIn.click(); return; }
      const del = e.target.closest(".mp-del");
      if (del) { removeLocal(del.dataset.rid); return; }
      const b = e.target.closest(".mp-item");
      const tr = b && tracks.find((x) => x.id === b.dataset.id);
      if (!tr) return;
      if (current && current.id === tr.id) { setMode("now"); return; }   // the playing song just reopens the card
      queue = tracks;
      play(tr);
    });
    fileIn.addEventListener("change", () => { const fs = Array.from(fileIn.files || []); fileIn.value = ""; addFiles(fs); });
    seg.addEventListener("click", (e) => { const b = e.target.closest("button[data-src]"); if (b) setSrc(b.dataset.src); });
    const step = (d) => {
      const i = queue.findIndex((x) => current && x.id === current.id);
      if (i < 0) return;
      if (d < 0 && audio.currentTime > 3) { audio.currentTime = 0; return; }   // like Apple Music: restart first, then go back
      const tr = queue[i + d];
      if (tr) play(tr); else { audio.currentTime = 0; }
    };
    prevBtn.addEventListener("click", () => step(-1));
    nextBtn.addEventListener("click", () => step(1));
    const flip = () => {
      if (!current) return;
      if (audio.paused) audio.play().catch(() => {}); else audio.pause();
    };
    toggle.addEventListener("click", flip);
    npToggle.addEventListener("click", flip);
    npPrev.addEventListener("click", () => step(-1));
    npNext.addEventListener("click", () => step(1));
    npTrack.addEventListener("click", (e) => {
      if (!audio.duration) return;
      const r = npTrack.getBoundingClientRect(), f = (e.clientX - r.left) / r.width;
      audio.currentTime = audio.duration * Math.min(1, Math.max(0, document.documentElement.dir === "rtl" ? 1 - f : f));
    });
    input.addEventListener("keydown", (e) => {
      if (e.key !== "Enter") return;
      if (window.imaView && /^(yt|map|wx|web|news)$/.test(window.imaView())) return;   // YouTube / Map own the search bar
      e.preventDefault();
      if (src === "local") showLocal(); else load(input.value.trim());
      input.blur();
    });
    input.addEventListener("input", () => { if (src === "local" && window.imaView && window.imaView() === "music") showLocal(); });   // local songs filter as you type
    input.addEventListener("search", () => { if (!input.value && !(window.imaView && /^(yt|map|wx|web|news)$/.test(window.imaView()))) { if (src === "local") showLocal(); else load(""); } });  // clear (x) → back to top songs
    audio.addEventListener("play", () => { box.classList.add("playing"); toggle.setAttribute("aria-label", "Pause"); npToggle.setAttribute("aria-label", "Pause"); });
    audio.addEventListener("pause", () => { box.classList.remove("playing"); toggle.setAttribute("aria-label", "Play"); npToggle.setAttribute("aria-label", "Play"); });
    audio.addEventListener("ended", () => {
      const i = queue.findIndex((x) => current && x.id === current.id);
      if (i >= 0 && i < queue.length - 1) play(queue[i + 1]); else { fill.style.width = "0"; npFill.style.width = "0"; }
    });
    audio.addEventListener("timeupdate", () => {
      const pct = audio.duration ? (audio.currentTime / audio.duration) * 100 + "%" : "0";
      fill.style.width = pct; npFill.style.width = pct;
      npCur.textContent = fmt(audio.currentTime);
      npLeft.textContent = "-" + fmt(audio.duration ? audio.duration - audio.currentTime : 0);
    });

    // language switch: refresh the texts that are not static markup
    window.imaMusicRefresh = () => { if (!current) renderNow(); syncPlaceholder(); if (src === "local") showLocal(); };
    renderNow();
    box.dataset.src = src;
    seg.querySelectorAll("button").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.src === src)));
    if (src === "local") { loadLocalDb().then(showLocal); } else { load(""); loadLocalDb(); }
  })();

  /* =========================================================
     TRANSLATE CHAT (Groq) — right half of the island.
     Only the tools use this key; the chat itself is untouched.
  ========================================================= */
  (() => {
    const sel = $("trLang"), btn = $("trBtn");
    if (!sel || !btn) return;
    const CFG = window.IMA_CONFIG || {};
    const LANGS = [
      ["ar", "Arabic", "العربية"], ["en", "English", "English"], ["es", "Spanish", "Español"], ["fr", "French", "Français"],
      ["de", "German", "Deutsch"], ["it", "Italian", "Italiano"], ["pt", "Portuguese", "Português"], ["tr", "Turkish", "Türkçe"],
      ["ru", "Russian", "Русский"], ["fa", "Persian", "فارسی"], ["ur", "Urdu", "اردو"], ["hi", "Hindi", "हिन्दी"],
      ["zh", "Chinese", "中文"], ["ja", "Japanese", "日本語"], ["ko", "Korean", "한국어"], ["id", "Indonesian", "Bahasa Indonesia"],
    ];
    LANGS.forEach(([code, , native]) => { const o = document.createElement("option"); o.value = code; o.textContent = native; sel.appendChild(o); });
    let saved = "";
    try { saved = localStorage.getItem("ima-trlang") || ""; } catch (_) {}
    sel.value = LANGS.some((l) => l[0] === saved) ? saved : (settings.lang === "ar" ? "en" : "ar");

    /* custom language picker: a pill + a glass grid inside the island (replaces the browser's own dropdown) */
    const selBtn = $("trSel"), selName = $("trSelName"), menu = $("trMenu");
    const tools = menu.parentElement;
    const setMenu = (on) => {
      menu.classList.toggle("open", on); tools.classList.toggle("pick", on); selBtn.setAttribute("aria-expanded", String(on));
      window.imaTrPick = on; if (window.imaSize) window.imaSize();   // the island grows to fit the list
      if (on) setTimeout(() => { const cur = menu.querySelector('[aria-selected="true"]'); if (cur) menu.scrollTop = Math.max(0, cur.offsetTop - menu.clientHeight / 2 + 20); }, 60);
    };
    const closeMenu = () => { if (menu.classList.contains("open")) setMenu(false); };
    const syncPick = () => {
      const l = LANGS.find((x) => x[0] === sel.value) || LANGS[0];
      selName.textContent = l[2];
      menu.querySelectorAll(".tr-opt").forEach((o) => o.setAttribute("aria-selected", String(o.dataset.code === sel.value)));
    };
    LANGS.forEach(([code, , native]) => {
      const o = document.createElement("button");
      o.type = "button"; o.className = "tr-opt"; o.dataset.code = code; o.setAttribute("role", "option");
      o.innerHTML = "<span></span><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M5 12.5l4.5 4.5L19 7.5\"/></svg>";
      o.firstChild.textContent = native;
      o.addEventListener("click", () => { closeMenu(); if (sel.value !== code) { sel.value = code; syncPick(); sel.dispatchEvent(new Event("change")); } });
      menu.appendChild(o);
    });
    selBtn.addEventListener("click", () => {
      setMenu(!menu.classList.contains("open"));
    });
    document.addEventListener("pointerdown", (e) => { if (menu.classList.contains("open") && !menu.contains(e.target) && !selBtn.contains(e.target)) closeMenu(); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeMenu(); });
    const trView = menu.closest(".bp-view");
    if (trView) new MutationObserver(() => { if (!trView.classList.contains("on")) closeMenu(); }).observe(trView, { attributes: true, attributeFilter: ["class"] });
    syncPick();

    let active = false, busy = false, flash = "", flashTimer = 0, gen = 0, modelIdx = 0;
    const langInfo = () => LANGS.find((l) => l[0] === sel.value) || LANGS[0];

    function render() {
      btn.className = "tr-btn" + (busy ? " busy" : active ? " on" : "");
      btn.disabled = busy;
      btn.textContent = flash || (busy ? t("trWorking") : active ? t("trBack") : t("trGo"));
    }
    function say(msg) {
      flash = msg; render();
      clearTimeout(flashTimer);
      flashTimer = setTimeout(() => { flash = ""; render(); }, 2600);
    }

    /* ----- which pieces of text in the chat get translated (code and formulas stay as they are) ----- */
    function collect() {
      const out = [];
      thread.querySelectorAll(".bubble:not(.typing), .quote-clip").forEach((box) => {
        const w = document.createTreeWalker(box, NodeFilter.SHOW_TEXT, {
          acceptNode(n) {
            if (!/\p{L}/u.test(n.nodeValue)) return NodeFilter.FILTER_REJECT;
            if (n.parentElement && n.parentElement.closest("pre, code, .katex, .code, .code-copy, button")) return NodeFilter.FILTER_REJECT;
            return NodeFilter.FILTER_ACCEPT;
          },
        });
        while (w.nextNode()) out.push(w.currentNode);
      });
      return out;
    }
    const hostOf = (n) => (n.parentElement && n.parentElement.closest(".bubble, .quote-clip")) || n.parentElement;

    /* ----- Groq ----- */
    async function groq(strings, langName) {
      const models = CFG.groqModels && CFG.groqModels.length ? CFG.groqModels : ["openai/gpt-oss-120b"];
      const messages = [
        { role: "system", content:
          "You are a translation engine inside a chat app. Translate every string of the JSON array the user sends into " + langName + ". " +
          "Keep emojis, numbers, URLs, @mentions, code and markdown symbols exactly as they are. Keep the tone and meaning. " +
          "If a string is already in " + langName + ", return it unchanged. Never explain anything. " +
          "Reply ONLY with JSON in this shape: {\"t\":[...]} holding exactly " + strings.length + " strings in the same order." },
        { role: "user", content: JSON.stringify(strings) },
      ];
      const tries = [
        { response_format: { type: "json_object" }, reasoning_effort: "low" },
        { response_format: { type: "json_object" } },
        {},
      ];
      let lastErr = new Error("failed");
      for (let m = modelIdx; m < models.length; m++) {
        for (const extra of tries) {
          let res;
          try {
            res = await fetch((window.IMA_API || "") + "/api/groq/tools", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(Object.assign({ model: models[m], temperature: 0.2, messages }, extra)),
            });
          } catch (e) { throw new Error("network"); }
          if (res.status === 401 || res.status === 403) throw new Error("auth");
          if (res.status === 429) throw new Error("rate");
          if (!res.ok) { lastErr = new Error("http " + res.status); continue; }   // 400/404: try a simpler request, then the next model
          const data = await res.json();
          const raw = (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || "";
          const s = raw.indexOf("{"), e = raw.lastIndexOf("}");
          let arr;
          try { arr = JSON.parse(raw.slice(s, e + 1)).t; } catch (_) { arr = null; }
          if (Array.isArray(arr) && arr.length === strings.length && arr.every((x) => typeof x === "string")) { modelIdx = m; return arr; }
          lastErr = new Error("bad answer");
        }
      }
      throw lastErr;
    }
    // a batch that comes back wrong is split in halves until it works
    async function safe(strings, langName) {
      try { return await groq(strings, langName); }
      catch (err) {
        if (strings.length < 2 || /^(auth|rate|network)$/.test(err.message)) throw err;
        const h = Math.ceil(strings.length / 2);
        return (await safe(strings.slice(0, h), langName)).concat(await safe(strings.slice(h), langName));
      }
    }
    async function translateAll(texts, langName) {
      const batches = []; let cur = [], size = 0;
      texts.forEach((x, i) => {
        if (cur.length && (cur.length >= 30 || size + x.length > 3000)) { batches.push(cur); cur = []; size = 0; }
        cur.push(i); size += x.length;
      });
      if (cur.length) batches.push(cur);
      const out = new Array(texts.length);
      let next = 0;
      const worker = async () => {
        while (next < batches.length) {
          const idx = batches[next++];
          const res = await safe(idx.map((i) => texts[i].trim()), langName);
          idx.forEach((i, k) => { const lead = texts[i].match(/^\s*/)[0], tail = texts[i].match(/\s*$/)[0]; out[i] = lead + res[k] + tail; });
        }
      };
      await Promise.all([worker(), worker(), worker()].slice(0, Math.min(3, batches.length)));
      return out;
    }

    /* ----- the animation: a wave while waiting, then the new text blurs in ----- */
    const hosts = (nodes) => Array.from(new Set(nodes.map(hostOf).filter(Boolean)));
    function wave(list, on) { list.forEach((h) => h.classList.toggle("tr-wait", on)); }
    function reveal(list) {
      list.forEach((h, i) => {
        h.style.setProperty("--trd", Math.min(i * 0.05, 0.7) + "s");
        h.classList.remove("tr-in"); void h.offsetWidth; h.classList.add("tr-in");
        h.addEventListener("animationend", () => { h.classList.remove("tr-in"); h.style.removeProperty("--trd"); }, { once: true });
      });
    }
    function setDir(list, on) {
      list.forEach((h) => {
        if (on) { if (h.dataset.trDir === undefined) h.dataset.trDir = h.getAttribute("dir") || ""; h.setAttribute("dir", "auto"); }
        else if (h.dataset.trDir !== undefined) { if (h.dataset.trDir) h.setAttribute("dir", h.dataset.trDir); else h.removeAttribute("dir"); delete h.dataset.trDir; }
      });
    }

    async function run(quiet) {
      const my = ++gen, code = sel.value, nodes = collect().filter((n) => n._l !== code);
      if (!nodes.length) { if (!quiet) say(t("trEmpty")); if (!quiet) active = true; render(); return; }
      busy = !quiet || busy; active = true; render();
      const list = hosts(nodes);
      wave(list, true);
      try {
        const res = await translateAll(nodes.map((n) => (n._o !== undefined ? n._o : n.nodeValue)), langInfo()[1]);
        if (my !== gen) { wave(list, false); return; }
        nodes.forEach((n, i) => { if (n._o === undefined) n._o = n.nodeValue; n.nodeValue = res[i]; n._l = code; });
        setDir(list, true); wave(list, false); reveal(list);
      } catch (err) {
        wave(list, false);
        if (my === gen) {
          console.warn("[translate]", err);
          if (!nodes.some((n) => n._l)) active = false;
          say(err.message === "auth" ? "API key?" : t("trFail"));
        }
      }
      if (my === gen) { busy = false; render(); }
    }
    function restore() {
      gen++; busy = false; active = false;
      const nodes = collect().filter((n) => n._o !== undefined && n._l);
      const list = hosts(nodes);
      nodes.forEach((n) => { n.nodeValue = n._o; delete n._o; delete n._l; });
      setDir(list, false); reveal(list); render();
    }

    btn.addEventListener("click", () => { if (busy) return; if (active) restore(); else run(false); });
    sel.addEventListener("change", () => {
      try { localStorage.setItem("ima-trlang", sel.value); } catch (_) {}
      if (active) run(false);
    });
    // new messages arrive while translate is on → they get translated too
    let pend = 0;
    new MutationObserver((muts) => {
      if (!active || !muts.some((m) => Array.from(m.addedNodes).some((n) => n.nodeType === 1 && n.classList.contains("msg")))) return;
      clearTimeout(pend);
      pend = setTimeout(() => { if (!busy) run(true); }, 300);
    }).observe(thread, { childList: true });

    window.imaTrRefresh = render;
    render();
  })();

  /* =========================================================
     YOUTUBE (Data API v3) — search in the island, play in a small floating player
  ========================================================= */
  (() => {
    const input = $("musicSearch"), list = $("ytList"), note = $("ytNote");
    if (!input || !list) return;
        let loaded = false, reqId = 0, videos = [];

    const esc = (x) => { const d = document.createElement("textarea"); d.innerHTML = x || ""; return d.value; };   // API titles come HTML-escaped
    async function fetchVideos(q) {
      let items;
      if (q) {
        const r = await fetch((window.IMA_API || "") + "/api/youtube/search?q=" + encodeURIComponent(q));
        if (!r.ok) throw new Error("http " + r.status);
        items = ((await r.json()).items || []).map((i) => ({ id: i.id && i.id.videoId, sn: i.snippet }));
      } else {
        const r = await fetch((window.IMA_API || "") + "/api/youtube/popular");
        if (!r.ok) throw new Error("http " + r.status);
        items = ((await r.json()).items || []).map((i) => ({ id: i.id, sn: i.snippet }));
      }
      return items.filter((i) => i.id && i.sn).map((i) => ({
        id: i.id, title: esc(i.sn.title), channel: esc(i.sn.channelTitle),
        thumb: (i.sn.thumbnails && (i.sn.thumbnails.medium || i.sn.thumbnails.default) || {}).url || "https://i.ytimg.com/vi/" + i.id + "/mqdefault.jpg",
      }));
    }
    function render() {
      list.textContent = "";
      note.textContent = videos.length ? "" : note.dataset.msg || "";
      note.style.display = videos.length ? "none" : "";
      videos.forEach((v) => {
        const b = document.createElement("button");
        b.type = "button"; b.className = "yt-item"; b.dataset.id = v.id;
        b.title = v.title + " — " + v.channel; b.setAttribute("role", "listitem"); b.setAttribute("aria-label", b.title);
        const im = document.createElement("img");
        im.alt = ""; im.loading = "lazy"; im.src = v.thumb;
        const tx = document.createElement("span"); tx.className = "li-txt";
        const t1 = document.createElement("b"); t1.textContent = v.title;
        const t2 = document.createElement("span"); t2.textContent = v.channel || "";
        tx.append(t1, t2);
        b.append(im, tx);
        list.appendChild(b);
      });
    }
    async function load(q) {
      const my = ++reqId;
      loaded = true; videos = []; note.dataset.msg = t("ytLoading"); render();
      try {
        const out = await fetchVideos(q);
        if (my !== reqId) return;
        videos = out; note.dataset.msg = out.length ? "" : t("ytNone");
      } catch (err) {
        if (my !== reqId) return;
        console.warn("[youtube]", err);
        videos = []; note.dataset.msg = t("ytFail");
      }
      render(); list.scrollLeft = 0;
    }

    /* ----- player: fills the whole expanded bar, under the search field ----- */
    const box = $("ytBox");
    let frameEl = null;
    function stop() {
      if (frameEl) { frameEl.remove(); frameEl = null; }
      box.classList.remove("watch");
      if (window.imaIslandWatch) window.imaIslandWatch(false);
    }
    function play(v) {
      if (frameEl) frameEl.remove();
      const f = document.createElement("iframe");
      f.className = "yt-frame";
      let q = "autoplay=1&playsinline=1&rel=0&modestbranding=1";
      if (/^https?:$/.test(location.protocol)) q += "&enablejsapi=1&origin=" + encodeURIComponent(location.origin);
      f.src = "https://www.youtube.com/embed/" + encodeURIComponent(v.id) + "?" + q;
      f.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen";
      f.referrerPolicy = "strict-origin-when-cross-origin";   // the embed refuses to play without a referrer (error 153)
      f.allowFullscreen = true;
      f.title = v.title;
      box.appendChild(f);
      frameEl = f;
      box.classList.add("watch");
      if (window.imaIslandWatch) window.imaIslandWatch(true);
    }
    window.imaYtStop = stop;

    list.addEventListener("click", (e) => {
      const b = e.target.closest(".yt-item");
      const v = b && videos.find((x) => x.id === b.dataset.id);
      if (!v) return;
      play(v);
    });
    input.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || !window.imaView || window.imaView() !== "yt") return;
      e.preventDefault();
      stop();
      load(input.value.trim());
      input.blur();
    });
    input.addEventListener("search", () => { if (!input.value && window.imaView && window.imaView() === "yt") { stop(); load(""); } });

    // the island tells us when the YouTube app opens / closes (search bar changes its hint)
    window.imaYtShow = (on) => {
      input.placeholder = on ? t("ytSearch") : t("musicSearch");
      input.setAttribute("aria-label", input.placeholder);
      if (on && !loaded) load(input.value.trim());
    };
    window.imaYtRefresh = () => { if (window.imaView && window.imaView() === "yt") window.imaYtShow(true); };
  })();

  /* =========================================================
     MAP (Leaflet.js + OpenStreetMap data) — opens inside the island; the search bar looks places up
  ========================================================= */
  (() => {
    const input = $("musicSearch"), satBtn = $("mapSat"), box = $("mapBox"), host = $("mapView"), note = $("mapNote"), locBtn = $("mapLoc");
    if (!input || !host) return;
    const LEAFLET = "https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/";
    let map = null, street = null, sat = null, satOn = false, marker = null, me = null, loading = null, reqId = 0;

    const say = (msg) => { note.textContent = msg || ""; note.style.display = msg ? "" : "none"; };
    function loadLeaflet() {
      if (window.L) return Promise.resolve();
      if (loading) return loading;
      loading = new Promise((ok, fail) => {
        const css = document.createElement("link");
        css.rel = "stylesheet"; css.href = LEAFLET + "leaflet.css";
        document.head.appendChild(css);
        const js = document.createElement("script");
        js.src = LEAFLET + "leaflet.js";
        js.onload = () => ok(); js.onerror = () => { loading = null; js.remove(); fail(new Error("leaflet")); };
        document.head.appendChild(js);
      });
      return loading;
    }
    const pin = () => L.divIcon({ className: "map-pin", html: "<i></i>", iconSize: [18, 18], iconAnchor: [9, 9] });
    function setMarker(latlng, label) {
      if (marker) marker.setLatLng(latlng); else marker = L.marker(latlng, { icon: pin(), keyboard: false }).addTo(map);
      marker.unbindTooltip();
      if (label) marker.bindTooltip(label, { direction: "top", offset: [0, -8], className: "map-tip" });
    }
    async function init() {
      if (map) { map.invalidateSize(); return; }
      say(t("ytLoading"));
      try { await loadLeaflet(); } catch (_) { say(t("mapFail")); return; }
      if (map) return;
      map = L.map(host, { zoomControl: false, attributionControl: false, worldCopyJump: true }).setView([30, 20], 2);
      L.control.attribution({ prefix: false, position: "bottomleft" }).addTo(map);
      L.control.zoom({ position: "bottomright" }).addTo(map);
      street = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(map);
      sat = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
        maxZoom: 19,
        attribution: "Tiles &copy; Esri &mdash; Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community",
      });
      [street, sat].forEach((l) => l
        .on("tileerror", () => { if (!host.dataset.err) { host.dataset.err = "1"; say(t("mapFail")); } })
        .on("tileload", () => { if (host.dataset.err) { delete host.dataset.err; say(""); } }));
      if (satOn) setSat(true);
      // the island animates its size: keep the map in step with it
      if (window.ResizeObserver) new ResizeObserver(() => map && map.invalidateSize()).observe(host);
      say("");
      locate(true);
    }
    function locate(quiet) {
      if (!navigator.geolocation) { if (!quiet) say(t("mapDenied")); return; }
      navigator.geolocation.getCurrentPosition((pos) => {
        const ll = [pos.coords.latitude, pos.coords.longitude];
        if (me) me.setLatLng(ll); else me = L.circleMarker(ll, { radius: 7, weight: 3, color: "#fff", fillColor: "#0a84ff", fillOpacity: 1 }).addTo(map);
        map.setView(ll, Math.max(map.getZoom(), 14), { animate: true });
      }, () => { if (!quiet) { say(t("mapDenied")); setTimeout(() => say(""), 2200); } }, { enableHighAccuracy: false, timeout: 8000, maximumAge: 300000 });
    }
    async function search(q) {
      const my = ++reqId;
      await init();
      if (!map || !q) return;
      say(t("ytLoading"));
      try {
        const r = await fetch("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&accept-language=" + encodeURIComponent(settings.lang || "en") + "&q=" + encodeURIComponent(q));
        if (!r.ok) throw new Error("http " + r.status);
        const hit = (await r.json())[0];
        if (my !== reqId) return;
        if (!hit) { say(t("mapNone")); setTimeout(() => { if (my === reqId) say(""); }, 2200); return; }
        say("");
        const ll = [parseFloat(hit.lat), parseFloat(hit.lon)];
        setMarker(ll, (hit.display_name || q).split(",").slice(0, 2).join(","));
        const bb = hit.boundingbox;
        if (bb && bb.length === 4) map.flyToBounds([[+bb[0], +bb[2]], [+bb[1], +bb[3]]], { maxZoom: 16, duration: 0.8 });
        else map.flyTo(ll, 14, { duration: 0.8 });
        marker.openTooltip();
      } catch (err) {
        if (my !== reqId) return;
        console.warn("[map]", err);
        say(t("mapFail"));
      }
    }
    // standard <-> satellite (Esri World Imagery): same map, markers and GPS, only the tiles change
    function setSat(on) {
      satOn = on;
      satBtn.classList.toggle("on", on);
      satBtn.setAttribute("aria-pressed", String(on));
      if (!map) return;
      if (on) { sat.addTo(map); map.removeLayer(street); } else { street.addTo(map); map.removeLayer(sat); }
      host.classList.toggle("is-sat", on);
      delete host.dataset.err; say("");
    }
    satBtn.addEventListener("click", async () => { await init(); if (map) setSat(!satOn); });
    locBtn.addEventListener("click", async () => { await init(); if (map) locate(false); });
    input.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || !window.imaView || window.imaView() !== "map") return;
      e.preventDefault();
      search(input.value.trim());
      input.blur();
    });

    // the island tells us when the Map app opens / closes (search bar changes its hint)
    window.imaMapShow = (on) => {
      if (on) { input.placeholder = t("mapSearch"); input.setAttribute("aria-label", input.placeholder); init(); }
    };
    window.imaMapRefresh = () => { if (window.imaView && window.imaView() === "map") window.imaMapShow(true); };
    say("");
  })();

  /* =========================================================
     NEWS (Google News RSS) — topics slide like the other tools; the search bar looks stories up.
     Google sends no CORS headers, so the feed is read through a public CORS proxy (several are tried).
  ========================================================= */
  (() => {
    const input = $("musicSearch"), tabs = $("nwTabs"), tabsIn = $("nwTabsIn"), list = $("nwList"), note = $("nwNote");
    if (!input || !tabs) return;
    const thumb = tabsIn.querySelector(".nw-thumb");
    const G = "https://news.google.com/rss";
    const EN = "hl=en-US&gl=US&ceid=US:en";
    const sec = (x) => G + "/headlines/section/topic/" + x + "?" + EN;
    const q = (x, loc) => G + "/search?q=" + x + "+when:1d&" + (loc || EN);
    const TOPICS = [
      { id: "top", name: "Top Stories", ar: "أهم الأخبار", url: G + "?" + EN },
      { id: "world", name: "World", ar: "العالم", url: sec("WORLD") },
      { id: "national", name: "National", ar: "محلي", url: sec("NATION") },
      { id: "technology", name: "Technology", ar: "التقنية", url: sec("TECHNOLOGY") },
      { id: "science", name: "Science", ar: "العلوم", url: sec("SCIENCE") },
      { id: "business", name: "Business", ar: "الأعمال", url: sec("BUSINESS") },
      { id: "entertainment", name: "Entertainment", ar: "ترفيه", url: sec("ENTERTAINMENT") },
      { id: "sports", name: "Sports", ar: "رياضة", url: sec("SPORTS") },
      { id: "health", name: "Health", ar: "الصحة", url: sec("HEALTH") },
      { id: "ai", name: "Artificial Intelligence", ar: "الذكاء الاصطناعي", url: q("artificial+intelligence") },
      { id: "openai", name: "OpenAI", ar: "OpenAI", url: q("OpenAI") },
      { id: "cybersecurity", name: "Cybersecurity", ar: "الأمن السيبراني", url: q("cybersecurity") },
      { id: "gaming", name: "Gaming", ar: "ألعاب", url: q("video+games") },
      { id: "space", name: "Space", ar: "الفضاء", url: q("space+exploration") },
      { id: "algeria", name: "Algeria", ar: "الجزائر", url: q("Algeria", "hl=ar&gl=DZ&ceid=DZ:ar") },
    ];
    /* Google News has no CORS headers → read it through public relays. All of them are asked at once and the first good answer wins,
       so one dead or blocked relay never breaks the news. A relay returns either the raw RSS text or (rss2json) ready JSON items. */
    const enc = encodeURIComponent;
    const RELAYS = [
      { u: (x) => "https://api.allorigins.win/raw?url=" + enc(x) },
      { u: (x) => "https://api.allorigins.win/get?url=" + enc(x), wrap: (j) => j && j.contents },
      { u: (x) => "https://corsproxy.io/?url=" + enc(x) },
      { u: (x) => "https://api.codetabs.com/v1/proxy?quest=" + enc(x) },
      { u: (x) => "https://api.cors.lol/?url=" + enc(x) },
      { u: (x) => "https://thingproxy.freeboard.io/fetch/" + x },
      { u: (x) => "https://api.rss2json.com/v1/api.json?rss_url=" + enc(x), json: true },
    ];
    let custom = null, idx = 0, reqId = 0, loaded = false;
    const cache = new Map();   // url -> { at, items }
    const topics = () => (custom ? [custom] : []).concat(TOPICS);
    const label = (tp) => (settings.lang === "ar" && tp.ar) || tp.name;
    const say = (msg) => { note.textContent = msg || ""; };

    /* ----- tabs (the white thumb slides to the chosen topic) ----- */
    function buildTabs() {
      tabsIn.querySelectorAll(".nw-tab").forEach((b) => b.remove());
      topics().forEach((tp, i) => {
        const b = document.createElement("button");
        b.type = "button"; b.className = "nw-tab"; b.setAttribute("role", "tab"); b.textContent = (tp.custom ? "🔍 " : "") + label(tp);
        b.addEventListener("click", () => go(i));
        tabsIn.appendChild(b);
      });
      markTab(false);
    }
    function markTab(smooth) {
      const bs = tabsIn.querySelectorAll(".nw-tab");
      bs.forEach((b, i) => b.setAttribute("aria-selected", String(i === idx)));
      const b = bs[idx];
      if (!b) return;
      thumb.style.width = b.offsetWidth + "px";
      thumb.style.transform = "translateX(" + b.offsetLeft + "px)";
      tabs.scrollTo({ left: b.offsetLeft - (tabs.clientWidth - b.offsetWidth) / 2, behavior: smooth ? "smooth" : "auto" });
    }

    /* ----- feed ----- */
    const ago = (d) => {
      const m = Math.round((Date.now() - d) / 60000);
      if (!isFinite(m)) return "";
      const rtf = new Intl.RelativeTimeFormat(timeLocale() || settings.lang || "en", { numeric: "auto", style: "short" });
      if (m < 60) return rtf.format(-Math.max(1, m), "minute");
      if (m < 1440) return rtf.format(-Math.round(m / 60), "hour");
      return rtf.format(-Math.round(m / 1440), "day");
    };
    function fromRss(xml) {
      const doc = new DOMParser().parseFromString(xml, "text/xml");
      return Array.from(doc.querySelectorAll("item")).slice(0, 30).map((it) => {
        const g = (n) => { const e = it.querySelector(n); return e ? e.textContent.trim() : ""; };
        return clean(g("title"), g("source"), g("link"), Date.parse(g("pubDate")));
      }).filter(Boolean);
    }
    function clean(title, src, link, date) {
      const cut = title.lastIndexOf(" - ");
      if (cut > 0) { if (!src) src = title.slice(cut + 3); title = title.slice(0, cut); }
      return title && link ? { title, src, link, date } : null;
    }
    // asks every relay in parallel; resolves with the first one that gives real stories
    function fetchFeed(url) {
      return new Promise((resolve, reject) => {
        const ctls = [], errs = []; let left = RELAYS.length, done = false;
        const fail = (e) => { errs.push(e && e.message); if (--left === 0 && !done) reject(new Error(errs.join(" | "))); };
        RELAYS.forEach((rl) => {
          const ctl = new AbortController(); ctls.push(ctl);
          const to = setTimeout(() => ctl.abort(), 12000);
          fetch(rl.u(url), { signal: ctl.signal })
            .then((r) => { if (!r.ok) throw new Error("http " + r.status); return rl.json || rl.wrap ? r.json() : r.text(); })
            .then((d) => {
              let items;
              if (rl.json) {
                if (!d || !Array.isArray(d.items)) throw new Error("bad json");
                items = d.items.slice(0, 30).map((x) => clean(x.title || "", "", x.link || "", Date.parse(String(x.pubDate || "").replace(" ", "T") + "Z"))).filter(Boolean);
              } else {
                const txt = rl.wrap ? rl.wrap(d) : d;
                if (typeof txt !== "string" || !/<item[\s>]/i.test(txt)) throw new Error("not rss");
                items = fromRss(txt);
              }
              if (!items.length) throw new Error("empty");
              if (!done) { done = true; ctls.forEach((c) => { if (c !== ctl) c.abort(); }); resolve(items); }
            })
            .catch(fail)
            .finally(() => clearTimeout(to));
        });
      });
    }
    const keep = (url, items) => { try { localStorage.setItem("ima-news:" + url, JSON.stringify({ at: Date.now(), items })); } catch (_) {} };
    const kept = (url) => { try { const j = JSON.parse(localStorage.getItem("ima-news:" + url)); return j && j.items && j.items.length ? j.items : null; } catch (_) { return null; } };
    function paint(items, dirCls) {
      list.className = "nw-list";
      list.textContent = "";
      items.forEach((it) => {
        const a = document.createElement("a");
        a.className = "nw-item"; a.href = it.link; a.target = "_blank"; a.rel = "noopener noreferrer"; a.setAttribute("role", "listitem");
        const b = document.createElement("b"); b.textContent = it.title; a.appendChild(b);
        const m = document.createElement("span"); m.className = "nw-meta";
        const sp = document.createElement("span"); sp.className = "nw-src"; sp.textContent = it.src; m.appendChild(sp);
        const t2 = ago(it.date);
        if (it.src && t2) m.appendChild(document.createElement("i"));
        if (t2) { const tt = document.createElement("span"); tt.textContent = t2; m.appendChild(tt); }
        a.appendChild(m); list.appendChild(a);
      });
      list.scrollTop = 0;
      if (dirCls) { void list.offsetWidth; list.classList.add(dirCls); }
    }
    function skeleton() { list.className = "nw-list"; list.innerHTML = '<div class="nw-skel"></div><div class="nw-skel"></div><div class="nw-skel"></div><div class="nw-skel"></div>'; }
    async function load(dirCls) {
      const tp = topics()[idx]; if (!tp) return;
      const my = ++reqId, hit = cache.get(tp.url);
      say(""); note.classList.remove("err");
      if (hit && Date.now() - hit.at < 5 * 60 * 1000) { paint(hit.items, dirCls); return; }
      skeleton();
      try {
        const items = await fetchFeed(tp.url);
        if (my !== reqId) return;
        cache.set(tp.url, { at: Date.now(), items }); keep(tp.url, items);
        paint(items, dirCls);
      } catch (err) {
        if (my !== reqId) return;
        console.warn("[news]", err);
        const old = (hit && hit.items) || kept(tp.url);   // offline / blocked: show the last stories we had
        if (old) { paint(old, dirCls); return; }
        list.textContent = ""; say(t("newsFail") + "\n" + t("newsRetry")); note.classList.add("err");
      }
    }
    note.addEventListener("click", () => { if (note.classList.contains("err")) load(); });
    function go(i, via) {
      const n = topics().length;
      if (i < 0 || i >= n || i === idx) return;
      const dirCls = via ? (i > idx ? "go-next" : "go-prev") : null;
      idx = i; markTab(true); load(dirCls);
    }

    /* ----- swipe the list left / right to change the topic ----- */
    let sx = 0, sy = 0, tracking = false;
    list.addEventListener("touchstart", (e) => { const p = e.touches[0]; sx = p.clientX; sy = p.clientY; tracking = e.touches.length === 1; }, { passive: true });
    list.addEventListener("touchend", (e) => {
      if (!tracking) return; tracking = false;
      const p = e.changedTouches[0], dx = p.clientX - sx, dy = p.clientY - sy;
      if (Math.abs(dx) < 50 || Math.abs(dx) < Math.abs(dy) * 1.5) return;
      const forward = isRTL() ? dx > 0 : dx < 0;
      go(idx + (forward ? 1 : -1), true);
    }, { passive: true });

    /* ----- search bar: Enter looks stories up and puts the query first in the strip ----- */
    input.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || !window.imaView || window.imaView() !== "news") return;
      e.preventDefault();
      const v = input.value.trim(); if (!v) return;
      const loc = settings.lang === "ar" ? "hl=ar&gl=DZ&ceid=DZ:ar" : EN;
      custom = { id: "q", custom: true, name: v, ar: v, url: G + "/search?q=" + encodeURIComponent(v) + "&" + loc };
      idx = 0; buildTabs(); tabs.scrollTo({ left: 0 }); load("go-prev"); input.blur();
    });
    window.imaNewsShow = (on) => {
      if (!on) return;
      input.placeholder = t("newsSearch"); input.setAttribute("aria-label", input.placeholder);
      if (!loaded) { loaded = true; buildTabs(); load(); }
      else requestAnimationFrame(() => markTab(false));
    };
    window.imaNewsRefresh = () => { if (window.imaView && window.imaView() === "news") { buildTabs(); window.imaNewsShow(true); } };
  })();

  /* =========================================================
     WEATHER (Open-Meteo, no key) — current conditions, hourly, 7 days and details; the search bar looks cities up
  ========================================================= */
  (() => {
    const input = $("musicSearch"), tempEl = $("wxTemp"), icoEl = $("wxIco"), placeEl = $("wxPlace"), note = $("wxNote"), box = $("wxBox");
    const condEl = $("wxCond"), hlEl = $("wxHL"), updEl = $("wxUpd"), locBtn = $("wxLoc"), hoursEl = $("wxHours"), daysEl = $("wxDays"), gridEl = $("wxGrid");
    const hH = $("wxHourlyH"), dH = $("wxDailyH"), tH = $("wxDetailsH"), scroller = $("wxScroll");
    if (!input || !box) return;
    const FALLBACK = { lat: 36.19, lon: 5.41, name: "Sétif" };
    let loc = null, loaded = false, reqId = 0, D = null, fetchedAt = 0, aqi = null;
    let unit = "c";
    try { unit = localStorage.getItem("ima-wxunit") === "f" ? "f" : "c"; } catch (_) {}

    const TXT = {
      en: {
        now: "Now", today: "Today", hourly: "Hourly", daily: "7-day forecast", details: "Details", feels: "Feels like", hum: "Humidity", wind: "Wind", gust: "Gusts",
        uv: "UV index", rain: "Rain", press: "Pressure", sunrise: "Sunrise", sunset: "Sunset", air: "Air quality", cloud: "Clouds", hi: "H", lo: "L", upd: "Updated",
        uvL: ["Low", "Moderate", "High", "Very high", "Extreme"], aqiL: ["Good", "Fair", "Moderate", "Poor", "Very poor", "Hazardous"],
        dir: ["N", "NE", "E", "SE", "S", "SW", "W", "NW"],
        wmo: { 0: "Clear sky", 1: "Mostly clear", 2: "Partly cloudy", 3: "Overcast", 45: "Fog", 48: "Rime fog", 51: "Light drizzle", 53: "Drizzle", 55: "Heavy drizzle", 56: "Freezing drizzle", 57: "Freezing drizzle",
          61: "Light rain", 63: "Rain", 65: "Heavy rain", 66: "Freezing rain", 67: "Freezing rain", 71: "Light snow", 73: "Snow", 75: "Heavy snow", 77: "Snow grains", 80: "Light showers", 81: "Showers", 82: "Violent showers",
          85: "Snow showers", 86: "Heavy snow showers", 95: "Thunderstorm", 96: "Thunderstorm, hail", 99: "Severe thunderstorm" },
      },
      ar: {
        now: "الآن", today: "اليوم", hourly: "كل ساعة", daily: "توقعات ٧ أيام", details: "التفاصيل", feels: "الإحساس", hum: "الرطوبة", wind: "الرياح", gust: "هبّات",
        uv: "الأشعة فوق البنفسجية", rain: "احتمال المطر", press: "الضغط", sunrise: "الشروق", sunset: "الغروب", air: "جودة الهواء", cloud: "الغيوم", hi: "عظمى", lo: "صغرى", upd: "آخر تحديث",
        uvL: ["منخفض", "معتدل", "مرتفع", "مرتفع جداً", "شديد"], aqiL: ["جيدة", "مقبولة", "متوسطة", "سيئة", "سيئة جداً", "خطرة"],
        dir: ["شمال", "شمال شرق", "شرق", "جنوب شرق", "جنوب", "جنوب غرب", "غرب", "شمال غرب"],
        wmo: { 0: "سماء صافية", 1: "صافٍ غالباً", 2: "غائم جزئياً", 3: "غائم", 45: "ضباب", 48: "ضباب جليدي", 51: "رذاذ خفيف", 53: "رذاذ", 55: "رذاذ كثيف", 56: "رذاذ متجمد", 57: "رذاذ متجمد",
          61: "مطر خفيف", 63: "مطر", 65: "مطر غزير", 66: "مطر متجمد", 67: "مطر متجمد", 71: "ثلج خفيف", 73: "ثلج", 75: "ثلج كثيف", 77: "حبيبات ثلج", 80: "زخات خفيفة", 81: "زخات مطر", 82: "زخات عنيفة",
          85: "زخات ثلج", 86: "زخات ثلج كثيفة", 95: "عواصف رعدية", 96: "عاصفة رعدية وبرَد", 99: "عاصفة رعدية شديدة" },
      },
    };
    const T = () => TXT[settings.lang] || TXT.en;
    const cond = (code) => { const m = T().wmo; return m[code] || m[Object.keys(m).map(Number).filter((k) => k <= code).pop()] || ""; };

    const say = (msg) => { note.textContent = msg || ""; note.style.display = msg ? "" : "none"; };
    const emoji = (code, day) => {
      if (code === 0) return day ? "☀️" : "🌙";
      if (code <= 2) return day ? "🌤️" : "☁️";
      if (code === 3) return "☁️";
      if (code <= 48) return "🌫️";
      if (code <= 57) return "🌦️";
      if (code <= 67) return "🌧️";
      if (code <= 77) return "❄️";
      if (code <= 82) return "🌧️";
      if (code <= 86) return "❄️";
      return "⛈️";
    };
    const deg = (c) => Math.round(unit === "f" ? c * 9 / 5 + 32 : c) + "°";
    const hhmm = (iso) => iso.slice(11, 16);
    const esc = (x) => String(x).replace(/[&<>"]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
    const lvl = (v, cuts) => cuts.filter((c) => v >= c).length;   // how many thresholds are passed

    function render() {
      if (!D) return;
      const tx = T(), c = D.current, dl = D.daily, hr = D.hourly;
      tempEl.textContent = deg(c.temperature_2m);
      icoEl.textContent = emoji(c.weather_code, c.is_day);
      condEl.textContent = cond(c.weather_code);
      hlEl.textContent = tx.hi + " " + deg(dl.temperature_2m_max[0]) + "  ·  " + tx.lo + " " + deg(dl.temperature_2m_min[0]);
      placeEl.textContent = (loc && loc.name) || t("wxHere");
      updEl.textContent = tx.upd + " " + hhmm(c.time);
      hH.textContent = tx.hourly; dH.textContent = tx.daily; tH.textContent = tx.details;

      // next 24 hours
      const from = hr.time.findIndex((x) => x >= c.time.slice(0, 13) + ":00");
      let h = "";
      for (let i = Math.max(0, from), n = 0; i < hr.time.length && n < 24; i++, n++) {
        const pr = hr.precipitation_probability[i];
        h += '<div class="wx-hr"><span class="wx-hr-t">' + (n === 0 ? tx.now : hhmm(hr.time[i])) + '</span>' +
          '<span class="wx-hr-i">' + emoji(hr.weather_code[i], hr.is_day[i]) + '</span>' +
          '<b>' + deg(hr.temperature_2m[i]) + '</b>' +
          '<span class="wx-hr-p">' + (pr >= 20 ? pr + "%" : "") + '</span></div>';
      }
      hoursEl.innerHTML = h;
      hoursEl.scrollLeft = 0;

      // 7 days
      const lo = Math.min(...dl.temperature_2m_min), hi = Math.max(...dl.temperature_2m_max), span = Math.max(1, hi - lo);
      let d = "";
      dl.time.forEach((day, i) => {
        const name = i === 0 ? tx.today : new Intl.DateTimeFormat(timeLocale() || settings.lang || "en", { weekday: "short" }).format(new Date(day + "T12:00:00"));
        const a = (dl.temperature_2m_min[i] - lo) / span * 100, b = (dl.temperature_2m_max[i] - lo) / span * 100;
        const pr = dl.precipitation_probability_max[i];
        d += '<div class="wx-day"><span class="wx-day-n">' + esc(name) + '</span>' +
          '<span class="wx-day-i">' + emoji(dl.weather_code[i], 1) + '</span>' +
          '<span class="wx-day-p">' + (pr >= 20 ? pr + "%" : "") + '</span>' +
          '<span class="wx-day-lo">' + deg(dl.temperature_2m_min[i]) + '</span>' +
          '<span class="wx-bar"><i style="inset-inline-start:' + a.toFixed(1) + '%;width:' + Math.max(8, b - a).toFixed(1) + '%"></i></span>' +
          '<span class="wx-day-hi">' + deg(dl.temperature_2m_max[i]) + '</span></div>';
      });
      daysEl.innerHTML = d;

      // detail tiles
      const uv = dl.uv_index_max[0] || 0, uvName = tx.uvL[Math.min(4, lvl(uv, [3, 6, 8, 11]))];
      const wd = Math.round(c.wind_direction_10m), wname = tx.dir[Math.round(wd / 45) % 8];
      const tile = (ico, label, val, sub) => '<div class="wx-tile"><span class="wx-tile-l"><i>' + ico + '</i>' + label + '</span><b>' + val + '</b><span class="wx-tile-s">' + (sub || "") + '</span></div>';
      let g = "";
      g += tile("🌡️", tx.feels, deg(c.apparent_temperature), "");
      g += tile("💧", tx.hum, Math.round(c.relative_humidity_2m) + "%", "");
      g += tile("💨", tx.wind, Math.round(c.wind_speed_10m) + " km/h", '<span class="wx-arrow" style="transform:rotate(' + ((wd + 180) % 360) + 'deg)">↑</span> ' + esc(wname) + (c.wind_gusts_10m ? "<br>" + tx.gust + " " + Math.round(c.wind_gusts_10m) : ""));
      g += tile("☀️", tx.uv, Math.round(uv), esc(uvName));
      g += tile("🌧️", tx.rain, (dl.precipitation_probability_max[0] || 0) + "%", c.precipitation ? c.precipitation + " mm" : "");
      g += tile("☁️", tx.cloud, Math.round(c.cloud_cover) + "%", "");
      g += tile("🌅", tx.sunrise, hhmm(dl.sunrise[0]), "");
      g += tile("🌇", tx.sunset, hhmm(dl.sunset[0]), "");
      g += tile("🧭", tx.press, Math.round(c.surface_pressure), "hPa");
      g += tile("🍃", tx.air, aqi == null ? "–" : Math.round(aqi), aqi == null ? "" : esc(tx.aqiL[Math.min(5, lvl(aqi, [20, 40, 60, 80, 100]))]));
      gridEl.innerHTML = g;
    }

    async function fetchWeather(l) {
      const my = ++reqId;
      say(t("ytLoading"));
      try {
        const url = "https://api.open-meteo.com/v1/forecast?latitude=" + l.lat + "&longitude=" + l.lon + "&timezone=auto&forecast_days=7&wind_speed_unit=kmh" +
          "&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,wind_direction_10m,wind_gusts_10m,surface_pressure,precipitation,cloud_cover,weather_code,is_day" +
          "&hourly=temperature_2m,weather_code,precipitation_probability,is_day" +
          "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset,uv_index_max";
        const r = await fetch(url);
        if (!r.ok) throw new Error("http " + r.status);
        const data = await r.json();
        if (my !== reqId) return;
        if (!data.current || !data.daily || !data.hourly) throw new Error("no data");
        loc = l; loaded = true; D = data; aqi = null; fetchedAt = Date.now();
        render();
        scroller.scrollTop = 0;
        say("");
        // air quality is a bonus: a failure just leaves the tile empty
        fetch("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=" + l.lat + "&longitude=" + l.lon + "&current=european_aqi")
          .then((x) => (x.ok ? x.json() : null))
          .then((j) => { if (my === reqId && j && j.current && typeof j.current.european_aqi === "number") { aqi = j.current.european_aqi; render(); } })
          .catch(() => {});
      } catch (err) {
        if (my !== reqId) return;
        console.warn("[weather]", err);
        say(t("wxFail"));
      }
    }
    async function search(q) {
      if (!q) return;
      const my = ++reqId;
      say(t("ytLoading"));
      try {
        const r = await fetch("https://geocoding-api.open-meteo.com/v1/search?count=1&language=" + encodeURIComponent(settings.lang || "en") + "&name=" + encodeURIComponent(q));
        if (!r.ok) throw new Error("http " + r.status);
        const hit = ((await r.json()).results || [])[0];
        if (my !== reqId) return;
        if (!hit) { say(t("wxNone")); setTimeout(() => { if (my === reqId) say(""); }, 2200); return; }
        fetchWeather({ lat: hit.latitude, lon: hit.longitude, name: hit.name });
      } catch (err) {
        if (my !== reqId) return;
        console.warn("[weather]", err);
        say(t("wxFail"));
      }
    }
    // the device location, or Sétif when it is not available
    function start() {
      loaded = true;
      const fallback = () => fetchWeather(loc || FALLBACK);
      if (!navigator.geolocation) { fallback(); return; }
      say(t("ytLoading"));
      navigator.geolocation.getCurrentPosition(
        (pos) => fetchWeather({ lat: +pos.coords.latitude.toFixed(2), lon: +pos.coords.longitude.toFixed(2), name: "" }),
        fallback, { timeout: 6000, maximumAge: 600000 });
    }

    // tap the big temperature: °C ⇄ °F
    tempEl.addEventListener("click", () => {
      unit = unit === "c" ? "f" : "c";
      try { localStorage.setItem("ima-wxunit", unit); } catch (_) {}
      render();
    });
    locBtn.addEventListener("click", start);
    input.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || !window.imaView || window.imaView() !== "wx") return;
      e.preventDefault();
      search(input.value.trim());
      input.blur();
    });
    window.imaWxShow = (on) => {
      if (!on) return;
      input.placeholder = t("wxSearch"); input.setAttribute("aria-label", input.placeholder);
      if (!loaded) start();
      else if (loc && Date.now() - fetchedAt > 10 * 60 * 1000) fetchWeather(loc);   // stale after 10 minutes
    };
    window.imaWxRefresh = () => { if (window.imaView && window.imaView() === "wx") { window.imaWxShow(true); render(); } };
    say("");
  })();

  /* =========================================================
     WEB SEARCH (Tavily) — the search bar sends the query, results open in a new tab
  ========================================================= */
  (() => {
    const input = $("musicSearch"), list = $("wsList"), note = $("wsNote");
    if (!input || !list) return;
        let reqId = 0, results = [], msg = "";

    const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ""); } catch (_) { return u; } };
    function render() {
      list.textContent = "";
      note.textContent = results.length ? "" : msg;
      note.style.display = results.length ? "none" : "";
      results.forEach((r) => {
        const a = document.createElement("a");
        a.className = "ws-item"; a.href = r.url; a.target = "_blank"; a.rel = "noopener noreferrer";
        a.setAttribute("role", "listitem");
        const ti = document.createElement("b"); ti.textContent = r.title || hostOf(r.url);
        const ur = document.createElement("span"); ur.className = "ws-url"; ur.textContent = hostOf(r.url);
        const sn = document.createElement("span"); sn.className = "ws-snip"; sn.textContent = r.content || "";
        a.append(ti, ur, sn);
        list.appendChild(a);
      });
    }
    // only http(s) links are shown (never javascript: etc.)
    const safe = (r) => r && typeof r.url === "string" && /^https?:\/\//i.test(r.url);
    async function search(q) {
      if (!q) return;
      const my = ++reqId;
      results = []; msg = t("ytLoading"); render();
      try {
        const res = await fetch((window.IMA_API || "") + "/api/tavily", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query: q, max_results: 8, search_depth: "basic" }),
        });
        if (!res.ok) throw new Error("http " + res.status);
        const out = ((await res.json()).results || []).filter(safe);
        if (my !== reqId) return;
        results = out; msg = out.length ? "" : t("webNone");
      } catch (err) {
        if (my !== reqId) return;
        console.warn("[web search]", err);
        results = []; msg = t("webFail");
      }
      render(); list.scrollTop = 0;
    }

    input.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || !window.imaView || window.imaView() !== "web" || window.imaSrchMode() !== "web") return;
      e.preventDefault();
      search(input.value.trim());
      input.blur();
    });
    window.imaWebShow = (on) => {
      if (!on || window.imaSrchMode() !== "web") return;
      input.placeholder = t("webSearch"); input.setAttribute("aria-label", input.placeholder);
      if (!results.length && !reqId) { msg = t("webHint"); render(); }
    };
    window.imaWebRefresh = () => { if (window.imaView && window.imaView() === "web" && window.imaSrchMode() === "web") { window.imaWebShow(true); if (!results.length && !reqId) { msg = t("webHint"); render(); } } };
  })();

  /* =========================================================
     IMAGE SEARCH (SerpKite) — Pinterest-style masonry in the island; tap a picture to open it full inside the island
     (pinch / double-tap / wheel to zoom, drag to pan, swipe sideways for the next picture)
  ========================================================= */
  (() => {
    const input = $("musicSearch"), grid = $("giGrid"), note = $("giNote");
    if (!input || !grid) return;
        let reqId = 0, items = [], msg = "", renderId = 0;

    const isUrl = (u) => typeof u === "string" && /^https?:\/\//i.test(u);
    const pick = (o, keys) => { for (const k of keys) { const v = o[k]; if (isUrl(v)) return v; if (v && typeof v === "object" && isUrl(v.url)) return v.url; } return ""; };
    // SerpKite's exact reply shape isn't documented here, so the common field names are all accepted
    function normalize(data) {
      const arr = [data && data.images, data && data.image_results, data && data.images_results, data && data.results, data && data.data, data && data.data && data.data.images, data && data.data && data.data.results]
        .find((x) => Array.isArray(x)) || [];
      return arr.map((o) => {
        if (!o || typeof o !== "object") return null;
        const thumb = pick(o, ["thumbnail", "thumbnail_url", "thumbnailUrl", "thumb", "image", "image_url", "imageUrl", "original", "url"]);
        const full = pick(o, ["original", "image", "image_url", "imageUrl", "url", "link", "thumbnail"]) || thumb;
        const page = pick(o, ["link", "source_url", "page_url", "pageUrl", "source"]);
        const title = typeof o.title === "string" ? o.title : (typeof o.alt === "string" ? o.alt : "");
        return thumb ? { thumb, full, page, title } : null;
      }).filter(Boolean);
    }

    /* ----- masonry: two columns, every picture goes under the shorter one (heights come from the real aspect ratios) ----- */
    const GAP = 6;
    function render() {
      const my = ++renderId;
      grid.textContent = "";
      note.textContent = items.length ? "" : msg;
      note.style.display = items.length ? "none" : "";
      if (!items.length) return;
      const cols = [0, 1].map(() => { const c = document.createElement("div"); c.className = "gi-col"; grid.appendChild(c); return c; });
      const h = [0, 0];
      const cw = Math.max(60, (grid.clientWidth - GAP) / 2);
      // load every thumbnail at once, but place them in the original order
      const loads = items.map((it) => new Promise((res) => {
        const im = new Image(); im.referrerPolicy = "no-referrer"; im.decoding = "async";
        const to = setTimeout(() => res(null), 5000);
        im.onload = () => { clearTimeout(to); res(im); };
        im.onerror = () => { clearTimeout(to); res(null); };
        im.src = it.thumb;
      }));
      (async () => {
        for (let i = 0; i < items.length; i++) {
          const im = await loads[i];
          if (my !== renderId) return;
          if (!im) continue;   // a broken thumbnail just disappears
          const it = items[i];
          const ratio = Math.min(2.2, Math.max(0.55, im.naturalHeight / im.naturalWidth || 1));
          const c = h[0] <= h[1] ? 0 : 1;
          h[c] += cw * ratio + GAP;
          const d = document.createElement("div");
          d.className = "gi-item"; d.dataset.i = i; d.setAttribute("role", "listitem"); d.tabIndex = 0;
          d.style.aspectRatio = "1 / " + ratio.toFixed(3);
          if (it.title) d.setAttribute("aria-label", it.title);
          im.alt = ""; im.draggable = false;
          d.appendChild(im);
          cols[c].appendChild(d);
          requestAnimationFrame(() => d.classList.add("in"));
        }
      })();
    }
    grid.addEventListener("click", (e) => { const d = e.target.closest(".gi-item"); if (d) openViewer(+d.dataset.i); });
    grid.addEventListener("keydown", (e) => { if (e.key === "Enter") { const d = e.target.closest(".gi-item"); if (d) openViewer(+d.dataset.i); } });

    /* ----- full-picture viewer inside the island ----- */
    const gi = $("giBox");
    const gv = document.createElement("div");
    gv.className = "gv"; gv.hidden = true;
    gv.innerHTML = '<div class="gv-stage"><img class="gv-img" alt="" draggable="false"></div><div class="gv-spin"></div>' +
      '<button class="gv-x" type="button" aria-label="Close"><svg viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M2 2l10 10M12 2L2 12"/></svg></button>' +
      '<span class="gv-count"></span>';
    gi.appendChild(gv);
    const stage = gv.querySelector(".gv-stage"), img = gv.querySelector(".gv-img"), spin = gv.querySelector(".gv-spin"), count = gv.querySelector(".gv-count");
    let cur = -1, S = 1, X = 0, Y = 0, loadTok = 0;
    const MAXS = 6;

    const apply = (anim) => {
      img.style.transition = anim ? "transform 0.3s cubic-bezier(0.2, 0.7, 0.2, 1)" : "none";
      img.style.transform = "translate(" + X + "px," + Y + "px) scale(" + S + ")";
    };
    const clampXY = () => {
      const r = stage.getBoundingClientRect(), mx = Math.max(0, (r.width * S - r.width) / 2), my2 = Math.max(0, (r.height * S - r.height) / 2);
      X = Math.min(mx, Math.max(-mx, X)); Y = Math.min(my2, Math.max(-my2, Y));
    };
    const reset = (anim) => { S = 1; X = 0; Y = 0; apply(anim); };
    function show(i, dir) {
      if (i < 0 || i >= items.length) return;
      cur = i;
      const it = items[i], tok = ++loadTok;
      count.textContent = (i + 1) + " / " + items.length;
      reset(false);
      img.style.opacity = "0.55"; spin.classList.add("on");
      img.referrerPolicy = "no-referrer";
      img.src = it.thumb;                       // the thumbnail shows at once, the sharp one replaces it
      if (dir) { img.classList.remove("slide-l", "slide-r"); void img.offsetWidth; img.classList.add(dir > 0 ? "slide-r" : "slide-l"); }
      if (it.full && it.full !== it.thumb) {
        const big = new Image(); big.referrerPolicy = "no-referrer";
        big.onload = () => { if (tok === loadTok) { img.src = it.full; img.style.opacity = ""; spin.classList.remove("on"); } };
        big.onerror = () => { if (tok === loadTok) { img.style.opacity = ""; spin.classList.remove("on"); } };
        big.src = it.full;
      } else { img.style.opacity = ""; spin.classList.remove("on"); }
    }
    function openViewer(i) { gv.hidden = false; requestAnimationFrame(() => gv.classList.add("open")); show(i); }
    function closeViewer() {
      if (gv.hidden) return false;
      gv.classList.remove("open"); loadTok++; cur = -1;
      setTimeout(() => { if (cur < 0) { gv.hidden = true; img.removeAttribute("src"); } }, 260);
      return true;
    }
    gv.querySelector(".gv-x").addEventListener("click", closeViewer);
    window.imaImgBack = () => closeViewer();   // the "<" button closes the picture first
    window.imaImgOpen = () => !gv.hidden;

    // gestures: pinch, drag, double-tap, wheel, swipe to the next picture
    const ptr = new Map();
    let pinch = null, drag = null, lastTap = 0, tapX = 0, tapY = 0, moved = 0, startX = 0, startY = 0;
    const center = () => { const r = stage.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; };
    const dist = () => { const p = [...ptr.values()]; return Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y); };
    const mid = () => { const p = [...ptr.values()]; return { x: (p[0].x + p[1].x) / 2, y: (p[0].y + p[1].y) / 2 }; };
    stage.addEventListener("pointerdown", (e) => {
      stage.setPointerCapture(e.pointerId);
      ptr.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (ptr.size === 2) { const m = mid(), c = center(); pinch = { d: dist(), s: S, px: m.x - c.x, py: m.y - c.y, x: X, y: Y }; drag = null; }
      else if (ptr.size === 1) { drag = { x: e.clientX, y: e.clientY, X, Y }; moved = 0; startX = e.clientX; startY = e.clientY; }
    });
    stage.addEventListener("pointermove", (e) => {
      if (!ptr.has(e.pointerId)) return;
      ptr.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pinch && ptr.size >= 2) {
        const m = mid(), c = center(), px = m.x - c.x, py = m.y - c.y;
        const ns = Math.min(MAXS, Math.max(0.8, pinch.s * dist() / pinch.d));
        // keep the picture point that was under the fingers where it was
        const qx = (pinch.px - pinch.x) / pinch.s, qy = (pinch.py - pinch.y) / pinch.s;
        S = ns; X = px - qx * ns; Y = py - qy * ns; apply(false);
      } else if (drag) {
        moved = Math.max(moved, Math.hypot(e.clientX - startX, e.clientY - startY));
        if (S > 1.02) { X = drag.X + e.clientX - drag.x; Y = drag.Y + e.clientY - drag.y; clampXY(); apply(false); }
      }
    });
    const end = (e) => {
      if (!ptr.has(e.pointerId)) return;
      const wasPinch = !!pinch, up = ptr.get(e.pointerId);
      ptr.delete(e.pointerId);
      if (ptr.size < 2) pinch = null;
      if (wasPinch) {
        if (S < 1.05) reset(true); else { clampXY(); apply(true); }
        drag = ptr.size === 1 ? (() => { const p = [...ptr.values()][0]; return { x: p.x, y: p.y, X, Y }; })() : null;
        return;
      }
      if (!drag || e.type === "pointercancel") { drag = null; return; }
      const dx = up.x - startX, dy = up.y - startY; drag = null;
      if (moved < 8) {                         // a tap: two quick taps zoom in / out around the finger
        const now = Date.now();
        if (now - lastTap < 320 && Math.hypot(up.x - tapX, up.y - tapY) < 30) {
          lastTap = 0;
          if (S > 1.05) reset(true);
          else { const c = center(), ns = 2.6; S = ns; X = -(up.x - c.x) * (ns - 1); Y = -(up.y - c.y) * (ns - 1); clampXY(); apply(true); }
        } else { lastTap = now; tapX = up.x; tapY = up.y; }
      } else if (S <= 1.05 && Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.4) {   // swipe: next / previous picture
        const fwd = isRTL() ? dx > 0 : dx < 0;
        show(cur + (fwd ? 1 : -1), fwd ? 1 : -1);
      } else if (S > 1.05) { clampXY(); apply(true); }
    };
    stage.addEventListener("pointerup", end);
    stage.addEventListener("pointercancel", end);
    stage.addEventListener("wheel", (e) => {
      e.preventDefault();
      const c = center(), px = e.clientX - c.x, py = e.clientY - c.y;
      const ns = Math.min(MAXS, Math.max(1, S * Math.exp(-e.deltaY * 0.0015)));
      const qx = (px - X) / S, qy = (py - Y) / S;
      S = ns; X = px - qx * ns; Y = py - qy * ns;
      if (S < 1.02) { S = 1; X = 0; Y = 0; } else clampXY();
      apply(false);
    }, { passive: false });
    stage.addEventListener("dblclick", (e) => e.preventDefault());

    async function search(q) {
      if (!q) return;
      const my = ++reqId;
      closeViewer();
      items = []; msg = t("ytLoading"); render();
      try {
        const res = await fetch((window.IMA_API || "") + "/api/images", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ q, country: "us", language: settings.lang === "ar" ? "ar" : "en", num: 20, safe: "active", format: "json" }),
        });
        if (!res.ok) throw new Error("http " + res.status);
        const out = normalize(await res.json());
        if (my !== reqId) return;
        items = out; msg = out.length ? "" : t("imgNone");
      } catch (err) {
        if (my !== reqId) return;
        console.warn("[image search]", err);
        items = []; msg = t("imgFail");
      }
      render(); grid.scrollTop = 0;
    }

    input.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || !window.imaView || window.imaView() !== "web" || window.imaSrchMode() !== "img") return;
      e.preventDefault();
      search(input.value.trim());
      input.blur();
    });
    const hint = () => { if (!items.length && !reqId) { msg = t("imgHint"); render(); } };
    window.imaImgShow = (on) => {
      if (!on || window.imaSrchMode() !== "img") { closeViewer(); return; }
      input.placeholder = t("imgSearch"); input.setAttribute("aria-label", input.placeholder);
      hint();
    };
    window.imaImgRefresh = () => { if (window.imaView && window.imaView() === "web") window.imaImgShow(true); };
  })();
})();


/* ---------- squircle title pill: smooth superellipse corners ---------- */
(function () {
  const brand = document.getElementById("brand");
  if (!brand) return;
  const body = document.getElementById("brandBody");
  const chev = document.getElementById("brandChev");
  const panel = document.getElementById("brandPanel");
  const OPEN_H0 = 150, OPEN_R = 36;
  let OPEN_H = OPEN_H0, watching = false;
  const glass = brand.querySelector(".brand-glass");
  const edge = brand.querySelector(".brand-edge path");
  const shadow = brand.querySelector(".brand-shadow path");

  function squircle(w, h, inset) {
    const x0 = inset, y0 = inset, W = w - inset * 2, H = h - inset * 2;
    const cs = getComputedStyle(brand);
    // radius grows with the island while it opens (follows the animated height)
    const h0 = brand.offsetHeight, p = Math.max(0, Math.min(1, (body.offsetHeight - h0) / (OPEN_H - h0 || 1)));
    const base = parseFloat(cs.getPropertyValue("--pill-radius"));
    const want = base + (OPEN_R - base) * p;
    const nn = parseFloat(cs.getPropertyValue("--pill-n"));
    const r = Math.max(0, Math.min(isFinite(want) ? want - inset : H * 0.5, H * 0.5, W / 2)), n = isFinite(nn) ? nn : 3.4, steps = 28, e = 2 / n;
    const c = (t) => Math.pow(Math.cos(t), e), s = (t) => Math.pow(Math.sin(t), e);
    const f = (v) => v.toFixed(2);
    let d = "M" + f(x0 + r) + " " + f(y0) + " L" + f(x0 + W - r) + " " + f(y0);
    const arc = (cx, cy, sx, sy, from, to) => {
      for (let i = 0; i <= steps; i++) {
        const t = from + (to - from) * (i / steps);
        d += " L" + f(cx + sx * r * c(t)) + " " + f(cy + sy * r * s(t));
      }
    };
    arc(x0 + W - r, y0 + r, 1, -1, Math.PI / 2, 0);
    d += " L" + f(x0 + W) + " " + f(y0 + H - r);
    arc(x0 + W - r, y0 + H - r, 1, 1, 0, Math.PI / 2);
    d += " L" + f(x0 + r) + " " + f(y0 + H);
    arc(x0 + r, y0 + H - r, -1, 1, Math.PI / 2, 0);
    d += " L" + f(x0) + " " + f(y0 + r);
    arc(x0 + r, y0 + r, -1, -1, 0, Math.PI / 2);
    return d + " Z";
  }

  function apply() {
    const w = body.offsetWidth, h = body.offsetHeight;
    if (!w || !h) return;
    glass.style.borderRadius = "0";
    glass.style.clipPath = glass.style.webkitClipPath = 'path("' + squircle(w, h, 0) + '")';
    edge.setAttribute("d", squircle(w, h, 0.6));
    shadow.setAttribute("d", squircle(w, h, 2));
  }
  window.imaPillRefresh = apply;
  apply();
  if (window.ResizeObserver) new ResizeObserver(apply).observe(body);

  /* tap the chevron: the pill opens like a dynamic island; tap again / outside / Esc closes it */
  window.imaSize = () => sizeIsland();
  function sizeIsland() {
    const app = document.getElementById("app");
    const btn = parseFloat(getComputedStyle(brand).getPropertyValue("--bar-btn")) || 36;
    const room = (app ? app.clientWidth : window.innerWidth) - 2 * (16 + btn + 8);
    const full = app ? app.clientWidth : window.innerWidth;
    // the map island opens almost edge to edge (over the side buttons); everything else keeps the normal width
    const w = curView === "map" ? Math.max(160, full - 32) : Math.max(160, Math.min(320, room));
    brand.classList.toggle("wide", curView === "map");
    brand.style.setProperty("--open-w", w + "px");
    // watching a video: the island grows so the 16:9 player fills the space under the search bar
    const top = (parseFloat(getComputedStyle(brand).getPropertyValue("--pill-h")) - 30) / 2 || 9;
    const art = Math.round(Math.max(106, Math.min(0.42 * (w - 32), 124)));   // now-playing cover size
    brand.style.setProperty("--np-art", art + "px");
    OPEN_H = watching ? Math.round(top + 30 + 9 + (w - 32) * 9 / 16 + 12)
           : curView === "music" && window.imaMusicMode && window.imaMusicMode() === "now" ? Math.round(top + 30 + 9 + art + 18)   // fits the cover
           : curView === "tr" && window.imaTrPick ? Math.round(top + 30 + 9 + 36 + 8 + 4.5 * 40 + 14)   // language list open
           : /^(wx|news)$/.test(curView) ? Math.round(Math.min(470, Math.max(330, ((app ? app.clientHeight : window.innerHeight) || 700) * 0.62)))   // weather: room for forecast + details
           : curView === "map" ? Math.round(Math.max(300, ((app ? app.clientHeight : window.innerHeight) || 700) * 0.6))   // the map island grows to ~60% of the screen
           : curView === "web" && srchMode === "img" ? Math.round(Math.max(360, ((app ? app.clientHeight : window.innerHeight) || 700) * 0.56))   // image search: room for the masonry + viewer
           : /^(map|web|music|yt)$/.test(curView) ? Math.round(top + 30 + 9 + (w - 32) * 0.72 + 12 + (curView === "web" ? 34 : curView === "music" ? 36 : 0))   // map, search, music and YouTube get a taller island (lists with names)
           : OPEN_H0;
    brand.style.setProperty("--open-h", OPEN_H + "px");
  }
  /* tools as apps: the island opens on the app icons; tapping one shows it under the search bar, "<" goes back */
  const views = Array.from(brand.querySelectorAll(".bp-view"));
  let curView = "home";
  window.imaView = () => curView;
  function showView(name) {
    curView = name;
    brand.classList.toggle("in-app", name !== "home");   // the search bar's magnifier turns into the back button
    views.forEach((v) => {
      const on = v.dataset.view === name;
      v.classList.toggle("on", on);
      if (on) v.removeAttribute("inert"); else v.setAttribute("inert", "");
    });
  }
  let srchMode = "web";   // the Safari app: "web" or "img"
  window.imaSrchMode = () => srchMode;
  const afterView = () => {
    if (window.imaYtShow) window.imaYtShow(curView === "yt");
    if (window.imaMapShow) window.imaMapShow(curView === "map");
    if (window.imaWxShow) window.imaWxShow(curView === "wx");
    if (window.imaNewsShow) window.imaNewsShow(curView === "news");
    if (window.imaWebShow) window.imaWebShow(curView === "web");
    if (window.imaImgShow) window.imaImgShow(curView === "web");
    if (window.imaMusicShow) window.imaMusicShow(curView === "music");
    sizeIsland();
  };
  brand.querySelectorAll(".app-tile").forEach((b) => b.addEventListener("click", () => { showView(b.dataset.app); afterView(); }));
  const backBtn = document.getElementById("bpBack");
  if (backBtn) backBtn.addEventListener("click", () => { if (curView === "music" && window.imaMusicBack && window.imaMusicBack()) return; if (curView === "web" && window.imaImgBack && window.imaImgBack()) return; if (window.imaYtStop) window.imaYtStop(); showView("home"); afterView(); });
  const seg = document.getElementById("seg"), srchBox = document.getElementById("srchBox");
  if (seg) seg.addEventListener("click", (e) => {
    const b = e.target.closest("button[data-mode]");
    if (!b || b.dataset.mode === srchMode) return;
    srchMode = b.dataset.mode;
    srchBox.dataset.mode = srchMode;
    seg.querySelectorAll("button").forEach((x) => x.setAttribute("aria-selected", String(x === b)));
    afterView();
  });
  const musicInput = document.getElementById("musicSearch");
  if (musicInput) musicInput.addEventListener("keydown", (e) => { if (e.key === "Enter" && curView !== "yt" && curView !== "map" && curView !== "wx" && curView !== "web" && curView !== "news") { showView("music"); afterView(); } });   // a search shows its results in Music

  function setOpen(on) {
    if (!on && window.imaYtStop) window.imaYtStop();
    if (on) { sizeIsland(); showView("home"); afterView(); }
    brand.classList.toggle("open", on);
    chev.setAttribute("aria-expanded", String(on));
    if (on) panel.removeAttribute("inert"); else panel.setAttribute("inert", "");
  }
  window.imaIslandClose = () => setOpen(false);
  window.imaIslandWatch = (on) => { watching = on; brand.classList.toggle("watch", on); sizeIsland(); };
  chev.addEventListener("click", () => setOpen(!brand.classList.contains("open")));
  document.addEventListener("pointerdown", (e) => {
    if (brand.classList.contains("open") && !brand.contains(e.target)) setOpen(false);
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && brand.classList.contains("open")) setOpen(false); });
  window.addEventListener("resize", apply);
})();
